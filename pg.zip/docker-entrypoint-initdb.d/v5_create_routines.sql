CREATE OR REPLACE FUNCTION neb.datediff(difftype character varying, date1 date, date2 date) returns integer
    language plpgsql
AS
$$
DECLARE
    YEAR_CONST            Character Varying(15) := 'year';
    MONTH_CONST           Character Varying(15) := 'month';
    DAY_CONST             Character Varying(15) := 'day';
    diffInInterval        Interval;
    diffInDoublePrecision Double Precision      := 0;
    diffInInteger         Integer               := 0;
    dateTemp              Date;
BEGIN

    diffInInterval := age(date2, date1);

    IF lower($1) = lower(YEAR_CONST) THEN
        diffInDoublePrecision := date_part('Year', diffInInterval);
    ELSEIF lower($1) = lower(MONTH_CONST) THEN
        diffInDoublePrecision := (date_part('Year', diffInInterval) * 12) + date_part('Month', diffInInterval);
    ELSEIF lower($1) = lower(DAY_CONST) THEN
        diffInDoublePrecision := endDate - startDate;
    END IF;

    diffInInteger := CAST(diffInDoublePrecision AS Integer);
    RETURN diffInInteger;
END;
$$;

ALTER FUNCTION neb.datediff(varchar, date, date) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.datediff(difftype character varying, date1 date, date2 date) TO nebgp_desenvolvedor with GRANT option;

GRANT EXECUTE ON FUNCTION neb.datediff(difftype character varying, date1 date, date2 date) TO nebgp_usuario_servico with GRANT option;

CREATE OR REPLACE FUNCTION neb.fn_boleto_proposta_hab(bigint) returns character varying
    language plpgsql
AS
$$
DECLARE
    v_contrato_numero ALIAS FOR $1;
    v_boleto_proposta bigint;
    p_boleto_proposta varchar(16);
    p_contador        int;

BEGIN

    v_boleto_proposta = (select max(boleto_proposta) AS boleto_proposta
                         from neb.hab_boleto_proposta
                         where contrato_numero = v_contrato_numero);
    p_boleto_proposta = CAST(v_boleto_proposta AS varchar(16));

    IF (p_boleto_proposta is null) THEN

        p_boleto_proposta = CAST(v_contrato_numero AS varchar(12)) || '2001';

    ELSE
        p_contador = CAST(right(p_boleto_proposta, 3) AS int) + 1;
        p_boleto_proposta = CAST(v_contrato_numero AS varchar(12)) || '2' || lpad(CAST(p_contador AS text), 3, '0');

    END IF;


    RETURN p_boleto_proposta;

END;

$$;

ALTER FUNCTION neb.fn_boleto_proposta_hab(bigint) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.fn_boleto_proposta_hab(bigint) TO nebgp_desenvolvedor with GRANT option;

GRANT EXECUTE ON FUNCTION neb.fn_boleto_proposta_hab(bigint) TO nebgp_usuario_servico with GRANT option;

CREATE OR REPLACE FUNCTION neb.fn_calcula_cedente_hab(bigint) returns character varying
    language plpgsql
AS
$$
DECLARE
    v_contrato_numero ALIAS FOR $1;
    v_digito_ctr                       int;
    v_numero                           varchar(20);
    v_contador                         bigint;
    v_soma                             bigint;
    v_multiplicador                    bigint;
    v_cedente                          varchar(20);
    v_digito_cedente                   bigint;
    v_resto                            bigint;
    v_mes_atraso                       varchar(2);
    v_ano_atraso                       varchar(2);
    v_data_atraso                      varchar(20);
    v_ncpd_invertido                   varchar(4);
    v_soma_ncpd_invertido              bigint;
    v_digito_ncpd                      varchar(1);
    v_nosso_numero_hab                 varchar(10);
    v_p1lndigitavel                    varchar(100);
    v_soma_ln_digitavel                bigint;
    v_controlador_ln_digitavel         bigint;
    v_segundo_controlador_ln_digitavel bigint;
    v_digito_ln1                       bigint;
    v_digito_ln2                       bigint;
    v_p2lndigitavel                    varchar(100);
    v_p3lndigitavel                    varchar(100);
    v_digito_ln3                       bigint;
    v_linha_digitavel_variavel         varchar(150);
    v_variavel_teste                   varchar(200);
    v_data_base                        date;
    v_numero_temp                      varchar(200);
    v_valor_doc                        varchar(10);
    v_fator_vencimento                 varchar(4);
    v_data_vencimento                  date;
    v_valor_boleto                     int;
    v_data_atual                       date;
    v_digito_geral                     varchar(1);
    v_numeracao_cod_barr               varchar(200);
    v_digito_nosso_numero              varchar(1);

BEGIN


    SELECT contrato_dv into v_digito_ctr FROM neb.hab_boleto_dados WHERE contrato_numero = v_contrato_numero;

    IF v_digito_ctr is not null THEN

        v_numero = '90' || CAST(v_contrato_numero AS text) || CAST(v_DIGITO_CTR AS text);
        v_multiplicador = 2;
        v_contador = 15;
        v_soma = 0;


        WHILE v_contador > 0
            LOOP

                v_soma = v_soma + ((CAST(SUBSTRING(v_numero from CAST(v_contador AS integer) FOR 1) AS bigint)) *
                                   v_multiplicador);

                --VERIFICAR MULTIPLICADOR
                IF v_multiplicador = 9 THEN
                    v_multiplicador = 2;
                ELSE
                    v_multiplicador = v_multiplicador + 1;
                END IF;

                v_contador = v_contador - 1;

            END LOOP;

        --CALCULA DIGITO ATRAVES DA SOMA DA 1ª PARTE ATRAVES DA SOMA

        v_RESTO = v_SOMA - ((CAST(FLOOR((v_SOMA / 11)) AS INT)) * 11);

        v_DIGITO_CEDENTE = 11 - (v_RESTO);

        IF v_digito_cedente > 9 THEN
            v_digito_cedente = 0;
        END IF;

        v_cedente = v_numero || CAST(v_digito_cedente AS text);

    END IF;

    RETURN v_cedente;


END;

$$;

ALTER FUNCTION neb.fn_calcula_cedente_hab(bigint) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.fn_calcula_cedente_hab(bigint) TO nebgp_desenvolvedor with GRANT option;

GRANT EXECUTE ON FUNCTION neb.fn_calcula_cedente_hab(bigint) TO nebgp_usuario_servico with GRANT option;

CREATE OR REPLACE FUNCTION neb.fn_calculaiof(numeric, numeric, numeric, date, integer, numeric) returns numeric
    language plpgsql
AS
$$
DECLARE
    valor_principal ALIAS FOR $1;
    vlr_entrada ALIAS FOR $2;
    valor_prest ALIAS FOR $3;
    dt_vencimento ALIAS FOR $4; -- data da contratacao
    qtd_prestacao ALIAS FOR $5;
    tx_juros ALIAS FOR $6;
    tx_iofa          decimal=0.0038;
    tx_iofb          decimal=0.000082;
    data_contratacao date = now();
    valor_base       decimal = valor_principal - vlr_entrada;
    aaa              integer;
    v_dt_prest       date;
    dias             integer;
    valor_fin        decimal;
    valor_juros      decimal;
    amortizacao      decimal;
    iof              decimal;
    iof_total        decimal = 0;
    iof_adicional    decimal;
BEGIN
    --raise notice 'valor_principal[%] vlr_entrada[%] valor_prest[%] dt_vencimento[%] qtd_prestacao[%] ', valor_principal, vlr_entrada, valor_prest, dt_vencimento, qtd_prestacao;
    --raise notice 'tx_juros[%] tx_iofa[%] tx_iofb[%] data_contratacao[%] valor_base[%]', tx_juros, tx_iofa, tx_iofb,data_contratacao, valor_base;
    valor_fin = valor_base;
    raise notice '';
    FOR aaa in 1..qtd_prestacao
        LOOP
            -- FOR de  1 atÃ© a qtde de prestaÃ§Ãµes


            v_dt_prest = data_contratacao + (aaa || ' month')::interval;
            --dias = fn_datediff('d'::char, dt_vencimento,v_dt_prest);
            dias = fn_datediff('d'::char, data_contratacao, v_dt_prest);
            valor_juros = (valor_fin * tx_juros);
            amortizacao = valor_prest - valor_juros;
            valor_fin = valor_fin - amortizacao;

            If dias < 365 Then
                iof = amortizacao * dias * tx_iofb;
            Else
                iof = amortizacao * 365 * tx_iofb;
            End If;
            iof_total = iof_total + iof;
            --raise notice 'v_dt_prest [%] dias[%] valor_fin[%] valor_juros[%] amortizacao[%]',v_dt_prest ,dias ,valor_fin,valor_juros,amortizacao;
            --raise notice 'iof_total[%] iof[%]',iof_total ,iof;


        END LOOP;
    iof_adicional = (tx_iofa * valor_base);
    raise notice 'iof_adicional[%]',iof_adicional;

    --RETURN (iof_total+iof_adicional)::decimal(19,2);
    RETURN (0)::decimal(19, 2);
END;

$$;

ALTER FUNCTION neb.fn_calculaiof(numeric, numeric, numeric, date, integer, numeric) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.fn_calculaiof(numeric, numeric, numeric, date, integer, numeric) TO nebgp_desenvolvedor with GRANT option;

GRANT EXECUTE ON FUNCTION neb.fn_calculaiof(numeric, numeric, numeric, date, integer, numeric) TO nebgp_usuario_servico with GRANT option;

CREATE OR REPLACE FUNCTION neb.fn_calculardigver10(character varying) returns character varying
    language plpgsql
AS
$$
DECLARE
    strNumero ALIAS FOR $1;
    intContador      integer;
    intTotalNumero   integer;
    strComparacao    varchar(500);
    intMultiplicador integer;
    intNumero        integer;
    intResto         integer;

BEGIN

    -------------------------------------------------------------------
-- cria string para verificar se Ã© nÃºmero e verifica
    intContador := 0;
    strComparacao := '';
    WHILE intContador < length(strNumero)
        LOOP
            intContador := intContador + 1;
            strComparacao := strComparacao || '[0-9]';
        END LOOP;
    --------------------------------
-- "~" Ã© o like do SQLServer
-- "!" Ã© o not
    IF strNumero !~ strComparacao THEN
        RETURN '';
    END IF;
    -------------------------------------------------------------------

-------------------------------------------------------------------
-- inicia o multiplicador
    intMultiplicador := 2;
    -------------------------------------------------------------------

-------------------------------------------------------------------
    intTotalNumero := 0;
    intContador := length(strNumero) + 1;
    WHILE intContador > 1
        LOOP
            intContador := intContador - 1;

            --RAISE NOTICE '>>>>> %', substring(strNumero, intContador, 1);
            -- extrai o caracter e multiplica pelo multiplicador
            intNumero := (CAST(substring(strNumero, intContador, 1) AS int)) * intMultiplicador;
            intNumero := CASE
                             WHEN intNumero > 9 THEN (intNumero % 10) + 1
                             ELSE intNumero END;


            --soma o resultado para totalizaÃ§Ã£o
            intTotalNumero := intTotalNumero + @intNumero;

            --se o multiplicador FOR maior que 2 decrementa-o caso contrario atribuir valor padrao original
            intMultiplicador := CASE WHEN (intMultiplicador = 2) THEN 1 ELSE 2 END;

        END LOOP;
    -------------------------------------------------------------------


-------------------------------------------------------------------
--calcula o resto da divisao do total por 10
    intResto = intTotalNumero % 10;

    intResto = 10 - intResto;

    RETURN CASE
               WHEN intResto = 10 Then '0'
               ELSE CAST(intResto AS varchar(2)) END;
-------------------------------------------------------------------


END;

$$;

ALTER FUNCTION neb.fn_calculardigver10(varchar) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.fn_calculardigver10(character varying) TO nebgp_desenvolvedor with GRANT option;

GRANT EXECUTE ON FUNCTION neb.fn_calculardigver10(character varying) TO nebgp_usuario_servico with GRANT option;

CREATE OR REPLACE FUNCTION neb.fn_calculardigver11(character varying) returns character varying
    language plpgsql
AS
$$
DECLARE
    strNumero ALIAS FOR $1;
    intContador      integer;
    intTotalNumero   integer;
    strComparacao    varchar(500);
    intMultiplicador integer;
    intNumero        integer;
    intResto         integer;

BEGIN

    -------------------------------------------------------------------
-- cria string para verificar se Ã© nÃºmero e verifica
    intContador := 0;
    strComparacao := '';
    WHILE intContador < length(strNumero)
        LOOP
            intContador := intContador + 1;
            strComparacao := strComparacao || '[0-9]';
        END LOOP;
    --------------------------------
-- "~" Ã© o like do SQLServer
-- "!" Ã© o not
    IF strNumero !~ strComparacao THEN
        RETURN '';
    END IF;
    -------------------------------------------------------------------


-------------------------------------------------------------------
-- inicia o multiplicador
    intMultiplicador := 9;
    -------------------------------------------------------------------


-------------------------------------------------------------------
    intTotalNumero := 0;
    intContador := length(strNumero) + 1;
    WHILE intContador > 1
        LOOP
            intContador := intContador - 1;

            --RAISE NOTICE '>>>>> %', substring(strNumero, intContador, 1);
            -- extrai o caracter e multiplica pelo multiplicador
            intNumero := (CAST(substring(strNumero, intContador, 1) AS int)) * intMultiplicador;

            --soma o resultado para totalizaÃ§Ã£o
            intTotalNumero := intTotalNumero + @intNumero;

            --se o multiplicador FOR maior que 2 decrementa-o caso contrario atribuir valor padrao original
            intMultiplicador := CASE WHEN (intMultiplicador > 2) THEN intMultiplicador - 1 ELSE 9 END;

        END LOOP;
    -------------------------------------------------------------------


-------------------------------------------------------------------
--calcula o resto da divisao do total por 11
    intResto = intTotalNumero % 11;

-- verifica AS exceÃ§Ãµes ( 0 -> DV=0    10 -> DV=X (para o BB) e retorna o DV
    RETURN CASE
               WHEN intResto = 10 Then '0'
               ELSE CAST(intResto AS varchar(2)) END;
-------------------------------------------------------------------


END;
$$;

ALTER FUNCTION neb.fn_calculardigver11(varchar) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.fn_calculardigver11(character varying) TO nebgp_usuario_servico with GRANT option;

GRANT EXECUTE ON FUNCTION neb.fn_calculardigver11(character varying) TO nebgp_desenvolvedor with GRANT option;

CREATE OR REPLACE FUNCTION neb.fn_calculardigvercodbarras(character varying) returns character varying
    language plpgsql
AS
$$
DECLARE
    strNumero ALIAS FOR $1;
    intContador      integer;
    intTotalNumero   integer;
    strComparacao    varchar(500);
    intMultiplicador integer;
    intNumero        integer;
    intResto         integer;

BEGIN
    -------------------------------------------------------------------
-- a quantidade de caracteres DEVE ser 43
    IF length(strNumero) <> 43 THEN
        RETURN '-1';
    END IF;
    -------------------------------------------------------------------


-------------------------------------------------------------------
-- cria string para verificar se Ã© nÃºmero e verifica
    intContador := 0;
    strComparacao := '';
    WHILE intContador < length(strNumero)
        LOOP
            intContador := intContador + 1;
            strComparacao := strComparacao || '[0-9]';
        END LOOP;
    --------------------------------
-- "~" Ã© o like do SQLServer
-- "!" Ã© o not
    IF strNumero !~ strComparacao THEN
        RETURN '-2';
    END IF;
    -------------------------------------------------------------------


-------------------------------------------------------------------
-- inicia o multiplicador
    intMultiplicador := 2;
    -------------------------------------------------------------------


-------------------------------------------------------------------
    intTotalNumero := 0;
    intContador := length(strNumero) + 1;
    WHILE intContador > 1
        LOOP
            intContador := intContador - 1;


            --RAISE NOTICE '>>>>> %', substring(strNumero, intContador, 1);
            -- extrai o caracter e multiplica pelo multiplicador
            intNumero := (CAST(substring(strNumero, intContador, 1) AS int)) * intMultiplicador;

            --soma o resultado para totalizaÃ§Ã£o
            intTotalNumero := intTotalNumero + @intNumero;

            --se o multiplicador FOR maior que 2 decrementa-o caso contrario atribuir valor padrao original
            intMultiplicador := CASE WHEN (intMultiplicador > 8) THEN 2 ELSE intMultiplicador + 1 END;

        END LOOP;
    -------------------------------------------------------------------

-------------------------------------------------------------------
--calcula o resto da divisao do total por 11
    intResto := intTotalNumero % 11;

    intResto := 11 - intResto;

    RETURN CASE
               WHEN intResto = 10 Then '1'
               WHEN intResto = 11 Then '1'
               ELSE CAST(intResto AS varchar(2)) END;


END;
$$;

ALTER FUNCTION neb.fn_calculardigvercodbarras(varchar) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.fn_calculardigvercodbarras(character varying) TO nebgp_usuario_servico with GRANT option;

GRANT EXECUTE ON FUNCTION neb.fn_calculardigvercodbarras(character varying) TO nebgp_desenvolvedor with GRANT option;

CREATE OR REPLACE FUNCTION neb.fn_cod_barras_hab(v_contrato_numero bigint, v_data_vencimento date) returns character varying
    language plpgsql
AS
$$
DECLARE

    v_digito_ctr                       int;
    v_numero                           varchar(20);
    v_contador                         bigint;
    v_soma                             bigint;
    v_multiplicador                    bigint;
    v_cedente                          varchar(20);
    v_digito_cedente                   bigint;
    v_resto                            bigint;
    v_mes_atraso                       varchar(2);
    v_ano_atraso                       varchar(2);
    v_data_atraso                      varchar(20);
    v_ncpd_invertido                   varchar(4);
    v_soma_ncpd_invertido              bigint;
    v_digito_ncpd                      varchar(1);
    v_nosso_numero_hab                 varchar(10);
    v_p1lndigitavel                    varchar(100);
    v_soma_ln_digitavel                bigint;
    v_controlador_ln_digitavel         bigint;
    v_segundo_controlador_ln_digitavel bigint;
    v_digito_ln1                       bigint;
    v_digito_ln2                       bigint;
    v_p2lndigitavel                    varchar(100);
    v_p3lndigitavel                    varchar(100);
    v_digito_ln3                       bigint;
    v_linha_digitavel_variavel         varchar(150);
    v_variavel_teste                   varchar(200);
    v_data_base                        date;
    v_numero_temp                      varchar(200);
    v_valor_doc                        varchar(10);
    v_fator_vencimento                 varchar(4);
    --v_data_vencimento date;
    v_valor_boleto                     numeric(13, 2);
    v_data_atual                       date;
    v_digito_geral                     varchar(1);
    v_numeracao_cod_barras             varchar(200);
    v_digito_nosso_numero              varchar(1);

BEGIN

    --###########################################
--##	ACHAR CEDENTE   ##
--###########################################

    v_cedente = (select neb.fn_calcula_cedente_hab(v_contrato_numero));


    --###########################################
--##	ACHAR NOSSO NUMERO   ##
--###########################################

    v_nosso_numero_hab = left((select neb.fn_proxnossonumero_hab(v_contrato_numero)), 10);


    --###########################################
--##	ACHAR PARTE 1 DA LINHA DIGITAVEL   ##
--###########################################


    v_P1LNDIGITAVEL = '1049' || SUBSTRING(v_NOSSO_NUMERO_HAB, 1, 5);


    v_CONTADOR = 9;
    v_MULTIPLICADOR = 2;
    v_SOMA_LN_DIGITAVEL = 0;


    WHILE v_CONTADOR > 0
        LOOP

            v_CONTROLADOR_LN_DIGITAVEL =
                        CAST(SUBSTRING(v_P1LNDIGITAVEL, CAST(v_CONTADOR AS integer), 1) AS bigint) * v_MULTIPLICADOR;


            IF v_CONTROLADOR_LN_DIGITAVEL > 9 THEN
                v_CONTROLADOR_LN_DIGITAVEL = CAST(LEFT(CAST(v_CONTROLADOR_LN_DIGITAVEL AS text), 1) AS bigint) +
                                             CAST(RIGHT(CAST(v_CONTROLADOR_LN_DIGITAVEL AS text), 1) AS bigint);
            END IF;--REFERENTE AO IF @CONTROLADOR_LN_DIGITAVEL>9

            v_SOMA_LN_DIGITAVEL = v_SOMA_LN_DIGITAVEL + v_CONTROLADOR_LN_DIGITAVEL;

            IF v_MULTIPLICADOR = 2 THEN
                v_MULTIPLICADOR = 1;
            ELSE
                v_MULTIPLICADOR = 2;
            END IF;

            v_CONTADOR = v_CONTADOR - 1;
        END LOOP; -- END REFERENTE AO WHILE DA PARTE 1 DA LINHA DIGITAVEL


    IF V_SOMA_LN_DIGITAVEL < 10 THEN
        v_SEGUNDO_CONTROLADOR_LN_DIGITAVEL = 10;
    ELSE
        v_SEGUNDO_CONTROLADOR_LN_DIGITAVEL = 10 * (CAST(left(CAST(v_SOMA_LN_DIGITAVEL AS text), 1) AS bigint) + 1);
    END IF;

    v_DIGITO_LN1 = v_SEGUNDO_CONTROLADOR_LN_DIGITAVEL - v_SOMA_LN_DIGITAVEL;

    IF v_DIGITO_LN1 = 10 THEN
        v_DIGITO_LN1 = 0;
    END IF;

    v_P1LNDIGITAVEL = v_P1LNDIGITAVEL || CAST(v_DIGITO_LN1 AS text);


    --###########################################
--##	ACHAR PARTE 2 DA LINHA DIGITAVEL   ##
--###########################################

    v_P2LNDIGITAVEL = SUBSTRING(v_NOSSO_NUMERO_HAB, 6, 5) || SUBSTRING(v_CEDENTE, 1, 5);

    v_CONTADOR = 10;
    v_MULTIPLICADOR = 2;
    v_SOMA_LN_DIGITAVEL = 0;

    WHILE v_CONTADOR > 0
        LOOP

            v_CONTROLADOR_LN_DIGITAVEL =
                        CAST(SUBSTRING(v_P2LNDIGITAVEL, CAST(v_CONTADOR AS integer), 1) AS bigint) * v_MULTIPLICADOR;


            IF v_CONTROLADOR_LN_DIGITAVEL > 9 THEN
                v_CONTROLADOR_LN_DIGITAVEL = CAST(LEFT(CAST(v_CONTROLADOR_LN_DIGITAVEL AS text), 1) AS bigint) +
                                             CAST(RIGHT(CAST(v_CONTROLADOR_LN_DIGITAVEL AS text), 1) AS bigint);
            END IF; --REFERENTE AO IF @CONTROLADOR_LN_DIGITAVEL>9


            v_SOMA_LN_DIGITAVEL = v_SOMA_LN_DIGITAVEL + v_CONTROLADOR_LN_DIGITAVEL;

            IF v_MULTIPLICADOR = 2 THEN
                v_MULTIPLICADOR = 1;
            ELSE
                v_MULTIPLICADOR = 2;
            END IF;

            v_CONTADOR = v_CONTADOR - 1;
        END LOOP; -- END REFERENTE AO WHILE DA PARTE 2 DA LINHA DIGITAVEL


    IF v_SOMA_LN_DIGITAVEL < 10 THEN
        v_SEGUNDO_CONTROLADOR_LN_DIGITAVEL = 10;
    ELSE
        v_SEGUNDO_CONTROLADOR_LN_DIGITAVEL = 10 * (CAST(LEFT(CAST(v_SOMA_LN_DIGITAVEL AS text), 1) AS bigint) + 1);
    END IF;

    v_DIGITO_LN2 = v_SEGUNDO_CONTROLADOR_LN_DIGITAVEL - v_SOMA_LN_DIGITAVEL;

    IF v_DIGITO_LN2 = 10 THEN
        v_DIGITO_LN2 = 0;
    END IF;

    v_P2LNDIGITAVEL = v_P2LNDIGITAVEL || CAST(v_DIGITO_LN2 AS VARCHAR(1));


    --########################################################
--##	ACHAR VARIAVEL QUE ANTECEDE A LINHA DIGITAVEL   ##
--########################################################

    V_P3LNDIGITAVEL = SUBSTRING(V_CEDENTE, 6, 10);


    v_CONTADOR = 10;
    v_MULTIPLICADOR = 2;
    v_SOMA_LN_DIGITAVEL = 0;
    v_VARIAVEL_TESTE = '';


    WHILE v_CONTADOR > 0
        LOOP

            v_CONTROLADOR_LN_DIGITAVEL =
                        CAST(SUBSTRING(v_P3LNDIGITAVEL, CAST(v_CONTADOR AS integer), 1) AS bigint) * v_MULTIPLICADOR;


            IF v_CONTROLADOR_LN_DIGITAVEL > 9 THEN
                v_CONTROLADOR_LN_DIGITAVEL = CAST(LEFT(CAST(v_CONTROLADOR_LN_DIGITAVEL AS text), 1) AS bigint) +
                                             CAST(RIGHT(CAST(v_CONTROLADOR_LN_DIGITAVEL AS text), 1) AS bigint);
            END IF; --REFERENTE AO IF @CONTROLADOR_LN_DIGITAVEL>9

            v_SOMA_LN_DIGITAVEL = v_SOMA_LN_DIGITAVEL + v_CONTROLADOR_LN_DIGITAVEL;


            IF v_MULTIPLICADOR = 2 THEN
                v_MULTIPLICADOR = 1;
            ELSE
                v_MULTIPLICADOR = 2;
            END IF;

            v_CONTADOR = v_CONTADOR - 1;
        END LOOP; -- END REFERENTE AO WHILE DA PARTE 2 DA LINHA DIGITAVEL


    IF v_SOMA_LN_DIGITAVEL < 10 THEN
        v_SEGUNDO_CONTROLADOR_LN_DIGITAVEL = 10;
    ELSE
        v_SEGUNDO_CONTROLADOR_LN_DIGITAVEL = 10 * ((CAST(LEFT(CAST(v_SOMA_LN_DIGITAVEL AS text), 1) AS bigint)) + 1);
    END IF;

    v_DIGITO_LN3 = v_SEGUNDO_CONTROLADOR_LN_DIGITAVEL - v_SOMA_LN_DIGITAVEL;

    IF v_DIGITO_LN3 = 10 THEN
        v_DIGITO_LN3 = 0;
    END IF;

    v_P3LNDIGITAVEL = v_P3LNDIGITAVEL || CAST(v_DIGITO_LN3 AS VARCHAR(1));

    v_LINHA_DIGITAVEL_VARIAVEL = v_P1LNDIGITAVEL || v_P2LNDIGITAVEL || v_P3LNDIGITAVEL;


    --######################################################################
--##	TRANSFORMAR LINHA VARIAVEL EM LINHA DIGITAVEL/COD DE BARRAS   ##
--######################################################################


    v_DATA_BASE = CAST('1997-10-07' AS date);

    select contrato_val_ca AS valor
    into v_valor_boleto
    from neb.hab_boleto_dados
    where contrato_numero = v_contrato_numero;


    -- 10 CHAR
    v_VALOR_DOC = lpad((CAST(floor(v_VALOR_BOLETO) AS text) || '55'), 10, '0');

    -- 4 CHAR
    v_FATOR_VENCIMENTO = CAST((v_DATA_VENCIMENTO - v_DATA_BASE) AS text);
    -- verificar

    --O @NUMERO_TEMP É A BASE PARA CALCULAR O DÍGITO GERAL DA LINHA DIGITÁVEL
    v_NUMERO_TEMP = '1049' || v_FATOR_VENCIMENTO || v_VALOR_DOC || LEFT(v_NOSSO_NUMERO_HAB, 10) || LEFT(v_CEDENTE, 15);

    --########### CÁLCULO DO DÍGITO GERAL #############
    v_CONTADOR = 43;
    v_MULTIPLICADOR = 2;
    v_SOMA = 0;


    WHILE v_CONTADOR > 0
        LOOP

            v_SOMA = v_SOMA + (CAST(SUBSTRING(v_NUMERO_TEMP, CAST(v_CONTADOR AS int), 1) AS INT) * v_MULTIPLICADOR);

            --VERIFICAR MULTIPLICADOR
            IF v_MULTIPLICADOR = 9 THEN
                v_MULTIPLICADOR = 2;
            ELSE
                v_MULTIPLICADOR = v_MULTIPLICADOR + 1;
            END IF;
            v_CONTADOR = v_CONTADOR - 1;
        END LOOP; -- END REFERENTE AO WHILE DO DÍGITO GERAL


    v_RESTO = 11 - (v_SOMA - ((CAST(floor((v_SOMA / 11)) AS INT)) * 11));


    IF (v_RESTO > 9 or v_RESTO = 0) THEN
        v_DIGITO_GERAL = '1';
    ELSE
        v_DIGITO_GERAL = CAST(v_RESTO AS VARCHAR(1));
    END IF;


    v_LINHA_DIGITAVEL_VARIAVEL = v_LINHA_DIGITAVEL_VARIAVEL || v_DIGITO_GERAL || v_FATOR_VENCIMENTO || v_VALOR_DOC;


    v_NUMERACAO_COD_BARRAS = '1049' || SUBSTRING(v_LINHA_DIGITAVEL_VARIAVEL, 33, 15) || LEFT(v_NOSSO_NUMERO_HAB, 10) ||
                             LEFT(v_CEDENTE, 15);


    RETURN v_NUMERACAO_COD_BARRAS;


END;

$$;

ALTER FUNCTION neb.fn_cod_barras_hab(bigint, date) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.fn_cod_barras_hab(v_contrato_numero bigint, v_data_vencimento date) TO nebgp_usuario_servico with GRANT option;

GRANT EXECUTE ON FUNCTION neb.fn_cod_barras_hab(v_contrato_numero bigint, v_data_vencimento date) TO nebgp_desenvolvedor with GRANT option;

CREATE OR REPLACE FUNCTION neb.fn_datediff(tipo character, dt1 date, dt2 date) returns integer
    language plpgsql
AS
$$
DECLARE
    -- tipo = "d" - dia
    -- tipo = "m" - mês desconsiderando dias
    -- tipo = "n" - mês exato
    -- tipo = "y" - ano
    auxData1    date;
    auxData2    date;
    auxAno      integer;
    auxMes      integer;
    auxMesExato integer;
    auxDia      integer;

BEGIN
    ---------------------------------
    -- a data menor é colocada em auxData1 e data maior em auxData2
    IF (dt1 < dt2) THEN
        auxData1 = dt1;
        auxData2 = dt2;
    ELSE
        auxData1 = dt2;
        auxData2 = dt1;

    END IF;
    ---------------------------------

    ---------------------------------
    -- calcula dia
    auxDia = auxData2 - auxData1;
    ---------------------------------

    ---------------------------------
    --- calcula ano
    auxAno = 0;
    WHILE (auxData1 <= auxData2)
        LOOP
            auxData1 = auxData1 + '1 year'::interval;
            auxAno = auxAno + 1;
        END LOOP;
    IF (auxData1 > auxData2) THEN
        auxAno = auxAno - 1;
        auxData1 = auxData1 + '-1 year'::interval;
    END IF;
    ---------------------------------


    ---------------------------------
    -- calcula mes
    auxMes = 0;
    auxMesExato = 0;
    WHILE (auxData1 <= auxData2)
        LOOP
            auxData1 = auxData1 + '1 month'::interval;
            auxMesExato = auxMesExato + 1;
        END LOOP;

    IF (auxData1 > auxData2) THEN
        auxMesExato = auxMesExato - 1;
    END IF;

    auxMesExato = auxMesExato + 12 * auxAno;
    auxMes = auxMesExato;

    -- ajuste para auxMes ignorando dia
    IF (extract(day from auxData1)::integer > extract(day from auxData2)::integer) THEN
        auxMes = auxMes + 1;
    END IF;
    ---------------------------------

    ---------------------------------
    -- ajuste para negativo de dia/mes/ano anteriores
    IF (dt1 > dt2) THEN
        auxDia = auxDia * -1;
        auxMes = auxMes * -1;
        auxAno = auxAno * -1;
    END IF;
    ---------------------------------

    IF (tipo = 'd') THEN RETURN auxDia; END IF;
    IF (tipo = 'm') THEN RETURN auxMes; END IF;
    IF (tipo = 'n') THEN RETURN auxMesExato; END IF;
    IF (tipo = 'y') THEN RETURN auxAno; END IF;

END;
$$;

ALTER FUNCTION neb.fn_datediff(char, date, date) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.fn_datediff(tipo character, dt1 date, dt2 date) TO nebgp_desenvolvedor with GRANT option;

GRANT EXECUTE ON FUNCTION neb.fn_datediff(tipo character, dt1 date, dt2 date) TO nebgp_usuario_servico with GRANT option;

CREATE OR REPLACE FUNCTION neb.fn_linha_digitavel_hab(v_contrato_numero bigint, v_data_vencimento date) returns character varying
    language plpgsql
AS
$$
DECLARE

    v_digito_ctr                       int;
    v_numero                           varchar(20);
    v_contador                         bigint;
    v_soma                             bigint;
    v_multiplicador                    bigint;
    v_cedente                          varchar(20);
    v_digito_cedente                   bigint;
    v_resto                            bigint;
    v_mes_atraso                       varchar(2);
    v_ano_atraso                       varchar(2);
    v_data_atraso                      varchar(20);
    v_ncpd_invertido                   varchar(4);
    v_soma_ncpd_invertido              bigint;
    v_digito_ncpd                      varchar(1);
    v_nosso_numero_hab                 varchar(10);
    v_p1lndigitavel                    varchar(100);
    v_soma_ln_digitavel                bigint;
    v_controlador_ln_digitavel         bigint;
    v_segundo_controlador_ln_digitavel bigint;
    v_digito_ln1                       bigint;
    v_digito_ln2                       bigint;
    v_p2lndigitavel                    varchar(100);
    v_p3lndigitavel                    varchar(100);
    v_digito_ln3                       bigint;
    v_linha_digitavel_variavel         varchar(150);
    v_variavel_teste                   varchar(200);
    v_data_base                        date;
    v_numero_temp                      varchar(200);
    v_valor_doc                        varchar(10);
    v_fator_vencimento                 varchar(4);
    --v_data_vencimento date;
    v_valor_boleto                     numeric(13, 2);
    v_data_atual                       date;
    v_digito_geral                     varchar(1);
    v_numeracao_cod_barras             varchar(200);
    v_digito_nosso_numero              varchar(1);
    v_linha_digitavel_formatada        varchar(200);


BEGIN

    --###########################################
--##	ACHAR CEDENTE   ##
--###########################################

    v_cedente = (select neb.fn_calcula_cedente_hab(v_contrato_numero));


    --###########################################
--##	ACHAR NOSSO NUMERO   ##
--###########################################

    v_nosso_numero_hab = left((select neb.fn_proxnossonumero_hab(v_contrato_numero)), 10);


    --###########################################
--##	ACHAR PARTE 1 DA LINHA DIGITAVEL   ##
--###########################################


    v_P1LNDIGITAVEL = '1049' || SUBSTRING(v_NOSSO_NUMERO_HAB, 1, 5);


    v_CONTADOR = 9;
    v_MULTIPLICADOR = 2;
    v_SOMA_LN_DIGITAVEL = 0;


    WHILE v_CONTADOR > 0
        LOOP

            v_CONTROLADOR_LN_DIGITAVEL =
                        CAST(SUBSTRING(v_P1LNDIGITAVEL, CAST(v_CONTADOR AS integer), 1) AS bigint) * v_MULTIPLICADOR;


            IF v_CONTROLADOR_LN_DIGITAVEL > 9 THEN
                v_CONTROLADOR_LN_DIGITAVEL = CAST(LEFT(CAST(v_CONTROLADOR_LN_DIGITAVEL AS text), 1) AS bigint) +
                                             CAST(RIGHT(CAST(v_CONTROLADOR_LN_DIGITAVEL AS text), 1) AS bigint);
            END IF;--REFERENTE AO IF @CONTROLADOR_LN_DIGITAVEL>9

            v_SOMA_LN_DIGITAVEL = v_SOMA_LN_DIGITAVEL + v_CONTROLADOR_LN_DIGITAVEL;

            IF v_MULTIPLICADOR = 2 THEN
                v_MULTIPLICADOR = 1;
            ELSE
                v_MULTIPLICADOR = 2;
            END IF;

            v_CONTADOR = v_CONTADOR - 1;
        END LOOP; -- END REFERENTE AO WHILE DA PARTE 1 DA LINHA DIGITAVEL


    IF V_SOMA_LN_DIGITAVEL < 10 THEN
        v_SEGUNDO_CONTROLADOR_LN_DIGITAVEL = 10;
    ELSE
        v_SEGUNDO_CONTROLADOR_LN_DIGITAVEL = 10 * (CAST(left(CAST(v_SOMA_LN_DIGITAVEL AS text), 1) AS bigint) + 1);
    END IF;

    v_DIGITO_LN1 = v_SEGUNDO_CONTROLADOR_LN_DIGITAVEL - v_SOMA_LN_DIGITAVEL;

    IF v_DIGITO_LN1 = 10 THEN
        v_DIGITO_LN1 = 0;
    END IF;

    v_P1LNDIGITAVEL = v_P1LNDIGITAVEL || CAST(v_DIGITO_LN1 AS text);


    --###########################################
--##	ACHAR PARTE 2 DA LINHA DIGITAVEL   ##
--###########################################

    v_P2LNDIGITAVEL = SUBSTRING(v_NOSSO_NUMERO_HAB, 6, 5) || SUBSTRING(v_CEDENTE, 1, 5);

    v_CONTADOR = 10;
    v_MULTIPLICADOR = 2;
    v_SOMA_LN_DIGITAVEL = 0;

    WHILE v_CONTADOR > 0
        LOOP

            v_CONTROLADOR_LN_DIGITAVEL =
                        CAST(SUBSTRING(v_P2LNDIGITAVEL, CAST(v_CONTADOR AS integer), 1) AS bigint) * v_MULTIPLICADOR;


            IF v_CONTROLADOR_LN_DIGITAVEL > 9 THEN
                v_CONTROLADOR_LN_DIGITAVEL = CAST(LEFT(CAST(v_CONTROLADOR_LN_DIGITAVEL AS text), 1) AS bigint) +
                                             CAST(RIGHT(CAST(v_CONTROLADOR_LN_DIGITAVEL AS text), 1) AS bigint);
            END IF; --REFERENTE AO IF @CONTROLADOR_LN_DIGITAVEL>9


            v_SOMA_LN_DIGITAVEL = v_SOMA_LN_DIGITAVEL + v_CONTROLADOR_LN_DIGITAVEL;

            IF v_MULTIPLICADOR = 2 THEN
                v_MULTIPLICADOR = 1;
            ELSE
                v_MULTIPLICADOR = 2;
            END IF;

            v_CONTADOR = v_CONTADOR - 1;
        END LOOP; -- END REFERENTE AO WHILE DA PARTE 2 DA LINHA DIGITAVEL


    IF v_SOMA_LN_DIGITAVEL < 10 THEN
        v_SEGUNDO_CONTROLADOR_LN_DIGITAVEL = 10;
    ELSE
        v_SEGUNDO_CONTROLADOR_LN_DIGITAVEL = 10 * (CAST(LEFT(CAST(v_SOMA_LN_DIGITAVEL AS text), 1) AS bigint) + 1);
    END IF;

    v_DIGITO_LN2 = v_SEGUNDO_CONTROLADOR_LN_DIGITAVEL - v_SOMA_LN_DIGITAVEL;

    IF v_DIGITO_LN2 = 10 THEN
        v_DIGITO_LN2 = 0;
    END IF;

    v_P2LNDIGITAVEL = v_P2LNDIGITAVEL || CAST(v_DIGITO_LN2 AS VARCHAR(1));


    --########################################################
--##	ACHAR VARIAVEL QUE ANTECEDE A LINHA DIGITAVEL   ##
--########################################################

    V_P3LNDIGITAVEL = SUBSTRING(V_CEDENTE, 6, 10);


    v_CONTADOR = 10;
    v_MULTIPLICADOR = 2;
    v_SOMA_LN_DIGITAVEL = 0;
    v_VARIAVEL_TESTE = '';


    WHILE v_CONTADOR > 0
        LOOP

            v_CONTROLADOR_LN_DIGITAVEL =
                        CAST(SUBSTRING(v_P3LNDIGITAVEL, CAST(v_CONTADOR AS integer), 1) AS bigint) * v_MULTIPLICADOR;


            IF v_CONTROLADOR_LN_DIGITAVEL > 9 THEN
                v_CONTROLADOR_LN_DIGITAVEL = CAST(LEFT(CAST(v_CONTROLADOR_LN_DIGITAVEL AS text), 1) AS bigint) +
                                             CAST(RIGHT(CAST(v_CONTROLADOR_LN_DIGITAVEL AS text), 1) AS bigint);
            END IF; --REFERENTE AO IF @CONTROLADOR_LN_DIGITAVEL>9

            v_SOMA_LN_DIGITAVEL = v_SOMA_LN_DIGITAVEL + v_CONTROLADOR_LN_DIGITAVEL;


            IF v_MULTIPLICADOR = 2 THEN
                v_MULTIPLICADOR = 1;
            ELSE
                v_MULTIPLICADOR = 2;
            END IF;

            v_CONTADOR = v_CONTADOR - 1;
        END LOOP; -- END REFERENTE AO WHILE DA PARTE 2 DA LINHA DIGITAVEL


    IF v_SOMA_LN_DIGITAVEL < 10 THEN
        v_SEGUNDO_CONTROLADOR_LN_DIGITAVEL = 10;
    ELSE
        v_SEGUNDO_CONTROLADOR_LN_DIGITAVEL = 10 * ((CAST(LEFT(CAST(v_SOMA_LN_DIGITAVEL AS text), 1) AS bigint)) + 1);
    END IF;

    v_DIGITO_LN3 = v_SEGUNDO_CONTROLADOR_LN_DIGITAVEL - v_SOMA_LN_DIGITAVEL;

    IF v_DIGITO_LN3 = 10 THEN
        v_DIGITO_LN3 = 0;
    END IF;

    v_P3LNDIGITAVEL = v_P3LNDIGITAVEL || CAST(v_DIGITO_LN3 AS VARCHAR(1));

    v_LINHA_DIGITAVEL_VARIAVEL = v_P1LNDIGITAVEL || v_P2LNDIGITAVEL || v_P3LNDIGITAVEL;


    --######################################################################
--##	TRANSFORMAR LINHA VARIAVEL EM LINHA DIGITAVEL/COD DE BARRAS   ##
--######################################################################


    v_DATA_BASE = CAST('1997-10-07' AS date);

    select contrato_val_ca AS valor
    into v_valor_boleto
    from neb.hab_boleto_dados
    where contrato_numero = v_contrato_numero;


    -- 10 CHAR
    v_VALOR_DOC = lpad((CAST(floor(v_VALOR_BOLETO) AS text) || '55'), 10, '0');

    -- 4 CHAR
    v_FATOR_VENCIMENTO = CAST((v_DATA_VENCIMENTO - v_DATA_BASE) AS text);
    -- verificar

    --O @NUMERO_TEMP É A BASE PARA CALCULAR O DÍGITO GERAL DA LINHA DIGITÁVEL
    v_NUMERO_TEMP = '1049' || v_FATOR_VENCIMENTO || v_VALOR_DOC || LEFT(v_NOSSO_NUMERO_HAB, 10) || LEFT(v_CEDENTE, 15);

    --########### CÁLCULO DO DÍGITO GERAL #############
    v_CONTADOR = 43;
    v_MULTIPLICADOR = 2;
    v_SOMA = 0;


    WHILE v_CONTADOR > 0
        LOOP

            v_SOMA = v_SOMA + (CAST(SUBSTRING(v_NUMERO_TEMP, CAST(v_CONTADOR AS int), 1) AS INT) * v_MULTIPLICADOR);

            --VERIFICAR MULTIPLICADOR
            IF v_MULTIPLICADOR = 9 THEN
                v_MULTIPLICADOR = 2;
            ELSE
                v_MULTIPLICADOR = v_MULTIPLICADOR + 1;
            END IF;
            v_CONTADOR = v_CONTADOR - 1;
        END LOOP; -- END REFERENTE AO WHILE DO DÍGITO GERAL


    v_RESTO = 11 - (v_SOMA - ((CAST(floor((v_SOMA / 11)) AS INT)) * 11));


    IF (v_RESTO > 9 or v_RESTO = 0) THEN
        v_DIGITO_GERAL = '1';
    ELSE
        v_DIGITO_GERAL = CAST(v_RESTO AS VARCHAR(1));
    END IF;


    v_LINHA_DIGITAVEL_VARIAVEL = v_LINHA_DIGITAVEL_VARIAVEL || v_DIGITO_GERAL || v_FATOR_VENCIMENTO || v_VALOR_DOC;


    v_linha_digitavel_formatada = left(v_LINHA_DIGITAVEL_VARIAVEL, 5) || '.' ||
                                  substring(v_LINHA_DIGITAVEL_VARIAVEL, 6, 5) || ' ' ||
                                  substring(v_LINHA_DIGITAVEL_VARIAVEL, 11, 5) || '.' ||
                                  substring(v_LINHA_DIGITAVEL_VARIAVEL, 16, 6) || ' ' ||
                                  substring(v_LINHA_DIGITAVEL_VARIAVEL, 22, 5) || '.' ||
                                  substring(v_LINHA_DIGITAVEL_VARIAVEL, 27, 6) || ' ' ||
                                  substring(v_LINHA_DIGITAVEL_VARIAVEL, 33, 1) || ' ' ||
                                  substring(v_LINHA_DIGITAVEL_VARIAVEL, 34, 14);


/*
	v_NUMERACAO_COD_BARRAS= '1049' || SUBSTRING(v_LINHA_DIGITAVEL_VARIAVEL, 33, 15) || LEFT(v_NOSSO_NUMERO_HAB,10) || LEFT(v_CEDENTE,15);

*/


    RETURN v_linha_digitavel_formatada;


END;

$$;

ALTER FUNCTION neb.fn_linha_digitavel_hab(bigint, date) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.fn_linha_digitavel_hab(v_contrato_numero bigint, v_data_vencimento date) TO nebgp_usuario_servico with GRANT option;

GRANT EXECUTE ON FUNCTION neb.fn_linha_digitavel_hab(v_contrato_numero bigint, v_data_vencimento date) TO nebgp_desenvolvedor with GRANT option;

CREATE OR REPLACE FUNCTION neb.fn_montarcodbarras(character varying, character varying, numeric, date,
                                              character varying) returns character varying
    language plpgsql
AS
$$
DECLARE

    strBanco ALIAS FOR $1;
    strMoeda ALIAS FOR $2;
    numValor ALIAS FOR $3;
    dtVencimento ALIAS FOR $4; -- usar NULL para nÃ£o ter vencimento (nÃ£o aconselhÃ¡vel)
    strLivre ALIAS FOR $5;
    codigo_sequencia varchar(50);
    data_base        date;
    fator            Integer;
    intDac           Integer;
    numValorAux      Integer;
    dtVencimentoAux  varchar(4);

BEGIN

    data_base = to_date('7/10/1997', 'DD/MM/YYYY');
    IF dtVencimento is null THEN
        dtVencimento = data_base;
    END IF;
--dtVencimentoAux = CAST(DateDiff(d, data_base, dtVencimento) AS nvarchar(4));
    dtVencimentoAux = CAST(dtVencimento - data_base AS varchar(4));


    numValorAux = CAST(numValor * 100 AS integer);
    strLivre = right('0000000000000000000000000' || strLivre, 25);


-- sequencia sem o DV
    codigo_sequencia = strBanco || strMoeda || dtVencimentoAux ||
                       right('0000000000' || CAST(numValorAux AS varchar(10)), 10) || strLivre;

-- calculo do DV
    intDac = fn_calcularDigVerCodBarras(codigo_sequencia);


-- monta a sequencia para o codigo de barras com o DV
    RETURN substring(codigo_sequencia, 1, 4) || CAST(@intDac AS char(1)) || substring(codigo_sequencia, 5, 39);

END;

$$;

ALTER FUNCTION neb.fn_montarcodbarras(varchar, varchar, numeric, date, varchar) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.fn_montarcodbarras(character varying, character varying, numeric, date, character varying) TO nebgp_usuario_servico with GRANT option;

GRANT EXECUTE ON FUNCTION neb.fn_montarcodbarras(character varying, character varying, numeric, date, character varying) TO nebgp_desenvolvedor with GRANT option;

CREATE OR REPLACE FUNCTION neb.fn_montarcodbarraslinhadig(character varying, boolean) returns character varying
    language plpgsql
AS
$$
DECLARE
    strSeq ALIAS FOR $1;
    formatada ALIAS FOR $2;
    seq1 varchar(11);
    seq2 varchar(12);
    seq3 varchar(12);
    seq4 varchar(14);
    dvcb varchar(1);
    dv1  varchar(1);
    dv2  varchar(1);
    dv3  varchar(1);

BEGIN

    seq1 := Left(strSeq, 4) || substring(strSeq, 20, 5);
    seq2 := substring(strSeq, 25, 10);
    seq3 := substring(strSeq, 35, 10);
    seq4 := substring(strSeq, 6, 14);
    dvcb := substring(strSeq, 5, 1);

    dv1 := fn_CalcularDigVer10(seq1);
    dv2 := fn_CalcularDigVer10(seq2);
    dv3 := fn_CalcularDigVer10(seq3);


    seq1 := Left(seq1 || dv1, 5) || CASE WHEN formatada = true THEN '.' ELSE '' END || substring(seq1 || dv1, 6, 5);
    seq2 := Left(seq2 || dv2, 5) || CASE WHEN formatada = true THEN '.' ELSE '' END || substring(seq2 || dv2, 6, 6);
    seq3 := Left(seq3 || dv3, 5) || CASE WHEN formatada = true THEN '.' ELSE '' END || substring(seq3 || dv3, 6, 6);


    RETURN seq1 || CASE WHEN formatada = true THEN ' ' ELSE '' END || seq2 ||
           CASE WHEN formatada = true THEN ' ' ELSE '' END || seq3 || CASE WHEN formatada = true THEN ' ' ELSE '' END ||
           dvcb || CASE WHEN formatada = true THEN ' ' ELSE '' END || seq4;

END;

$$;

ALTER FUNCTION neb.fn_montarcodbarraslinhadig(varchar, boolean) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.fn_montarcodbarraslinhadig(character varying, boolean) TO nebgp_usuario_servico with GRANT option;

GRANT EXECUTE ON FUNCTION neb.fn_montarcodbarraslinhadig(character varying, boolean) TO nebgp_desenvolvedor with GRANT option;

CREATE OR REPLACE FUNCTION neb.fn_montarlivre(character varying) returns character varying
    language plpgsql
AS
$$
DECLARE
    strNossoNumero ALIAS FOR $1;
    cod_Cedente varchar(15);
    resultado   varchar(24);
BEGIN
    cod_Cedente = '249087000000032';
    resultado = Right(cod_Cedente, 4) || Left(Right('00000' || cod_Cedente, 15), 6) || Right(strNossoNumero, 14);
    RETURN resultado;
END


$$;

ALTER FUNCTION neb.fn_montarlivre(varchar) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.fn_montarlivre(character varying) TO nebgp_desenvolvedor with GRANT option;

GRANT EXECUTE ON FUNCTION neb.fn_montarlivre(character varying) TO nebgp_usuario_servico with GRANT option;

CREATE OR REPLACE FUNCTION neb.fn_proxnossonumero(bigint, character) returns character varying
    language plpgsql
AS
$$
DECLARE
    v_cpf_cnpj ALIAS FOR $1;
    v_origem ALIAS FOR $2;
    v_ultimo_nossonumero bigint;
    v_novo_nossonumero   bigint;
    v_tipo_cliente       int;
    v_parte1             varchar(20);
    v_parte2             varchar(20);
    v_parte3             varchar(20);
    v_parte4             varchar(20);
    v_parte5             varchar(20);
    v_auxTxt             varchar(100);
    v_auxBigInt          bigint;
    v_r                  record;
BEGIN
    select max(contrato_cliente_tipo_cod) AS tipo_pessoa
    into v_tipo_cliente
    from neb.VW_COM_BOLETO_DADOS
    where contrato_cpf_cnpj = v_cpf_cnpj;
    IF coalesce(v_tipo_cliente, 0) = 0 THEN
        RETURN null;
    END IF;

    SELECT MAX(BOLETO_NOSSO_NUMERO) AS ultimo_nosso_numero
    into v_ultimo_nossonumero
    FROM neb.COM_BOLETO_CLIENTE
    WHERE BOLETO_CPF_CNPJ = v_cpf_cnpj
      and BOLETO_NOSSO_NUMERO::varchar ~~ ('__________' || v_origem || '_____')::varchar;


    -------------------------
    -- 1Âª parte: digito 8
    v_parte1 = '8';
    -------------------------
    -- 2Âª parte: [ 9 primeiros dÃ­gitos do CPF(11 digitos totais) ou CNPJ(14 digitos totais) ]
    v_parte2 = left(
            CASE
                WHEN v_tipo_cliente = 1 THEN right('00000000000000' || v_cpf_cnpj::varchar, 11)
                WHEN v_tipo_cliente = 2 THEN right('00000000000000' || v_cpf_cnpj::varchar, 14)
                ELSE '00000000000000' END
        , 9);
    -------------------------
    -- 3Âª parte: [ 0 para Caixa ou 1 para ECT ]
    v_parte3 = v_origem;
    -------------------------
    -- 4Âª parte: [ 3 digitos sequenciais, de 000 a 999 ]
    v_auxTxt = coalesce(v_ultimo_nossonumero::varchar, '');
    v_auxTxt = substring(v_auxTxt, 12, 3);
    v_auxBigInt = ('0' || v_auxTxt)::bigint;
    v_auxBigInt = v_auxBigInt + 1;
    v_auxTxt = v_auxBigInt::varchar;
    v_auxTxt = right('000' || v_auxTxt, 3);
    v_parte4 = v_auxTxt;
    IF v_parte4 = '000' THEN
        RETURN '-1';
    END IF;
    -------------------------
    -- 5Âª parte: [1 para PF ou 2 para PJ]
    v_parte5 = v_tipo_cliente;
    -------------------------
    -- nosso numero e [DV do Nosso NÃºmero]
    v_novo_nossonumero = v_parte1 || v_parte2 || v_parte3 || v_parte4 || v_parte5 ||
                         neb.fn_calcularDigVer11(v_parte1 || v_parte2 || v_parte3 || v_parte4 || v_parte5);
    -------------------------

    RETURN v_novo_nossonumero;

END;

$$;

ALTER FUNCTION neb.fn_proxnossonumero(bigint, char) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.fn_proxnossonumero(bigint, character) TO nebgp_desenvolvedor with GRANT option;

GRANT EXECUTE ON FUNCTION neb.fn_proxnossonumero(bigint, character) TO nebgp_usuario_servico with GRANT option;

CREATE OR REPLACE FUNCTION neb.fn_proxnossonumero_hab(bigint) returns character varying
    language plpgsql
AS
$$
DECLARE
    v_contrato_numero ALIAS FOR $1;
    v_digito_ctr                       int;
    v_numero                           varchar(20);
    v_contador                         int;
    v_soma                             bigint;
    v_multiplicador                    bigint;
    v_cedente                          varchar(20);
    v_digito_cedente                   bigint;
    v_resto                            bigint;
    v_mes_atraso                       varchar(2);
    v_ano_atraso                       varchar(2);
    v_data_atraso                      varchar(20);
    v_ncpd_invertido                   varchar(4);
    v_soma_ncpd_invertido              bigint;
    v_digito_ncpd                      varchar(1);
    v_nosso_numero_hab                 varchar(11);
    v_p1lndigitavel                    varchar(100);
    v_soma_ln_digitavel                bigint;
    v_controlador_ln_digitavel         bigint;
    v_segundo_controlador_ln_digitavel bigint;
    v_digito_ln1                       bigint;
    v_digito_ln2                       bigint;
    v_p2lndigitavel                    varchar(100);
    v_p3lndigitavel                    varchar(100);
    v_digito_ln3                       bigint;
    v_linha_digitavel_variavel         varchar(150);
    v_variavel_teste                   varchar(200);
    v_data_base                        date;
    v_numero_temp                      varchar(200);
    v_valor_doc                        varchar(10);
    v_fator_vencimento                 varchar(4);
    v_data_vencimento                  date;
    v_valor_boleto                     int;
    v_data_atual                       date;
    v_digito_geral                     varchar(1);
    v_numeracao_cod_barr               varchar(200);
    v_digito_nosso_numero              int;
--	v_mes varchar(2);

BEGIN

    SELECT right(CAST(DATE_PART('YEAR', (-CONTRATO_DIAS_ATRASO + contrato_data_ca)) AS text), 2) AS ano_atraso
    into v_ano_atraso
    FROM neb.hab_boleto_dados
    WHERE contrato_numero = v_contrato_numero;

    SELECT CAST(DATE_PART('month', (-CONTRATO_DIAS_ATRASO + contrato_data_ca)) AS text) AS mes_atraso
    into v_mes_atraso
    FROM neb.hab_boleto_dados
    WHERE contrato_numero = v_contrato_numero;

    SELECT CAST((-CONTRATO_DIAS_ATRASO) + contrato_data_ca AS text) AS data_atraso
    into v_data_atraso
    FROM neb.hab_boleto_dados
    WHERE contrato_numero = v_contrato_numero;

    -- nãétilizado
--v_DATA_ATRASO = to_char(v_DATA_ATRASO, 'DD/MM/YYYY');

--v_DATA_ATRASO=RIGHT('00'+CONVERT(VARCHAR(2),DAY(v_DATA_ATRASO)),2)+'/'+v_MES_ATRASO+'/20'+v_ANO_ATRASO

    IF CAST(v_mes_atraso AS int) < 10 THEN
        v_mes_atraso = '0' || CAST(v_mes_atraso AS text);
    ELSE
        v_mes_atraso = CAST(v_mes_atraso AS text);
    END IF;

    v_ncpd_invertido = v_ANO_ATRASO || v_mes_atraso;


    v_SOMA_NCPD_INVERTIDO = (CAST(LEFT(v_ANO_ATRASO, 1) AS bigint) * 3)
        + (CAST(RIGHT(v_ANO_ATRASO, 1) AS bigint))
        + (CAST(LEFT(v_MES_ATRASO, 1) AS bigint) * 8)
        + (CAST(RIGHT(v_MES_ATRASO, 1) AS bigint) * 3);


    v_DIGITO_NCPD = RIGHT(CAST((v_SOMA_NCPD_INVERTIDO + 12) AS text), 1);


    v_NOSSO_NUMERO_HAB = CAST(v_NCPD_INVERTIDO AS text) || v_DIGITO_NCPD || '31000';


    v_MULTIPLICADOR = 2;
    v_CONTADOR = 10;
    v_SOMA = 0;


    WHILE v_CONTADOR > 0
        LOOP

            v_SOMA = v_SOMA + (CAST(SUBSTRING(v_NOSSO_NUMERO_HAB FROM CAST(v_contador AS int) FOR 1) AS bigint) *
                               v_MULTIPLICADOR);

            --VERIFICAR MULTIPLICADOR
            IF v_MULTIPLICADOR = 9 THEN
                v_MULTIPLICADOR = 2 ;
            ELSE
                v_MULTIPLICADOR = v_MULTIPLICADOR + 1;
            END IF;

            v_CONTADOR = v_CONTADOR - 1;
        END LOOP;
    -- END REFERENTE AO WHILE DO DIGITO DO NOSSO NUMERO


--CALCULA DIGITO ATRAVES DA SOMA DA 1ª PARTE ATRAVES DA SOMA
--OBS: UTILIZANDO A FUNÇO FLOOR PORQUE O ROUND NO POSTGRES NAO SE CONFIGURA PRA PUXAR PRA CIMA OU BAIXO
    v_RESTO = v_SOMA - ((CAST(FLOOR((v_SOMA / 11)) AS INT)) * 11);


    v_DIGITO_NOSSO_NUMERO = 11 - v_RESTO;


    IF (v_DIGITO_NOSSO_NUMERO > 9) THEN
        v_DIGITO_NOSSO_NUMERO = 0 ;
    END IF;

    v_NOSSO_NUMERO_HAB = v_NOSSO_NUMERO_HAB || v_DIGITO_NOSSO_NUMERO;


    RETURN v_NOSSO_NUMERO_HAB;


END;

$$;

ALTER FUNCTION neb.fn_proxnossonumero_hab(bigint) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.fn_proxnossonumero_hab(bigint) TO nebgp_desenvolvedor with GRANT option;

GRANT EXECUTE ON FUNCTION neb.fn_proxnossonumero_hab(bigint) TO nebgp_usuario_servico with GRANT option;

CREATE OR REPLACE FUNCTION neb.fn_proxnossonumero_sigcb(bigint, character) returns character varying
    language plpgsql
AS
$$
DECLARE
    v_cpf_cnpj ALIAS FOR $1;
    v_origem ALIAS FOR $2;
    v_ultimo_nossonumero bigint;
    v_novo_nossonumero   bigint;
    v_tipo_cliente       int;
    v_parte1             varchar(20);
    v_parte2             varchar(20);
    v_parte3             varchar(20);
    v_parte4             varchar(20);
    v_parte5             varchar(20);
    v_auxTxt             varchar(100);
    v_auxTxt_1           varchar(100); --teste
    v_auxBigInt          bigint;
    v_r                  record;
BEGIN
    select max(contrato_cliente_tipo_cod) AS tipo_pessoa
    into v_tipo_cliente
    from neb.COM_BOLETO_DADOS
    where contrato_cpf_cnpj = v_cpf_cnpj;
    IF coalesce(v_tipo_cliente, 0) = 0 THEN
        RETURN null;
    END IF;

    SELECT MAX(BOLETO_NOSSO_NUMERO) AS ultimo_nosso_numero
    into v_ultimo_nossonumero
    FROM neb.COM_BOLETO_CLIENTE
    WHERE BOLETO_CPF_CNPJ = v_cpf_cnpj
      and substring(BOLETO_NOSSO_NUMERO::varchar from 1 FOR 2) = '14';
    --and BOLETO_NOSSO_NUMERO::varchar ~~ ('__________'||v_origem||'_____')::varchar; -- verificar com o joaquim

    -------------------------
    -- 1ª parte: digito 14
    v_parte1 = '14';
    -------------------------
    -- 2ª parte: [ 9 primeiros dígitos do CPF(11 digitos totais) ou CNPJ(14 digitos totais) ]
    v_parte2 = left(
            CASE
                WHEN v_tipo_cliente = 1 THEN right('00000000000000' || v_cpf_cnpj::varchar, 11)
                WHEN v_tipo_cliente = 2 THEN right('00000000000000' || v_cpf_cnpj::varchar, 14)
                ELSE '00000000000000' END
        , 9);
    -------------------------
    -- 3ª parte: [ 0 para Caixa ou 1 para ECT ]
    v_parte3 = v_origem;
    -------------------------
    -- 4ª parte: [ 3 digitos sequenciais, de 000 a 999 ]
    v_auxTxt = coalesce(v_ultimo_nossonumero::varchar, '');
    v_auxTxt_1 = coalesce(v_ultimo_nossonumero::varchar, '');
    v_auxTxt = substring(v_auxTxt, 13, 4);
    v_auxBigInt = ('0' || v_auxTxt)::bigint;
    v_auxBigInt = v_auxBigInt + 1;
    v_auxTxt = v_auxBigInt::varchar;
    v_auxTxt = right('0000' || v_auxTxt, 4);
    v_parte4 = v_auxTxt;
    IF v_parte4 = '0000' THEN
        RETURN '-1';
    END IF;
    -------------------------
    -- 5ª parte: [1 para PF ou 2 para PJ]
    v_parte5 = v_tipo_cliente;
    -------------------------
    -- nosso numero e [DV do Nosso Número]
    v_novo_nossonumero = v_parte1 || v_parte2 || v_parte3 || v_parte4 || v_parte5 ||
                         neb.fn_calcularDigVer11(v_parte1 || v_parte2 || v_parte3 || v_parte4 || v_parte5);
    -------------------------


    /*
	***********************************************************************************************************
	MO 67.119 4.2.4.6 – NOSSO NÚMERO
	***********************************************************************************************************
	- Número de identificação do título, que permite o Banco e o Beneficiário identificar os dados da cobrança
	que deram origem ao boleto.
	- O Nosso Número no SIGCB é composto de 17 posições, sendo AS 02 posições iniciais para identificar a
	Carteira e AS 15 posições restantes são para livre utilização pelo Beneficiário.
	- Formato: XYNNNNNNNNNNNNNNN-D, onde:
	X Modalidade/Carteira de Cobrança (1-Registrada/2-Sem Registro)
	Y Emissão do boleto (4-Beneficiário)
	NNNNNNNNNNNNNNN Nosso Número (15 posições livres do Beneficiário)
	D *Dígito Verificador
	* Dígito Verificador do Nosso Número calculado através do Modulo 11, conforme ANEXO IV.
	Admite 0 (zero), diferentemente do DV Geral do Código de Barras.
	*/


--RETURN v_ultimo_nossonumero;
    RETURN v_novo_nossonumero;

END;

$$;

ALTER FUNCTION neb.fn_proxnossonumero_sigcb(bigint, char) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.fn_proxnossonumero_sigcb(bigint, character) TO nebgp_usuario_servico with GRANT option;

GRANT EXECUTE ON FUNCTION neb.fn_proxnossonumero_sigcb(bigint, character) TO nebgp_desenvolvedor with GRANT option;

CREATE OR REPLACE FUNCTION neb.fn_proxnsu(bigint) returns character varying
    language plpgsql
AS
$$
DECLARE
    v_cpf_cnpj ALIAS FOR $1;
    v_nsu int;

BEGIN
    --select max(nsu_cod)+1 AS nsu from tbl_nsu;
    v_nsu = (select max(nsu_cod) + 1 AS nsu from neb.tbl_nsu);

    insert into neb.tbl_nsu
    values (v_nsu, v_cpf_cnpj, now());


    RETURN v_nsu;

END;

$$;

ALTER FUNCTION neb.fn_proxnsu(bigint) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.fn_proxnsu(bigint) TO nebgp_usuario_servico with GRANT option;

GRANT EXECUTE ON FUNCTION neb.fn_proxnsu(bigint) TO nebgp_desenvolvedor with GRANT option;

CREATE OR REPLACE FUNCTION neb.sp_att_export_estatisticas() returns void
    language plpgsql
AS
$$
DECLARE

BEGIN

    -- FUNÇÃO (SP) copy
    PERFORM sp_atualizacao_copy_to('tbl_estatisticas', 'tbl_estatisticas.txt');
    PERFORM sp_atualizacao_copy_to('com_boleto_proposta', 'com_boleto_proposta.txt');
    PERFORM sp_atualizacao_copy_to('nebtbf51_acordo_ngcco_cartao', 'nebtbf51_acordo_ngcco_cartao.txt');
    PERFORM sp_atualizacao_copy_to('hab_boleto_proposta', 'hab_boleto_proposta.txt');


END;
$$;

ALTER FUNCTION neb.sp_att_export_estatisticas() OWNER TO nebgp_desenvolvedor;

GRANT EXECUTE ON FUNCTION neb.sp_att_export_estatisticas() TO nebgp_usuario_servico with GRANT option;

CREATE OR REPLACE FUNCTION neb.sp_att_export_full(p_tabela_nome character varying) returns void
    security definer
    language plpgsql
AS
$$
DECLARE
    v_sql                       varchar(1000);

    -- variaveis do LOOP
    v_arquivo_id                integer;
    v_arquivo_nome              varchar(100);
    v_sineb_tabela_destino      varchar(100);
    v_sineb_tabela_destino_temp varchar(100);


    --cursor
    cursor_clientes CURSOR FOR SELECT arquivo_id, arquivo_nome, sineb_tabela_destino
                               FROM tbl_atualizacao_arquivos
                               WHERE (p_tabela_nome = '' AND exportar = 1)
                                  OR (p_tabela_nome <> '' AND sineb_tabela_destino = p_tabela_nome)
                                  --sineb_tabela_destino = 'tbl_empct' AND
                                  --carregar = 1
                               ORDER BY ordem
    ;
BEGIN

    OPEN cursor_clientes;
    --
    LOOP
        FETCH cursor_clientes INTO v_arquivo_id, v_arquivo_nome, v_sineb_tabela_destino;
        EXIT WHEN NOT FOUND;


        RAISE NOTICE '% - % - %',v_arquivo_id, v_arquivo_nome, v_sineb_tabela_destino_temp;
        --PERFORM pg_sleep(10);


        -- FUNÇÃO (SP) copy
        PERFORM sp_atualizacao_copy_to(v_sineb_tabela_destino, v_arquivo_nome);


    END LOOP;
    --
    CLOSE cursor_clientes;

END;
$$;

ALTER FUNCTION neb.sp_att_export_full(varchar) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.sp_att_export_full(p_tabela_nome character varying) TO nebgp_usuario_servico with GRANT option;

GRANT EXECUTE ON FUNCTION neb.sp_att_export_full(p_tabela_nome character varying) TO nebgp_desenvolvedor with GRANT option;

CREATE OR REPLACE FUNCTION neb.sp_att_import_atualiza_view_dependente(p_tabela_nome character varying) returns void
    security definer
    language plpgsql
AS
$$
DECLARE
    v_sql            character varying;
    v_view_nome      varchar(100);
    v_view_definicao character varying;
BEGIN

    -- CREATE INDEX
    -- FOR para pegar os indices da tabela
    FOR v_view_nome IN SELECT view_nome
                       FROM tbl_atualizacao_views_dependencia
                       WHERE objeto_nome = p_tabela_nome
                         AND objeto_tipo = 'tb' -- tb: tabela, vw: view
                       GROUP BY view_nome
        LOOP
            v_sql := '';
            -- pegar a definição da view
            v_sql := v_sql || (SELECT view_definicao
                               FROM tbl_atualizacao_views
                               WHERE view_nome = v_view_nome);

            v_sql := v_sql || ';';
            v_sql := v_sql || 'ALTER TABLE ' || v_view_nome || '  OWNER TO sneb001;';

            RAISE NOTICE '%',v_sql;
            EXECUTE v_sql;
        END LOOP;
END;
$$;

ALTER FUNCTION neb.sp_att_import_atualiza_view_dependente(varchar) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.sp_att_import_atualiza_view_dependente(p_tabela_nome character varying) TO nebgp_usuario_servico with GRANT option;

GRANT EXECUTE ON FUNCTION neb.sp_att_import_atualiza_view_dependente(p_tabela_nome character varying) TO nebgp_desenvolvedor with GRANT option;

CREATE OR REPLACE FUNCTION neb.sp_att_import_atualiza_view_dependente_full() returns void
    security definer
    language plpgsql
AS
$$
DECLARE
    v_sql            character varying;
    v_view_nome      character varying(100);
    v_view_definicao character varying;
    v_arquivo_id     integer;
    v_cmd            character varying(300);

    -- cursor
    cursor_carga_view CURSOR FOR SELECT arquivo_id, view_nome, view_definicao
                                 FROM tbl_atualizacao_views
                                 GROUP BY arquivo_id, view_nome, view_definicao
                                 order by arquivo_id ;

BEGIN


    OPEN cursor_carga_view;
    LOOP
        FETCH cursor_carga_view INTO v_arquivo_id, v_view_nome, v_view_definicao;
        EXIT WHEN NOT FOUND;

        RAISE NOTICE '%',v_view_definicao;
        EXECUTE v_view_definicao;
        v_cmd := 'GRANT SELECT ON ' || v_view_nome || ' TO nebgp_owner, sneb001, sneb002';
        EXECUTE v_cmd;
        v_cmd := 'ALTER TABLE neb.' || v_view_nome || ' OWNER TO sneb001';
        EXECUTE v_cmd;

    END LOOP;
    CLOSE cursor_carga_view;


END;
$$;

ALTER FUNCTION neb.sp_att_import_atualiza_view_dependente_full() OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.sp_att_import_atualiza_view_dependente_full() TO nebgp_desenvolvedor with GRANT option;

GRANT EXECUTE ON FUNCTION neb.sp_att_import_atualiza_view_dependente_full() TO nebgp_usuario_servico with GRANT option;

CREATE OR REPLACE FUNCTION neb.sp_att_import_create_constraint(p_tabela_nome character varying, p_tabela_nome_temp character varying) returns void
    security definer
    language plpgsql
AS
$$
DECLARE
    v_sql           varchar(1000);
    v_indice_nome   varchar(100);
    v_indice_coluna varchar(100);
BEGIN

    -- CREATE INDEX
    -- FOR para pegar os indices da tabela
    FOR v_indice_nome IN SELECT indice_nome
                         FROM tbl_atualizacao_tabelas_colunas
                         WHERE tabela_nome = p_tabela_nome
                           AND indice_tipo = 'pk' -- PK
                         GROUP BY indice_nome
        LOOP
            v_sql := '';
            v_sql := v_sql || 'ALTER TABLE ' || p_tabela_nome_temp;
            v_sql := v_sql || ' ADD CONSTRAINT ' || v_indice_nome;
            v_sql := v_sql || ' PRIMARY KEY (';
            -- FOR para pegar AS colunas do indices da tabela
            FOR v_indice_coluna IN SELECT coluna_nome
                                   FROM tbl_atualizacao_tabelas_colunas
                                   WHERE indice_nome = v_indice_nome
                LOOP
                    v_sql := v_sql || v_indice_coluna;
                    v_sql := v_sql || ',';
                END LOOP;

            v_sql := SUBSTR(v_sql, 1, char_length(v_sql) - 1);

            v_sql := v_sql || ') ';
            v_sql := v_sql || ';';
            RAISE NOTICE '%',v_sql;
            EXECUTE v_sql;
        END LOOP;
END;
$$;

ALTER FUNCTION neb.sp_att_import_create_constraint(varchar, varchar) OWNER TO c131481;

CREATE OR REPLACE FUNCTION neb.sp_att_import_create_index(p_tabela_nome character varying, p_tabela_nome_temp character varying) returns void
    security definer
    language plpgsql
AS
$$
DECLARE
    v_sql           varchar(1000);
    v_indice_nome   varchar(100);
    v_indice_coluna varchar(100);
BEGIN

    -- CREATE INDEX
    -- FOR para pegar os indices da tabela
    FOR v_indice_nome IN SELECT indice_nome
                         FROM tbl_atualizacao_tabelas_colunas
                         WHERE tabela_nome = p_tabela_nome
                           AND indice_tipo = 'ix' -- index normal, não PK
                         GROUP BY indice_nome
        LOOP
            v_sql := '';
            v_sql := v_sql || 'CREATE INDEX ' || v_indice_nome;
            v_sql := v_sql || ' ON ' || p_tabela_nome_temp;
            v_sql := v_sql || ' (';
            -- FOR para pegar AS colunas do indices da tabela
            FOR v_indice_coluna IN SELECT coluna_nome
                                   FROM tbl_atualizacao_tabelas_colunas
                                   WHERE indice_nome = v_indice_nome
                LOOP
                    v_sql := v_sql || v_indice_coluna;
                    v_sql := v_sql || ',';
                END LOOP;

            v_sql := SUBSTR(v_sql, 1, char_length(v_sql) - 1);

            v_sql := v_sql || ') ';
            -- v_sql := v_sql || ' TABLESPACE nebtsix001 ';
            v_sql := v_sql || ';';
            RAISE NOTICE '%',v_sql;
            EXECUTE v_sql;
        END LOOP;
END;
$$;

ALTER FUNCTION neb.sp_att_import_create_index(varchar, varchar) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.sp_att_import_create_index(p_tabela_nome character varying, p_tabela_nome_temp character varying) TO nebgp_usuario_servico with GRANT option;

GRANT EXECUTE ON FUNCTION neb.sp_att_import_create_index(p_tabela_nome character varying, p_tabela_nome_temp character varying) TO nebgp_desenvolvedor with GRANT option;

CREATE OR REPLACE FUNCTION neb.sp_att_import_drop_view() returns void
    security definer
    language plpgsql
AS
$$
DECLARE
    v_sql            character varying;
    v_view_nome      varchar(100);
    v_view_definicao character varying;

    -- cursor
    cursor_drop_view CURSOR FOR SELECT view_nome
                                FROM tbl_atualizacao_views
                                GROUP BY view_nome
                                ORDER BY view_nome;

BEGIN


    OPEN cursor_drop_view;
    LOOP
        FETCH cursor_drop_view INTO v_view_nome;
        EXIT WHEN NOT FOUND;

        RAISE NOTICE '%',' DROP VIEW ' || v_view_nome || ';';
        EXECUTE ' DROP VIEW ' || v_view_nome || ';';

    END LOOP;
    CLOSE cursor_drop_view;


END;
$$;

ALTER FUNCTION neb.sp_att_import_drop_view() OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.sp_att_import_drop_view() TO nebgp_usuario_servico with GRANT option;

GRANT EXECUTE ON FUNCTION neb.sp_att_import_drop_view() TO nebgp_desenvolvedor with GRANT option;

CREATE OR REPLACE FUNCTION neb.sp_att_import_full_atualiza(p_tabela_nome character varying) returns void
    security definer
    language plpgsql
AS
$$
DECLARE
    v_sql                       varchar(1000);

    -- variaveis do LOOP
    v_arquivo_id                integer;
    v_arquivo_nome              varchar(100);
    v_sineb_tabela_destino      varchar(100);
    v_sineb_tabela_destino_temp varchar(100);


    --cursor Atualização de Tabelas SEM PK
    cursor_clientes CURSOR FOR SELECT arquivo_id, arquivo_nome, sineb_tabela_destino
                               FROM tbl_atualizacao_arquivos A
                               WHERE (
                                             (p_tabela_nome = '' AND carregar = 1 AND sistema = 0)
                                             OR
                                             (p_tabela_nome <> '' AND sineb_tabela_destino = p_tabela_nome AND
                                              carregar = 1 AND sistema = 0)
                                         )
--	AND
--	NOT EXISTS
--	(
--	 SELECT 1 FROM tbl_atualizacao_tabelas_colunas B WHERE B.tabela_nome = A.sineb_tabela_destino
--		AND B.indice_tipo = 'pk' -- PK
--	)
                                     --sineb_tabela_destino = 'tbl_empct' AND
                                     --carregar = 1
                               ORDER BY ordem
    ;

    -- variaveis de indice
    v_indice_nome               varchar(100);
    v_indice_coluna             varchar(100);
BEGIN

    OPEN cursor_clientes;
    --
    LOOP
        FETCH cursor_clientes INTO v_arquivo_id, v_arquivo_nome, v_sineb_tabela_destino;
        EXIT WHEN NOT FOUND;

        v_sineb_tabela_destino_temp := v_sineb_tabela_destino || '_temp'; -- tbl temp

        RAISE NOTICE '% - % - %',v_arquivo_id, v_arquivo_nome, v_sineb_tabela_destino_temp;
        --PERFORM pg_sleep(10);

        -- limpa indices e PK que podem ter ficado de uma execução não finalizada
        -- DROP INDEX (todos indices de cada tabela da carga)
        PERFORM sp_atualizacao_drop_index(v_sineb_tabela_destino_temp);
        -- DROP PK (de cada tabela da carga)
        PERFORM sp_atualizacao_drop_constraint(v_sineb_tabela_destino_temp);


        -- renomeia INDEX da tabela de produção (_temp2)
        FOR v_indice_nome IN SELECT i.relname AS indice_nome
                             FROM pg_class c
                                      JOIN pg_index x ON c.oid = x.indrelid
                                      JOIN pg_class i ON i.oid = x.indexrelid
                             WHERE c.relname = v_sineb_tabela_destino
                               AND not (x.indisprimary) -- index normal, não PK
            LOOP
                v_sql := '';
                v_sql := v_sql || 'ALTER INDEX  ' || v_indice_nome || ' RENAME TO ' || v_indice_nome || '_temp2';
                v_sql := v_sql || ';';
                RAISE NOTICE '%',v_sql;
                EXECUTE v_sql;
            END LOOP;


        -- renomeia PK da tabela de produção (_temp2)
        FOR v_indice_nome IN SELECT i.relname AS indice_nome
                             FROM pg_class c
                                      JOIN pg_index x ON c.oid = x.indrelid
                                      JOIN pg_class i ON i.oid = x.indexrelid
                             WHERE c.relname = v_sineb_tabela_destino
                               AND (x.indisprimary) -- PK
            LOOP
                v_sql := '';
                v_sql := v_sql || 'ALTER INDEX  ' || v_indice_nome || ' RENAME TO ' || v_indice_nome || '_temp2';
                v_sql := v_sql || ';';
                RAISE NOTICE '%',v_sql;
                EXECUTE v_sql;
            END LOOP;

        -- cria INDEX da tabela de produção na TEMP
        PERFORM sp_att_import_create_index(v_sineb_tabela_destino, v_sineb_tabela_destino_temp);

        -- cria PK da tabela de produção na TEMP
        PERFORM sp_att_import_create_constraint(v_sineb_tabela_destino, v_sineb_tabela_destino_temp);

        -- renomeia produção para _temp2
        v_sql := '';
        v_sql := v_sql || 'ALTER TABLE ' || v_sineb_tabela_destino;
        v_sql := v_sql || ' RENAME TO ' || v_sineb_tabela_destino || '_temp2';
        v_sql := v_sql || ';';
        RAISE NOTICE '%',v_sql;
        EXECUTE v_sql;

        -- renomeia TEMP para produção
        v_sql := '';
        v_sql := v_sql || 'ALTER TABLE ' || v_sineb_tabela_destino_temp;
        v_sql := v_sql || ' RENAME TO ' || v_sineb_tabela_destino;
        v_sql := v_sql || ';';
        RAISE NOTICE '%',v_sql;
        EXECUTE v_sql;

        -- renomeia _temp2 para _temp
        v_sql := '';
        v_sql := v_sql || 'ALTER TABLE ' || v_sineb_tabela_destino || '_temp2';
        v_sql := v_sql || ' RENAME TO ' || v_sineb_tabela_destino_temp;
        v_sql := v_sql || ';';
        RAISE NOTICE '%',v_sql;
        EXECUTE v_sql;

        -- recria view com dependencia da ex-tabela de produção, para ela apontar para a nova
        -- PERFORM sp_att_import_atualiza_view_dependente(v_sineb_tabela_destino);


    END LOOP;
    --
    CLOSE cursor_clientes;

END;
$$;

ALTER FUNCTION neb.sp_att_import_full_atualiza(varchar) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.sp_att_import_full_atualiza(p_tabela_nome character varying) TO nebgp_desenvolvedor with GRANT option;

GRANT EXECUTE ON FUNCTION neb.sp_att_import_full_atualiza(p_tabela_nome character varying) TO nebgp_usuario_servico with GRANT option;

CREATE OR REPLACE FUNCTION neb.sp_att_import_full_atualiza_drop(p_tabela_nome character varying) returns void
    security definer
    language plpgsql
AS
$$
DECLARE
    v_sql                       varchar(1000);

    -- variaveis do LOOP
    v_arquivo_id                integer;
    v_arquivo_nome              varchar(100);
    v_sineb_tabela_destino      varchar(100);
    v_sineb_tabela_destino_temp varchar(100);


    --cursor Atualização de Tabelas SEM PK
    cursor_clientes CURSOR FOR SELECT arquivo_id, arquivo_nome, sineb_tabela_destino
                               FROM tbl_atualizacao_arquivos A
                               WHERE (
                                             (p_tabela_nome = '' AND carregar = 1 AND sistema = 0)
                                             OR
                                             (p_tabela_nome <> '' AND sineb_tabela_destino = p_tabela_nome AND
                                              carregar = 1 AND sistema = 0)
                                         )
--	AND
--	NOT EXISTS
--	(
--	 SELECT 1 FROM tbl_atualizacao_tabelas_colunas B WHERE B.tabela_nome = A.sineb_tabela_destino
--		AND B.indice_tipo = 'pk' -- PK
--	)
                                     --sineb_tabela_destino = 'tbl_empct' AND
                                     --carregar = 1
                               ORDER BY ordem
    ;

    -- variaveis de indice
    v_indice_nome               varchar(100);
    v_indice_coluna             varchar(100);
BEGIN

    OPEN cursor_clientes;
    --
    LOOP
        FETCH cursor_clientes INTO v_arquivo_id, v_arquivo_nome, v_sineb_tabela_destino;
        EXIT WHEN NOT FOUND;

        v_sineb_tabela_destino_temp := v_sineb_tabela_destino || '_temp'; -- tbl temp

        RAISE NOTICE '% - % - %',v_arquivo_id, v_arquivo_nome, v_sineb_tabela_destino_temp;
        --PERFORM pg_sleep(10);

        -- DROP nova Tabela Temp (ex-prod)
        v_sql := '';
        v_sql := v_sql || 'DROP TABLE IF EXISTS ' || v_sineb_tabela_destino_temp;
        v_sql := v_sql || ';';
        RAISE NOTICE '%',v_sql;
        EXECUTE v_sql;

    END LOOP;
    --
    CLOSE cursor_clientes;

END;
$$;

ALTER FUNCTION neb.sp_att_import_full_atualiza_drop(varchar) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.sp_att_import_full_atualiza_drop(p_tabela_nome character varying) TO nebgp_desenvolvedor with GRANT option;

GRANT EXECUTE ON FUNCTION neb.sp_att_import_full_atualiza_drop(p_tabela_nome character varying) TO nebgp_usuario_servico with GRANT option;

CREATE OR REPLACE FUNCTION neb.sp_att_import_full_atualiza_view(p_tabela_nome character varying) returns void
    security definer
    language plpgsql
AS
$$
DECLARE
    v_sql                       varchar(1000);

    -- variaveis do LOOP
    v_arquivo_id                integer;
    v_arquivo_nome              varchar(100);
    v_sineb_tabela_destino      varchar(100);
    v_sineb_tabela_destino_temp varchar(100);


    --cursor Atualização de Tabelas SEM PK
    cursor_clientes CURSOR FOR SELECT arquivo_id, arquivo_nome, sineb_tabela_destino
                               FROM tbl_atualizacao_arquivos A
                               WHERE (
                                             (p_tabela_nome = '' AND carregar = 1 AND sistema = 0)
                                             OR
                                             (p_tabela_nome <> '' AND sineb_tabela_destino = p_tabela_nome)
                                         )
--	AND
--	NOT EXISTS
--	(
--	 SELECT 1 FROM tbl_atualizacao_tabelas_colunas B WHERE B.tabela_nome = A.sineb_tabela_destino
--		AND B.indice_tipo = 'pk' -- PK
--	)
                                     --sineb_tabela_destino = 'tbl_empct' AND
                                     --carregar = 1
                               ORDER BY ordem
    ;

    -- variaveis de indice
    v_indice_nome               varchar(100);
    v_indice_coluna             varchar(100);
BEGIN

    OPEN cursor_clientes;
    --
    LOOP
        FETCH cursor_clientes INTO v_arquivo_id, v_arquivo_nome, v_sineb_tabela_destino;
        EXIT WHEN NOT FOUND;

        v_sineb_tabela_destino_temp := v_sineb_tabela_destino || '_temp'; -- tbl temp

        RAISE NOTICE '% - % - %',v_arquivo_id, v_arquivo_nome, v_sineb_tabela_destino_temp;
        --PERFORM pg_sleep(10);

        -- recria view com dependencia da ex-tabela de produção, para ela apontar para a nova
        PERFORM sp_att_import_atualiza_view_dependente(v_sineb_tabela_destino);

    END LOOP;
    --
    CLOSE cursor_clientes;

END;
$$;

ALTER FUNCTION neb.sp_att_import_full_atualiza_view(varchar) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.sp_att_import_full_atualiza_view(p_tabela_nome character varying) TO nebgp_desenvolvedor with GRANT option;

GRANT EXECUTE ON FUNCTION neb.sp_att_import_full_atualiza_view(p_tabela_nome character varying) TO nebgp_usuario_servico with GRANT option;

CREATE OR REPLACE FUNCTION neb.sp_att_import_full_carga(p_tabela_nome character varying) returns void
    security definer
    language plpgsql
AS
$$
DECLARE
    v_sql                       varchar(1000);

    -- variaveis do LOOP
    v_arquivo_id                integer;
    v_arquivo_nome              varchar(100);
    v_sineb_tabela_destino      varchar(100);
    v_sineb_tabela_destino_temp varchar(100);


    --cursor
    cursor_clientes CURSOR FOR SELECT arquivo_id, arquivo_nome, sineb_tabela_destino
                               FROM tbl_atualizacao_arquivos
                               WHERE (p_tabela_nome = '' AND carregar = 1 AND sistema = 0)
                                  OR (p_tabela_nome <> '' AND sineb_tabela_destino = p_tabela_nome AND carregar = 1 AND
                                      sistema = 0)
                                  --sineb_tabela_destino = 'tbl_empct' AND
                                  --carregar = 1
                               ORDER BY ordem desc
                               limit 1
    ;
BEGIN

    OPEN cursor_clientes;
    --
    LOOP
        FETCH cursor_clientes INTO v_arquivo_id, v_arquivo_nome, v_sineb_tabela_destino;
        EXIT WHEN NOT FOUND;

        v_sineb_tabela_destino_temp := v_sineb_tabela_destino || '_temp'; -- tbl temp


        RAISE NOTICE '% - % - %',v_arquivo_id, v_arquivo_nome, v_sineb_tabela_destino_temp;
        --PERFORM pg_sleep(10);

        -- Cria TEMP da tabela para carga
        v_sql := '';
        v_sql := v_sql || 'DROP TABLE IF EXISTS ' || v_sineb_tabela_destino_temp;
        v_sql := v_sql || ';';
        RAISE NOTICE '%',v_sql;
        EXECUTE v_sql;

        v_sql := '';
        v_sql := v_sql || 'CREATE TABLE ' || v_sineb_tabela_destino_temp;
        v_sql := v_sql || ' AS SELECT * FROM ' || v_sineb_tabela_destino || ' limit 0';
        v_sql := v_sql || ';';
        RAISE NOTICE '%',v_sql;
        EXECUTE v_sql;


        -- FUNÇÃO (SP) copy
        PERFORM sp_atualizacao_copy_from(v_arquivo_nome, v_sineb_tabela_destino_temp);

    END LOOP;
    --
    CLOSE cursor_clientes;

END;
$$;

ALTER FUNCTION neb.sp_att_import_full_carga(varchar) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.sp_att_import_full_carga(p_tabela_nome character varying) TO nebgp_desenvolvedor with GRANT option;

GRANT EXECUTE ON FUNCTION neb.sp_att_import_full_carga(p_tabela_nome character varying) TO nebgp_usuario_servico with GRANT option;

CREATE OR REPLACE FUNCTION neb.sp_att_import_inc_atualiza(p_tabela_nome character varying) returns void
    security definer
    language plpgsql
AS
$$
DECLARE
    v_sql                       varchar(1000);

    -- variaveis do LOOP
    v_arquivo_id                integer;
    v_arquivo_nome              varchar(100);
    v_sineb_tabela_destino      varchar(100);
    v_sineb_tabela_destino_temp varchar(100);


    --cursor Atualização de Tabelas com PK
    cursor_clientes CURSOR FOR SELECT arquivo_id, arquivo_nome, sineb_tabela_destino
                               FROM tbl_atualizacao_arquivos A
                               WHERE 1 = 2
                                 AND (
                                       (p_tabela_nome = '' AND carregar = 1 AND sistema = 0)
                                       OR
                                       (p_tabela_nome <> '' AND sineb_tabela_destino = p_tabela_nome)
                                   )
                                 AND EXISTS
                                   (
                                       SELECT 1
                                       FROM tbl_atualizacao_tabelas_colunas B
                                       WHERE B.tabela_nome = A.sineb_tabela_destino
                                         AND B.indice_tipo = 'pk' -- PK
                                   )
                                 --sineb_tabela_destino = 'tbl_empct' AND
                                 --carregar = 1
                               ORDER BY ordem
    ;

    -- variaveis de indice
    v_indice_nome               varchar(100);
    v_indice_coluna             varchar(100);
BEGIN

    OPEN cursor_clientes;
    --
    LOOP
        FETCH cursor_clientes INTO v_arquivo_id, v_arquivo_nome, v_sineb_tabela_destino;
        EXIT WHEN NOT FOUND;

        v_sineb_tabela_destino_temp := v_sineb_tabela_destino || '_temp'; -- tbl temp

        RAISE NOTICE '% - % - %',v_arquivo_id, v_arquivo_nome, v_sineb_tabela_destino_temp;
        --PERFORM pg_sleep(10);

        -- limpa indices e PK que podem ter ficado de uma execução não finalizada
        -- DROP INDEX (todos indices de cada tabela da carga)
        PERFORM sp_atualizacao_drop_index(v_sineb_tabela_destino_temp);
        -- DROP PK (de cada tabela da carga)
        PERFORM sp_atualizacao_drop_constraint(v_sineb_tabela_destino_temp);

        -- Carrega na TEMP os dados de produção que não serão renovados (não vieram na TEMP)
        -- INSERT INTO - ini
        v_sql := '';
        v_sql := v_sql || 'INSERT INTO ' || v_sineb_tabela_destino_temp;
        v_sql := v_sql || ' SELECT * FROM  ' || v_sineb_tabela_destino || ' A ';
        v_sql := v_sql || ' WHERE NOT EXISTS (SELECT 1 FROM ' || v_sineb_tabela_destino_temp || ' B WHERE ';

        -- busca PK
        -- FOR para pegar os indices da tabela
        FOR v_indice_nome IN SELECT indice_nome
                             FROM tbl_atualizacao_tabelas_colunas
                             WHERE tabela_nome = v_sineb_tabela_destino
                               AND indice_tipo = 'pk' -- PK
                             GROUP BY indice_nome
            LOOP
                -- FOR para pegar AS colunas do indices da tabela
                FOR v_indice_coluna IN SELECT coluna_nome
                                       FROM tbl_atualizacao_tabelas_colunas
                                       WHERE indice_nome = v_indice_nome
                    LOOP
                        v_sql := v_sql || ' A.' || v_indice_coluna || ' = B.' || v_indice_coluna;
                        v_sql := v_sql || ' AND ';
                    END LOOP;

                v_sql := SUBSTR(v_sql, 1, char_length(v_sql) - 5);

            END LOOP;

        v_sql := v_sql || ')'; -- fecha NOT EXISTS

        v_sql := v_sql || ';';
        RAISE NOTICE '%',v_sql;
        EXECUTE v_sql;
        -- INSERT INTO - fim

        -- renomeia INDEX da tabela de procução (_temp2)
        FOR v_indice_nome IN SELECT i.relname AS indice_nome
                             FROM pg_class c
                                      JOIN pg_index x ON c.oid = x.indrelid
                                      JOIN pg_class i ON i.oid = x.indexrelid
                             WHERE c.relname = v_sineb_tabela_destino
                               AND not (x.indisprimary) -- index normal, não PK
            LOOP
                v_sql := '';
                v_sql := v_sql || 'ALTER INDEX  ' || v_indice_nome || ' RENAME TO ' || v_indice_nome || '_temp2';
                v_sql := v_sql || ';';
                RAISE NOTICE '%',v_sql;
                EXECUTE v_sql;
            END LOOP;


        -- renomeia PK da tabela de procução (_temp2)
        FOR v_indice_nome IN SELECT i.relname AS indice_nome
                             FROM pg_class c
                                      JOIN pg_index x ON c.oid = x.indrelid
                                      JOIN pg_class i ON i.oid = x.indexrelid
                             WHERE c.relname = v_sineb_tabela_destino
                               AND (x.indisprimary) -- PK
            LOOP
                v_sql := '';
                v_sql := v_sql || 'ALTER INDEX  ' || v_indice_nome || ' RENAME TO ' || v_indice_nome || '_temp2';
                v_sql := v_sql || ';';
                RAISE NOTICE '%',v_sql;
                EXECUTE v_sql;
            END LOOP;

        -- cria INDEX da tabela de produção na TEMP
        PERFORM sp_att_import_create_index(v_sineb_tabela_destino, v_sineb_tabela_destino_temp);

        -- cria PK da tabela de produção na TEMP
        PERFORM sp_att_import_create_constraint(v_sineb_tabela_destino, v_sineb_tabela_destino_temp);

        -- renomeia produção para _temp2
        v_sql := '';
        v_sql := v_sql || 'ALTER TABLE ' || v_sineb_tabela_destino;
        v_sql := v_sql || ' RENAME TO ' || v_sineb_tabela_destino || '_temp2';
        v_sql := v_sql || ';';
        RAISE NOTICE '%',v_sql;
        EXECUTE v_sql;

        -- renomeia TEMP para produção
        v_sql := '';
        v_sql := v_sql || 'ALTER TABLE ' || v_sineb_tabela_destino_temp;
        v_sql := v_sql || ' RENAME TO ' || v_sineb_tabela_destino;
        v_sql := v_sql || ';';
        RAISE NOTICE '%',v_sql;
        EXECUTE v_sql;

        -- renomeia _temp2 para _temp
        v_sql := '';
        v_sql := v_sql || 'ALTER TABLE ' || v_sineb_tabela_destino || '_temp2';
        v_sql := v_sql || ' RENAME TO ' || v_sineb_tabela_destino_temp;
        v_sql := v_sql || ';';
        RAISE NOTICE '%',v_sql;
        EXECUTE v_sql;

        -- recria view com dependencia da ex-tabela de produção, para ela apontar para a nova
        --PERFORM sp_att_import_atualiza_view_dependente(v_sineb_tabela_destino);

    END LOOP;
    --
    CLOSE cursor_clientes;

END;
$$;

ALTER FUNCTION neb.sp_att_import_inc_atualiza(varchar) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.sp_att_import_inc_atualiza(p_tabela_nome character varying) TO nebgp_desenvolvedor with GRANT option;

GRANT EXECUTE ON FUNCTION neb.sp_att_import_inc_atualiza(p_tabela_nome character varying) TO nebgp_usuario_servico with GRANT option;

CREATE OR REPLACE FUNCTION neb.sp_att_import_inc_atualiza_drop(p_tabela_nome character varying) returns void
    security definer
    language plpgsql
AS
$$
DECLARE
    v_sql                       varchar(1000);

    -- variaveis do LOOP
    v_arquivo_id                integer;
    v_arquivo_nome              varchar(100);
    v_sineb_tabela_destino      varchar(100);
    v_sineb_tabela_destino_temp varchar(100);


    --cursor Atualização de Tabelas com PK
    cursor_clientes CURSOR FOR SELECT arquivo_id, arquivo_nome, sineb_tabela_destino
                               FROM tbl_atualizacao_arquivos A
                               WHERE 1 = 2
                                 AND (
                                       (p_tabela_nome = '' AND carregar = 1 AND sistema = 0)
                                       OR
                                       (p_tabela_nome <> '' AND sineb_tabela_destino = p_tabela_nome)
                                   )
                                 AND EXISTS
                                   (
                                       SELECT 1
                                       FROM tbl_atualizacao_tabelas_colunas B
                                       WHERE B.tabela_nome = A.sineb_tabela_destino
                                         AND B.indice_tipo = 'pk' -- PK
                                   )
                                 --sineb_tabela_destino = 'tbl_empct' AND
                                 --carregar = 1
                               ORDER BY ordem
    ;

    -- variaveis de indice
    v_indice_nome               varchar(100);
    v_indice_coluna             varchar(100);
BEGIN

    OPEN cursor_clientes;
    --
    LOOP
        FETCH cursor_clientes INTO v_arquivo_id, v_arquivo_nome, v_sineb_tabela_destino;
        EXIT WHEN NOT FOUND;

        v_sineb_tabela_destino_temp := v_sineb_tabela_destino || '_temp'; -- tbl temp

        RAISE NOTICE '% - % - %',v_arquivo_id, v_arquivo_nome, v_sineb_tabela_destino_temp;
        --PERFORM pg_sleep(10);

        -- DROP nova Tabela Temp (ex-prod)
        v_sql := '';
        v_sql := v_sql || 'DROP TABLE IF EXISTS ' || v_sineb_tabela_destino_temp;
        v_sql := v_sql || ';';
        RAISE NOTICE '%',v_sql;
        EXECUTE v_sql;

    END LOOP;
    --
    CLOSE cursor_clientes;

END;
$$;

ALTER FUNCTION neb.sp_att_import_inc_atualiza_drop(varchar) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.sp_att_import_inc_atualiza_drop(p_tabela_nome character varying) TO nebgp_usuario_servico with GRANT option;

GRANT EXECUTE ON FUNCTION neb.sp_att_import_inc_atualiza_drop(p_tabela_nome character varying) TO nebgp_desenvolvedor with GRANT option;

CREATE OR REPLACE FUNCTION neb.sp_att_import_sis_controle_atualiza(p_tabela_nome character varying) returns void
    security definer
    language plpgsql
AS
$$
DECLARE

    v_sql                       varchar(1000);
    v_sineb_tabela_destino      varchar(100);
    v_sineb_tabela_destino_temp varchar(100);
    v_arquivo_nome              varchar(100);

BEGIN

    v_sineb_tabela_destino := p_tabela_nome;
    v_sineb_tabela_destino_temp := v_sineb_tabela_destino || '_temp'; -- tbl temp
    v_arquivo_nome := v_sineb_tabela_destino || '.txt';
    -- TXT


    -- Cria TEMP da tabela para carga
    v_sql := '';
    v_sql := v_sql || 'DROP TABLE IF EXISTS ' || v_sineb_tabela_destino_temp;
    v_sql := v_sql || ';';
    RAISE NOTICE '%',v_sql;
    EXECUTE v_sql;

    v_sql := '';
    v_sql := v_sql || 'CREATE TABLE ' || v_sineb_tabela_destino_temp;
    v_sql := v_sql || ' AS SELECT * FROM ' || v_sineb_tabela_destino || ' limit 0';
    v_sql := v_sql || ';';
    RAISE NOTICE '%',v_sql;
    EXECUTE v_sql;


    -- FUNÇÃO (SP) copy
    PERFORM sp_atualizacao_copy_from(v_arquivo_nome, v_sineb_tabela_destino_temp);


    -- TRUNCATE
    v_sql := '';
    v_sql := v_sql || 'TRUNCATE TABLE ' || v_sineb_tabela_destino;
    v_sql := v_sql || ';';
    RAISE NOTICE '%',v_sql;
    EXECUTE v_sql;

    -- INSERT
    v_sql := '';
    v_sql := v_sql || 'INSERT INTO ' || v_sineb_tabela_destino;
    v_sql := v_sql || ' SELECT * FROM ' || v_sineb_tabela_destino_temp;
    v_sql := v_sql || ';';
    RAISE NOTICE '%',v_sql;
    EXECUTE v_sql;


    -- DROP Temp
    v_sql := '';
    v_sql := v_sql || 'DROP TABLE IF EXISTS ' || v_sineb_tabela_destino_temp;
    v_sql := v_sql || ';';
    RAISE NOTICE '%',v_sql;
    EXECUTE v_sql;


END;
$$;

ALTER FUNCTION neb.sp_att_import_sis_controle_atualiza(varchar) OWNER TO c131481;

CREATE OR REPLACE FUNCTION neb.sp_att_import_sis_full_carga(p_tabela_nome character varying) returns void
    security definer
    language plpgsql
AS
$$
DECLARE
    v_sql                       varchar(1000);

    -- variaveis do LOOP
    v_arquivo_id                integer;
    v_arquivo_nome              varchar(100);
    v_sineb_tabela_destino      varchar(100);
    v_sineb_tabela_destino_temp varchar(100);


    --cursor
    cursor_clientes CURSOR FOR SELECT arquivo_id, arquivo_nome, sineb_tabela_destino
                               FROM tbl_atualizacao_arquivos
                               WHERE (
                                       (p_tabela_nome = '' AND carregar = 1 AND sistema = 1)
                                       OR
                                       (p_tabela_nome <> '' AND sineb_tabela_destino = p_tabela_nome)
                                   )
                                 AND sineb_tabela_destino <> 'tbl_atualizacao_arquivos'
                               ORDER BY ordem
    ;
BEGIN

    OPEN cursor_clientes;
    --
    LOOP
        FETCH cursor_clientes INTO v_arquivo_id, v_arquivo_nome, v_sineb_tabela_destino;
        EXIT WHEN NOT FOUND;

        v_sineb_tabela_destino_temp := v_sineb_tabela_destino || '_temp'; -- tbl temp


        RAISE NOTICE '% - % - %',v_arquivo_id, v_arquivo_nome, v_sineb_tabela_destino_temp;
        --PERFORM pg_sleep(10);

        -- Cria TEMP da tabela para carga
        v_sql := '';
        v_sql := v_sql || 'DROP TABLE IF EXISTS ' || v_sineb_tabela_destino_temp;
        v_sql := v_sql || ';';
        RAISE NOTICE '%',v_sql;
        EXECUTE v_sql;

        v_sql := '';
        v_sql := v_sql || 'CREATE TABLE ' || v_sineb_tabela_destino_temp;
        v_sql := v_sql || ' AS SELECT * FROM ' || v_sineb_tabela_destino || ' limit 0';
        v_sql := v_sql || ';';
        RAISE NOTICE '%',v_sql;
        EXECUTE v_sql;


        -- FUNÇÃO (SP) copy
        PERFORM sp_atualizacao_copy_from(v_arquivo_nome, v_sineb_tabela_destino_temp);

    END LOOP;
    --
    CLOSE cursor_clientes;

END;
$$;

ALTER FUNCTION neb.sp_att_import_sis_full_carga(varchar) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.sp_att_import_sis_full_carga(p_tabela_nome character varying) TO nebgp_usuario_servico with GRANT option;

GRANT EXECUTE ON FUNCTION neb.sp_att_import_sis_full_carga(p_tabela_nome character varying) TO nebgp_desenvolvedor with GRANT option;

CREATE OR REPLACE FUNCTION neb.sp_atualizacao_copy_from(p_origem_arquivo character varying,
                                                    p_destino_tabela character varying) returns void
    security definer
    language plpgsql
AS
$$
DECLARE
    v_caminho varchar(200) := '/producao/rotina/SINEB/new/'; -- NOVO CAMINHO PRODUÇÃO
    -- v_caminho varchar(200) := '/producao/rotina/SINEB/dados/IMPORT/arquivos/batch/'
    -- v_caminho varchar(200) := 'C:\Pub\';
    --v_caminho varchar(200) := 'C:\Rafael\Informatica\SINEB\TXT_Carga\';


    v_sql     varchar(1000);
    v_qtde    integer;
BEGIN

    set client_encoding TO 'LATIN-1';

    v_sql := '';
    -- copy
    v_sql := 'copy ' || p_destino_tabela || ' from  ' || '''' || v_caminho || p_origem_arquivo || '''' ||
             ' delimiter ' || quote_literal('#') || ' null ' || '''''';
    v_sql := v_sql || ';';
    RAISE NOTICE '%',v_sql;
    EXECUTE v_sql;

    --RETURN (1);
END;
$$;

ALTER FUNCTION neb.sp_atualizacao_copy_from(varchar, varchar) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.sp_atualizacao_copy_from(p_origem_arquivo character varying, p_destino_tabela character varying) TO nebgp_usuario_servico with GRANT option;

GRANT EXECUTE ON FUNCTION neb.sp_atualizacao_copy_from(p_origem_arquivo character varying, p_destino_tabela character varying) TO nebgp_desenvolvedor with GRANT option;

CREATE OR REPLACE FUNCTION neb.sp_atualizacao_copy_to(p_origem_tabela character varying,
                                                  p_destino_arquivo character varying) returns void
    security definer
    language plpgsql
AS
$$
DECLARE
    v_caminho varchar(200) := '/producao/rotina/SINEB/new/'; -- NOVO CAMINHO PRODUÇÃO
    -- v_caminho varchar(200) := '/producao/rotina/SINEB/dados/IMPORT/arquivos/batch/'
    -- v_caminho varchar(200) := 'C:\Pub\';
    --v_caminho varchar(200) := 'C:\Rafael\Informatica\SINEB\TXT_Carga\';

    v_sql     varchar(1000);
    v_qtde    integer;
BEGIN

    --	set client_encoding TO 'UTF-8';

    v_sql := '';
    -- copy
    v_sql := 'copy ' || p_origem_tabela || ' TO  ' || '''' || v_caminho || p_destino_arquivo || '''' || ' delimiter ' ||
             quote_literal('#') || ' null ' || '''''';
    v_sql := v_sql || ';';
    RAISE NOTICE '%',v_sql;
    EXECUTE v_sql;

    --RETURN (1);
END;
$$;

ALTER FUNCTION neb.sp_atualizacao_copy_to(varchar, varchar) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.sp_atualizacao_copy_to(p_origem_tabela character varying, p_destino_arquivo character varying) TO nebgp_usuario_servico with GRANT option;

GRANT EXECUTE ON FUNCTION neb.sp_atualizacao_copy_to(p_origem_tabela character varying, p_destino_arquivo character varying) TO nebgp_desenvolvedor with GRANT option;

CREATE OR REPLACE FUNCTION neb.sp_atualizacao_create_constraint(p_tabela_nome character varying) returns void
    security definer
    language plpgsql
AS
$$
DECLARE
    v_sql           varchar(1000);
    v_indice_nome   varchar(100);
    v_indice_coluna varchar(100);
BEGIN

    -- CREATE PK
    -- FOR para pegar os indices da tabela
    FOR v_indice_nome IN SELECT indice_nome
                         FROM tbl_atualizacao_tabelas_colunas
                         WHERE tabela_nome = p_tabela_nome
                           AND indice_tipo = 'pk' -- PK
                         GROUP BY indice_nome
        LOOP
            v_sql := '';
            v_sql := v_sql || 'ALTER TABLE ' || p_tabela_nome;
            v_sql := v_sql || ' ADD CONSTRAINT ' || v_indice_nome;
            v_sql := v_sql || ' PRIMARY KEY (';
            -- FOR para pegar AS colunas do indices da tabela
            FOR v_indice_coluna IN SELECT coluna_nome
                                   FROM tbl_atualizacao_tabelas_colunas
                                   WHERE indice_nome = v_indice_nome
                LOOP
                    v_sql := v_sql || v_indice_coluna;
                    v_sql := v_sql || ',';
                END LOOP;

            v_sql := SUBSTR(v_sql, 1, char_length(v_sql) - 1);

            v_sql := v_sql || ') ';
            v_sql := v_sql || ';';
            RAISE NOTICE '%',v_sql;
            EXECUTE v_sql;
        END LOOP;
END;
$$;

ALTER FUNCTION neb.sp_atualizacao_create_constraint(varchar) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.sp_atualizacao_create_constraint(p_tabela_nome character varying) TO nebgp_usuario_servico with GRANT option;

GRANT EXECUTE ON FUNCTION neb.sp_atualizacao_create_constraint(p_tabela_nome character varying) TO nebgp_desenvolvedor with GRANT option;

CREATE OR REPLACE FUNCTION neb.sp_atualizacao_create_index(p_tabela_nome character varying) returns void
    security definer
    language plpgsql
AS
$$
DECLARE
    v_sql           varchar(1000);
    v_indice_nome   varchar(100);
    v_indice_coluna varchar(100);
BEGIN

    -- CREATE INDEX
    -- FOR para pegar os indices da tabela
    FOR v_indice_nome IN SELECT indice_nome
                         FROM tbl_atualizacao_tabelas_colunas
                         WHERE tabela_nome = p_tabela_nome
                           AND indice_tipo = 'ix' -- index normal, não PK
                         GROUP BY indice_nome
        LOOP
            v_sql := '';
            v_sql := v_sql || 'CREATE INDEX ' || v_indice_nome;
            v_sql := v_sql || ' ON ' || p_tabela_nome;
            v_sql := v_sql || ' (';
            -- FOR para pegar AS colunas do indices da tabela
            FOR v_indice_coluna IN SELECT coluna_nome
                                   FROM tbl_atualizacao_tabelas_colunas
                                   WHERE indice_nome = v_indice_nome
                LOOP
                    v_sql := v_sql || v_indice_coluna;
                    v_sql := v_sql || ',';
                END LOOP;

            v_sql := SUBSTR(v_sql, 1, char_length(v_sql) - 1);

            v_sql := v_sql || ') ';
            v_sql := v_sql || ';';
            RAISE NOTICE '%',v_sql;
            EXECUTE v_sql;
        END LOOP;
END;
$$;

ALTER FUNCTION neb.sp_atualizacao_create_index(varchar) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.sp_atualizacao_create_index(p_tabela_nome character varying) TO nebgp_usuario_servico with GRANT option;

GRANT EXECUTE ON FUNCTION neb.sp_atualizacao_create_index(p_tabela_nome character varying) TO nebgp_desenvolvedor with GRANT option;

CREATE OR REPLACE FUNCTION neb.sp_atualizacao_drop_constraint(p_tabela_nome character varying) returns void
    security definer
    language plpgsql
AS
$$
DECLARE
    v_sql         varchar(1000);
    v_indice_nome varchar(100);
BEGIN

    -- DROP INDEX (todos indices de cada tabela da carga)
    FOR v_indice_nome IN SELECT i.relname AS indice_nome
                         FROM pg_class c
                                  JOIN pg_index x ON c.oid = x.indrelid
                                  JOIN pg_class i ON i.oid = x.indexrelid
                         WHERE c.relname = p_tabela_nome
                           AND (x.indisprimary) -- PK
        LOOP
            v_sql := '';
            v_sql := v_sql || 'ALTER TABLE ' || p_tabela_nome || ' DROP CONSTRAINT ' || v_indice_nome;
            v_sql := v_sql || ';';
            RAISE NOTICE '%',v_sql;
            EXECUTE v_sql;
        END LOOP;

END;
$$;

ALTER FUNCTION neb.sp_atualizacao_drop_constraint(varchar) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.sp_atualizacao_drop_constraint(p_tabela_nome character varying) TO nebgp_desenvolvedor with GRANT option;

GRANT EXECUTE ON FUNCTION neb.sp_atualizacao_drop_constraint(p_tabela_nome character varying) TO nebgp_usuario_servico with GRANT option;

CREATE OR REPLACE FUNCTION neb.sp_atualizacao_drop_index(p_tabela_nome character varying) returns void
    security definer
    language plpgsql
AS
$$
DECLARE
    v_sql         varchar(1000);
    v_indice_nome varchar(100);
BEGIN

    -- DROP INDEX (todos indices de cada tabela da carga)
    FOR v_indice_nome IN SELECT i.relname AS indice_nome
                         FROM pg_class c
                                  JOIN pg_index x ON c.oid = x.indrelid
                                  JOIN pg_class i ON i.oid = x.indexrelid
                         WHERE c.relname = p_tabela_nome
                           AND not (x.indisprimary) -- index normal, não PK
        LOOP
            v_sql := '';
            v_sql := v_sql || 'DROP INDEX ' || v_indice_nome;
            v_sql := v_sql || ';';
            RAISE NOTICE '%',v_sql;
            EXECUTE v_sql;
        END LOOP;

END;
$$;

ALTER FUNCTION neb.sp_atualizacao_drop_index(varchar) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.sp_atualizacao_drop_index(p_tabela_nome character varying) TO nebgp_usuario_servico with GRANT option;

GRANT EXECUTE ON FUNCTION neb.sp_atualizacao_drop_index(p_tabela_nome character varying) TO nebgp_desenvolvedor with GRANT option;

CREATE OR REPLACE FUNCTION neb.sp_atualizacao_log(p_log_rotina character varying, p_log_rotina_passo character varying,
                                              p_log_rotina_passo_observacao character varying) returns void
    security definer
    language plpgsql
AS
$$
DECLARE
    v_sql      varchar(1000);
    v_data_reg timestamp without time zone;
BEGIN

    --v_data_reg := NOW();
    v_data_reg := timeofday();

    INSERT INTO tbl_atualizacao_zlog (log_rotina, log_rotina_passo, log_rotina_passo_observacao, log_data_reg)
    VALUES (p_log_rotina, p_log_rotina_passo, p_log_rotina_passo_observacao, v_data_reg);

END;
$$;

ALTER FUNCTION neb.sp_atualizacao_log(varchar, varchar, varchar) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.sp_atualizacao_log(p_log_rotina character varying, p_log_rotina_passo character varying, p_log_rotina_passo_observacao character varying) TO nebgp_usuario_servico with GRANT option;

GRANT EXECUTE ON FUNCTION neb.sp_atualizacao_log(p_log_rotina character varying, p_log_rotina_passo character varying, p_log_rotina_passo_observacao character varying) TO nebgp_desenvolvedor with GRANT option;

CREATE OR REPLACE FUNCTION neb.sp_calcula_correcao_juros(vl_ca numeric, dt_ca date, negociacao bit) returns money
    language plpgsql
AS
$$
DECLARE
    vl_corrigido  DECIMAL(13, 2); indice_ca DECIMAL(18, 13); indice_dia DECIMAL(18, 13);
    tx_juros      DECIMAL(18, 13); dias_atraso DECIMAL(18, 13); valor_atual DECIMAL(18, 13);
    dt_cal_indice DATE; dt_cal_indice_dia DATE ;

BEGIN

    SELECT dias_atraso = (DATEDIFF(DAY, GETDATE(), dt_ca) * -1) + 60;
    SELECT tx_juros = 0.0,
           vl_corrigido = 0.0,
           indice_ca = NULL,
           indice_dia = NULL,
           dt_cal_indice = dt_ca,
           dt_cal_indice_dia = CONVERT(DATETIME, CONVERT(NVARCHAR(12), getDate(), 106));


    -- CALCULA CORREÃ?Ã?O MONETÃRIA
    IF dias_atraso > 60 AND dias_atraso < 721 THEN

--dbo.sp_calcula_correcao_juros 609.49,'04/07/2004',0
        WHILE indice_ca IS NULL
            LOOP
                SELECT indice_ca = ini_fatacum FROM tbl_indices WHERE ind_cod = 2 AND ini_dtref = dt_cal_indice;
                SELECT dt_cal_indice = DATEADD(Day, 1, dt_cal_indice);

            END LOOP;
        WHILE indice_dia IS NULL
            LOOP
                SELECT indice_dia = ini_fatacum FROM tbl_indices WHERE ind_cod = 2 AND ini_dtref = dt_cal_indice_dia;
                SELECT dt_cal_indice_dia = DATEADD(Day, -1, dt_cal_indice_dia);
            END LOOP;

        SELECT vl_corrigido = (vl_ca / indice_ca) * indice_dia;
    ELSIF dias_atraso > 720 THEN
        WHILE indice_ca IS NULL
            LOOP
                SELECT indice_ca = ini_fatacum FROM tbl_indices WHERE ind_cod = 3 AND ini_dtref = dt_cal_indice;
                SELECT dt_cal_indice = DATEADD(Day, 1, dt_cal_indice);

            END LOOP;

        WHILE indice_dia IS NULL
            LOOP
                SELECT indice_dia = ini_fatacum FROM tbl_indices WHERE ind_cod = 3 AND ini_dtref = dt_cal_indice_dia;
                SELECT dt_cal_indice_dia = DATEADD(Day, -1, dt_cal_indice_dia);
            END LOOP;
        SELECT vl_corrigido = (vl_ca / indice_ca) * indice_dia;
    END IF;

    -- CALCULA JUROS --> quando negociacao = 1 a negociaÃ§Ã£o Ã© a prazo
    IF dias_atraso > 60 AND dias_atraso < 181 AND negociacao = 1 THEN
        SELECT tx_juros = vl_corrigido * ((((POWER((1 + (1.5 / 100)), ((dias_atraso - 60) / 30))) - 1) * 100) / 100);
    ELSIF dias_atraso > 180 AND dias_atraso < 361 AND negociacao = 1 THEN
        SELECT tx_juros = vl_corrigido * ((((POWER((1 + (1.0 / 100)), ((dias_atraso - 60) / 30))) - 1) * 100) / 100);
    ELSIF dias_atraso > 360 AND dias_atraso < 721 AND negociacao = 1 THEN
        SELECT tx_juros = vl_corrigido * ((((POWER((1 + (0.5 / 100)), ((dias_atraso - 60) / 30))) - 1) * 100) / 100);
    ELSIF dias_atraso > 720 AND dias_atraso < 1081 AND negociacao = 0 THEN
        SELECT tx_juros = vl_corrigido * ((((POWER((1 + (0.5 / 100)), ((dias_atraso - 60) / 30))) - 1) * 100) / 100);
    ELSIF dias_atraso > 720 AND dias_atraso < 1081 AND negociacao = 1 THEN
        SELECT tx_juros = vl_corrigido * ((((POWER((1 + (1.0 / 100)), ((dias_atraso - 60) / 30))) - 1) * 100) / 100);
    ELSIF dias_atraso > 1080 AND dias_atraso < 1801 AND negociacao = 1 THEN
        SELECT tx_juros = vl_corrigido * ((((POWER((1 + (0.5 / 100)), ((dias_atraso - 60) / 30))) - 1) * 100) / 100);
    END IF;

    --	SELECT	vl_ca = vl_ca
--	SELECT	dt_ca = CONVERT(NVARCHAR(12),dt_ca,106)
--	SELECT	dias_atraso = dias_atraso
--	SELECT indice_ca = indice_ca
--	SELECT indice_dia = indice_dia
--	SELECT	vl_corrigido = vl_corrigido
--	SELECT	tx_juros = tx_juros
    SELECT valor_atual = vl_corrigido + tx_juros;

    RETURN valor_atual;

END;
$$;

ALTER FUNCTION neb.sp_calcula_correcao_juros(numeric, date, bit) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.sp_calcula_correcao_juros(vl_ca numeric, dt_ca date, negociacao bit) TO nebgp_usuario_servico with GRANT option;

GRANT EXECUTE ON FUNCTION neb.sp_calcula_correcao_juros(vl_ca numeric, dt_ca date, negociacao bit) TO nebgp_desenvolvedor with GRANT option;

CREATE OR REPLACE FUNCTION neb.sp_com_boleto_calcula_co_048(vl_ca numeric, dt_ca date, negociacao integer, contrato bigint,
                                                        parametro boolean) returns numeric
    language plpgsql
AS
$$
DECLARE
    --DECLARAÇÃO DAS INÚMERAS VARIÁVEIS UTILIZADAS
    vl_corrigido      DECIMAL(13, 2);
    indice_ca         DECIMAL(18, 13);
    indice_dia        DECIMAL(18, 13);
    tx_juros          DECIMAL(18, 13);
    mes_atraso        integer;
    valor_atual       DECIMAL(13, 2);
    dt_cal_indice     DATE;
    dt_cal_indice_dia DATE ;
    tp_indice         smallint;
    data_ca_util      date;
    juros_add         DECIMAL(18, 13);
    round_final       DECIMAL(18, 13);
    tp_negociacao     integer;
    dias_atraso       integer;
    divisao_meses     DECIMAL(18, 13);
    RS                record;
    vl_campanha       numeric;
begin

    IF parametro and 1 = (select 1 from tbl_campanha_contrato where contrato_numero = contrato) THEN

        select CASE
                   WHEN negociacao = 0 THEN campanha_valor_a_vista::numeric
                   WHEN negociacao = 1 THEN campanha_valor_a_prazo::numeric
                   END
        into vl_campanha
        from tbl_campanha_contrato
        where contrato_numero = contrato;
        RETURN vl_campanha::decimal(13, 2);
    ELSE

        -- O ENQUADRAMENTO SE DÁ POR MESES CORRIDOS

        mes_atraso = (fn_dateDiff('m', dt_ca, now()::date)) + 2;
        -- saída em meses para comparar da mesma maneira da GEACO, e soma dois para acrescentar o tempo antes do CA.
        --raise notice '%',mes_atraso;

        dias_atraso = (fn_dateDiff('d', dt_ca, now()::date)) + 60;
        --raise notice '%',dias_atraso ;


        tx_juros = 0.0;
        vl_corrigido = 0.0;
        indice_ca = NULL;
        indice_dia = NULL;
        dt_cal_indice = dt_ca;
        dt_cal_indice_dia = now()::date;


        -- A TABELA DE PARÂMETRO ESTÁ DIFERENTE DA PÁGINA 0 PARA À VISTA = 1 PARA A VISTA NA TABELA E ETC
        IF negociacao = 0 THEN
            tp_negociacao = 1;
        ELSE
            tp_negociacao = 2;
        END IF;

        --ENCONTRA A PENÚLTIMA DATA ÚTIL ANTES DO CA. (O CÁLCULO É ASSIM NO BD CAIXA)
        SELECT INI_DTREF
        into data_ca_util
        FROM TBL_INDICES
        WHERE ini_dtref < dt_cal_indice
        ORDER BY ini_dtref DESC
        limit 1;
        raise notice '%',data_ca_util;

        --ENCONTRA O JUROS, JÁ LIGADO AO CO 048 E BD CAIXA
        SELECT TAXA_JUROS, indexador
        into juros_add,tp_indice
        FROM COM_NEGOCIACAO_PARAMETRO_CONSOLIDACAO
        WHERE FORMA_PAGAMENTO = tp_negociacao
          AND CORTE_SUPERIOR_MESES >= mes_atraso
          AND CORTE_INFERIOR_MESES < mes_atraso
        limit 1;
        --raise notice 'mes_atraso %, tp_negociacao %, juros_add %,tp_indice %',mes_atraso,tp_negociacao, juros_add ,tp_indice ;

        -- CALCULA CORREÇÃO MONETÁRIA
        SELECT ini_fatacum
        into indice_ca
        FROM tbl_indices
        WHERE ind_cod = tp_indice
          AND ini_dtref < data_ca_util
        order by ini_dtref desc
        limit 1;
        SELECT ini_fatacum
        into indice_dia
        FROM tbl_indices
        WHERE ind_cod = tp_indice
          AND ini_dtref < dt_cal_indice_dia
        order by ini_dtref desc
        limit 1;
        --raise notice 'indice_ca % - indice_dia %',indice_ca  ,indice_dia ;

        -- ESTE 'IF' EVITA LOOP INFINITO, E SE ELE FOR FALSO, FAZ O CÁLCULO DO VALOR CORRIGIDO
        IF indice_dia IS NULL OR indice_ca IS null THEN
            vl_corrigido = vl_ca;
            juros_add = 0;
        ELSE
            round_final = (floor((indice_dia / indice_ca) * 10 ^ 13)) / 10 ^ 13; -- obtem 13 casas decimais, desconsiderando AS demais
            vl_corrigido = floor((vl_ca * (round_final)) * 100) / 100;
        END IF;
        --raise notice 'round_final % - vl_corrigido %',round_final,vl_corrigido ;


        --CALCULA OS DIAS CORRIDOS. OS JUROS SÃO CALCULADOS POR DIAS CORRIDOS DIVIDOS POR 30 (MESES COMERCIAL)
        dias_atraso = (fn_datediff('d', data_ca_util, now()::date)) + 60;
        divisao_meses = ((dias_atraso::numeric(18, 13) - 60::numeric(18, 13)) / 30::numeric(18, 13));
        --raise notice 'dias_atraso % - divisao_meses %',dias_atraso,divisao_meses;

        -- CALCULA JUROS --> quando @negociacao = 1 a negociação é a prazo
        tx_juros = floor((vl_corrigido * ((((POW((1 + (juros_add)), ((divisao_meses)))) - 1)))) * 100) / 100;
        -- trunca em 2 casas decimais
        --raise notice 'tx_juros %',tx_juros ;


        valor_atual = floor(((vl_corrigido + tx_juros) * 1.03) * 100) / 100;
        --raise notice 'valor_atual %',valor_atual ;
        RETURN valor_atual::decimal(13, 2);
    END IF;
/*





--EXEMPLO: SP_COM_BOLETO_CALCULA_CO_048 149686.35,'23/12/2011',1
*/

END;
$$;

ALTER FUNCTION neb.sp_com_boleto_calcula_co_048(numeric, date, integer, bigint, boolean) OWNER TO c131481;

GRANT EXECUTE ON FUNCTION neb.sp_com_boleto_calcula_co_048(vl_ca numeric, dt_ca date, negociacao integer, contrato bigint, parametro boolean) TO nebgp_usuario_servico with GRANT option;

GRANT EXECUTE ON FUNCTION neb.sp_com_boleto_calcula_co_048(vl_ca numeric, dt_ca date, negociacao integer, contrato bigint, parametro boolean) TO nebgp_desenvolvedor with GRANT option;

CREATE OR REPLACE FUNCTION neb.sp_com_boleto_calcula_divida_total(contrato bigint, parametro boolean) returns numeric
    language plpgsql
AS
$$
DECLARE
    --DECLARAÇÃO DAS INÚMERAS VARIÁVEIS UTILIZADAS
    divida_total    DECIMAL(13, 2);
    valor_campanha  DECIMAL(13, 2);
    valor_ca        DECIMAL(13, 2);
    dt_ca           DATE;
    valor_co_aprazo DECIMAL(13, 2);
    valor_diferenca DECIMAL(13, 2);
    result          DECIMAL(13, 2);


begin

    -- (1ªRegra) se o @CONTRATO_DIVIDA_TOTAL FOR maior que o @VALOR_CAMPANHA ou @VALOR_CA e menor que (2*@VALOR_CO_APRAZO) então ele é a divida total
-- (2ªRegra) não atendendo a 1ª regra e (2 * @VALOR_CO_APRAZO) FOR maior que o @VALOR_CAMPANHA ou @VALOR_CA então ele é a divida total
-- (3ªRegra) não atendendo AS regras ateriores então @VALOR_CAMPANHA ou @VALOR_CA é a divida total

    select contrato_divida_total,
           contrato_val_ca,
           contrato_data_ca
    into divida_total,
        valor_ca,
        dt_ca
    from vw_com_boleto_dados
    where contrato_numero = contrato;


    select campanha_valor_a_prazo
    into valor_campanha
    from tbl_campanha_contrato
    where contrato_numero = contrato;

    select SP_COM_BOLETO_CALCULA_CO_048(valor_ca, dt_ca::date, 1::integer, contrato, parametro) into valor_co_aprazo;


    IF parametro and valor_campanha > 0 THEN
        valor_ca = valor_campanha;
    END IF;

    IF divida_total > valor_ca and divida_total < (2 * valor_co_aprazo) THEN
        RETURN divida_total::DECIMAL(13, 2);
        --elsif (2 * valor_co_aprazo) > valor_ca THEN
        --	RETURN (2 * valor_co_aprazo)::DECIMAL(13,2);
    ELSE
        --	RETURN valor_ca::DECIMAL(13,2);
        RETURN (2 * valor_co_aprazo)::DECIMAL(13, 2);
    END IF;


--EXEMPLO: sp_com_boleto_calcula_divida_total(430160000015987)

END;
$$;

ALTER FUNCTION neb.sp_com_boleto_calcula_divida_total(bigint, boolean) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.sp_com_boleto_calcula_divida_total(contrato bigint, parametro boolean) TO nebgp_usuario_servico with GRANT option;

GRANT EXECUTE ON FUNCTION neb.sp_com_boleto_calcula_divida_total(contrato bigint, parametro boolean) TO nebgp_desenvolvedor with GRANT option;

CREATE OR REPLACE FUNCTION neb.sp_com_boleto_date_diff(data_inicial date, data_final date) returns integer
    language plpgsql
AS
$$
BEGIN

    SELECT SAIDA = (DATA_FINAL - DATA_INICIAL);
    RETURN (DATA_FINAL - DATA_INICIAL);

END;
$$;

ALTER FUNCTION neb.sp_com_boleto_date_diff(date, date) OWNER TO c131481;

CREATE OR REPLACE FUNCTION neb.sp_com_boleto_price(vvlr_residual numeric, vnum_prestacao integer, vtp_negociacao integer)
    returns TABLE
            (
                saida          numeric,
                taxa_utilizada numeric
            )
    language plpgsql
AS
$$
-- 1) Recebe saldo devedor como valor residual (saldo original - entrada), número de prestações e tipo de negociação, se FOR livre ou 10% é 0, se FOR 1 parcela é 1
declare
-- 2) Declaração Básica das Variaveis, nem todas serao usadas
    vVLR_PRESTACAO DECIMAL(18, 2);
    vTX_JUROS      DECIMAL(18, 13);
    vTESTE_UM      DECIMAL(18, 13);
    vTESTE_DOIS    DECIMAL(18, 13);
    RS             record;
begin
    /*
utilize desta forma (Exemplo)
select * from sp_com_boleto_price (1000.100,10,0);
*/

/*
CÁLCULOS FINANCEIROS - AMORTIZAÇÃO

Valor da Prestação de um financiamento com amortização mensal. Adicionalmente, descubra a Taxa desse financiamento, se já conhecer o valor da prestação.
A fórmula matemática para o Valor da Prestação é a seguinte:
|--------------------------
|                i(1+i)^n      |
| PMT = PV -------------  |
|               (1+i)^n - 1   |
|--------------------------
PMT = PV * ((i*(1+i)^n)/((1+i)^n-1))

onde PMT=Prestação, PV=Valor Financiado, i=Taxa Mensal÷100 e n=Nº de Meses
*/

-- 3) Se FOR tipo 0 inicia aqui
    SELECT ((TAXP_PERCMAX::decimal) / 100) AS TX_JUROS
    into RS
    FROM COM_BOLETO_TAXAS_PARCELAMENTO
    WHERE vNUM_PRESTACAO >= PRAP_MIN
      AND vNUM_PRESTACAO <= PRAP_MAX;
    vTX_JUROS = rs.TX_JUROS;
--raise notice 'vTX_JUROS %',vTX_JUROS;


    IF vtp_negociacao = 0 THEN
        -----------------------------------------------------------
        -- 4) Cálculo da prestação para essa situação
        vVLR_PRESTACAO = floor((((vVLR_RESIDUAL * vTX_JUROS) /
                                 (1 - (1 / (POWER((1 + vTX_JUROS), (vNUM_PRESTACAO))))))) * 100) / 100;

        --raise notice '(vVLR_RESIDUAL % * vTX_JUROS % ) = %, vVLR_PRESTACAO %',vVLR_RESIDUAL,vTX_JUROS,(vVLR_RESIDUAL*vTX_JUROS),vVLR_PRESTACAO;
        --raise notice '%', POWER((1+vTX_JUROS),(vNUM_PRESTACAO));
-----------------------------------------------------------
    elseIF vtp_negociacao = 1 THEN
        -- 5) Se FOR tipo 1 inicia aqui
-----------------------------------------------------------


        -- 6) Cálculo da prestação parte 1 para  entrada sendo 1 parcela
        --SELECT @TESTE_UM=(@TX_JUROS+1), @TESTE_DOIS=CONVERT(FLOAT,((1-POWER((1+@TX_JUROS), (@NUM_PRESTACAO+1)*-1))/@TX_JUROS))
        vTESTE_UM = (vTX_JUROS + 1);
        vTESTE_DOIS = ((1 - POWER((1 + vTX_JUROS), (vNUM_PRESTACAO + 1) * -1)) / vTX_JUROS);

        -- 7) Cálculo da prestação parte 2 para  entrada sendo 1 parcela
        --SELECT @VLR_PRESTACAO=(@VLR_RESIDUAL/(@TESTE_UM*@TESTE_DOIS))
        vVLR_PRESTACAO = (vVLR_RESIDUAL / (vTESTE_UM * vTESTE_DOIS));
        ---------------------------------------------------

    END IF;

-- 8) Saída do Cálculo
    SELECT vVLR_PRESTACAO AS SAIDA, vTX_JUROS AS TAXA_UTILIZADA into RS;

    RETURN query SELECT vVLR_PRESTACAO AS SAIDA, vTX_JUROS AS TAXA_UTILIZADA;

END;
$$;

ALTER FUNCTION neb.sp_com_boleto_price(numeric, integer, integer) OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.sp_com_boleto_price(vvlr_residual numeric, vnum_prestacao integer, vtp_negociacao integer) TO nebgp_usuario_servico with GRANT option;

GRANT EXECUTE ON FUNCTION neb.sp_com_boleto_price(vvlr_residual numeric, vnum_prestacao integer, vtp_negociacao integer) TO nebgp_desenvolvedor with GRANT option;

CREATE OR REPLACE FUNCTION neb.sp_tbl_estatisticas() returns void
    language plpgsql
AS
$$
DECLARE
BEGIN
    TRUNCATE TABLE neb.tbl_estatisticas;

    INSERT INTO neb.tbl_estatisticas
        (item, referencia, data_registro, valor)

    SELECT 'Com qtde boletos'         AS item,
           'emitido hoje'             AS referencia,
           current_timestamp          AS data_registro,
           COUNT(boleto_nosso_numero) AS valor
    FROM neb.com_boleto_proposta
    WHERE boleto_dt_doc >= current_date

    union

    SELECT 'Car qtde boletos'         AS item,
           'emitido hoje'             AS referencia,
           current_timestamp          AS data_registro,
           COUNT(boleto_nosso_numero) AS valor
    FROM neb.car_boleto_proposta
    WHERE boleto_dt_processamento >= current_date

    union

    SELECT 'Hab qtde boletos'         AS item,
           'emitido hoje'             AS referencia,
           current_timestamp          AS data_registro,
           COUNT(boleto_nosso_numero) AS valor
    FROM neb.hab_boleto_proposta
    WHERE boleto_dt_doc >= current_date

    union

    SELECT 'Com vlr boletos' AS item,
           'emitido hoje'    AS referencia,
           current_timestamp AS data_registro,
           SUM(boleto_valor) AS valor
    FROM neb.com_boleto_proposta
    WHERE boleto_dt_doc >= current_date

    union

    SELECT 'Car vlr boletos'        AS item,
           'emitido hoje'           AS referencia,
           current_timestamp        AS data_registro,
           SUM(boleto_valor_maximo) AS valor
    FROM neb.car_boleto_proposta
    WHERE boleto_dt_processamento >= current_date

    union

    SELECT 'Hab qtde boletos' AS item,
           'emitido hoje'     AS referencia,
           current_timestamp  AS data_registro,
           SUM(boleto_valor)  AS valor
    FROM neb.hab_boleto_proposta
    WHERE boleto_dt_doc >= current_date

    union

    SELECT 'Com qtd ctr - Neg'                 AS item,
           'posicao'                           AS referencia,
           CAST(contrato_posicao AS timestamp) AS data_registro,
           COUNT(1)                            AS valor
    FROM neb.com_boleto_dados
    WHERE negociacao_parametro = 1
    GROUP BY contrato_posicao

    union

    SELECT 'Com vlr CA - Neg'                  AS item,
           'posicao'                           AS referencia,
           CAST(contrato_posicao AS timestamp) AS data_registro,
           SUM(contrato_val_ca)                AS valor
    FROM neb.com_boleto_dados
    WHERE negociacao_parametro = 1
    GROUP BY contrato_posicao

    union

    SELECT 'Car qtd ctr - Neg'                 AS item,
           'posicao'                           AS referencia,
           CAST(contrato_posicao AS timestamp) AS data_registro,
           COUNT(1)                            AS valor
    FROM neb.car_boleto_dados
    WHERE negociacao_parametro = 1
    GROUP BY contrato_posicao

    union

    SELECT 'Car vlr CA - Neg'                  AS item,
           'posicao'                           AS referencia,
           CAST(contrato_posicao AS timestamp) AS data_registro,
           SUM(contrato_val_ca)                AS valor
    FROM neb.car_boleto_dados
    WHERE negociacao_parametro = 1
    GROUP BY contrato_posicao

    union

    SELECT 'Hab qtd ctr - Neg'                 AS item,
           'posicao'                           AS referencia,
           CAST(contrato_posicao AS timestamp) AS data_registro,
           COUNT(1)                            AS valor
    FROM neb.hab_boleto_dados
    WHERE negociacao_parametro = 1
    GROUP BY contrato_posicao

    union

    SELECT 'Hab vlr CA - Neg'                  AS item,
           'posicao'                           AS referencia,
           CAST(contrato_posicao AS timestamp) AS data_registro,
           SUM(contrato_val_ca)                AS valor
    FROM neb.hab_boleto_dados
    WHERE negociacao_parametro = 1
    GROUP BY contrato_posicao
    ORDER BY data_registro DESC
           , item;

END;
$$;

ALTER FUNCTION neb.sp_tbl_estatisticas() OWNER TO neb;

GRANT EXECUTE ON FUNCTION neb.sp_tbl_estatisticas() TO nebgp_desenvolvedor with GRANT option;

GRANT EXECUTE ON FUNCTION neb.sp_tbl_estatisticas() TO nebgp_usuario_servico with GRANT option;

