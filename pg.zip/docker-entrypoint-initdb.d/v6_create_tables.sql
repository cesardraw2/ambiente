-- Adminer 4.8.1 PostgreSQL 12.5 dump

\connect "posdes02";

CREATE TABLE "neb"."car_acordo_detalhes" (
    "cod_entidade" integer,
    "cod_agencia" integer,
    "numero_conta" bigint,
    "num_parcela" integer,
    "dt_parcela" date,
    "dt_pagto_parce" date,
    "snl_vlr_parcela" character varying(1),
    "vlr_parcela" numeric(13,2),
    "snl_vlr_pago" character varying(1),
    "vlr_pago" numeric(13,2),
    "situacao_parcela" character varying(30),
    "snl_vlr_pagar" character varying(1),
    "vlr_pagar" numeric(13,2),
    "snl_vlr_juro_atraso" character varying(1),
    "vlr_juro_atraso" numeric(13,2),
    "snl_vlr_mora_atraso" character varying(1),
    "vlr_mora_atraso" numeric(13,2),
    "snl_vlr_multa_atraso" character varying(1),
    "vlr_multa_atraso" numeric(13,2),
    "snl_vlr_iof_atraso" character varying(1),
    "vlr_iof_atraso" numeric(13,2)
) WITH (oids = false);


CREATE TABLE "neb"."car_bin" (
    "car_bin_cod" integer NOT NULL,
    "car_bin_desc" character varying(50),
    "car_bin_sac" character varying(150),
    CONSTRAINT "pk_car_bin_cod" PRIMARY KEY ("car_bin_cod")
) WITH (oids = false);

CREATE INDEX "car_bin_car_bin_cod_idx" ON "neb"."car_bin" USING btree ("car_bin_cod");


CREATE TABLE "neb"."car_boleto_dados" (
    "contrato_numero" bigint NOT NULL,
    "contrato_cpf_cnpj" bigint,
    "contrato_ativo" bit(1),
    "contrato_pv" integer,
    "contrato_sistema_cod" smallint,
    "contrato_cliente_tipo_cod" smallint,
    "contrato_op_cod" integer,
    "contrato_nome" character varying(100),
    "contrato_dias_atraso" integer,
    "contrato_divida_total" numeric(13,2),
    "contrato_val_ca" numeric(13,2),
    "contrato_data_ca" date,
    "contrato_garantia_tipo" smallint,
    "ajuizado" bit(1),
    "empresa_cobranca_cod" integer,
    "contrato_girec_cod" integer,
    "negociacao_parametro" smallint,
    "contrato_formatado" character varying(16),
    "contrato_posicao" date,
    CONSTRAINT "pk_car_boleto_dados" PRIMARY KEY ("contrato_numero")
) WITH (oids = false);

CREATE INDEX "car_boleto_dados_contrato_cpf_cnpj_idx" ON "neb"."car_boleto_dados" USING btree ("contrato_cpf_cnpj");


CREATE TABLE "neb"."car_boleto_dados_fixos" (
    "contrato_numero" bigint NOT NULL,
    "linha_digitavel" character varying(43),
    "cedente" character varying(40),
    "codigo_cedente" character varying(21),
    "data_documento" date,
    "aceite" character varying(1),
    "carteira" character varying(2),
    "moeda" character varying(2),
    "cnpj_cpf" bigint,
    "numero_cartao" character varying(22),
    "nosso_numero" character varying(16),
    "vencimento_boleto" date,
    "pagamento_minimo" numeric(13,2),
    "codigo_de_barras" character varying(44),
    "data_processamento" date,
    CONSTRAINT "pk_car_boleto_dados_fixos" PRIMARY KEY ("contrato_numero")
) WITH (oids = false);

CREATE INDEX "car_boleto_dados_fixos_contrato_numero_idx" ON "neb"."car_boleto_dados_fixos" USING btree ("contrato_numero");


CREATE TABLE "neb"."car_boleto_dados_proposta" (
    "contrato_numero" bigint NOT NULL,
    "qtd_parc_proposta" integer NOT NULL,
    "vlr_cada_parcela" numeric(13,2),
    "vlr_iof" numeric(13,2),
    "vlr_prim_parcela_c_iof" numeric(13,2),
    "vlr_total" numeric(13,2),
    "vlr_juros_prop" numeric(13,2),
    "vlr_custo_efetivo" numeric(13,2),
    CONSTRAINT "pk_car_boleto_dados_proposta" PRIMARY KEY ("contrato_numero", "qtd_parc_proposta")
) WITH (oids = false);

CREATE INDEX "car_boleto_dados_proposta_contrato_numero_idx" ON "neb"."car_boleto_dados_proposta" USING btree ("contrato_numero");


CREATE TABLE "neb"."car_boleto_proposta" (
    "boleto_nosso_numero" bigint NOT NULL,
    "boleto_dt_vencto" date,
    "boleto_dt_processamento" timestamp,
    "boleto_usuario" bigint,
    "boleto_unidade_responsavel" integer,
    "boleto_contrato" bigint,
    "boleto_valor_maximo" numeric(13,2)
) WITH (oids = false);


CREATE TABLE "neb"."car_pcspogca" (
    "cod_entidade" integer,
    "cod_agencia" integer,
    "numero_conta" bigint,
    "cliente_nome" character varying(40),
    "cliente_ddd_fone_comercial" integer,
    "cliente_fone_comercial" bigint,
    "cliente_ddd_fone_celular" integer,
    "cliente_fone_celular" bigint,
    "cliente_end_correspo" character varying(40),
    "cliente_bairro_end_correspo" character varying(15),
    "cliente_cidade_end_correspo" character varying(40),
    "cliente_uf_end_correspo" character varying(2),
    "cliente_cep_end_correspo" bigint,
    "cliente_pais_end_correspo" character varying(25),
    "cod_produto" bigint,
    "snl_saldo_fatura" character varying(1),
    "vlr_saldo_fatura" numeric(13,2),
    "cod_situacao_conta" integer,
    "dt_corte" date,
    "vlr_min_fatura_cob" numeric(13,2),
    "dt_dia_venc_fatura" date,
    "limite" numeric(13,2),
    "bloqueio" character varying(40),
    "atributo" character varying(25),
    "atraso_conta" integer,
    "pessoa_tipo" character varying(5),
    "cpf_cnpj" bigint,
    "dt_nascimento" date,
    "ic_classif_conta" character varying(2),
    "espaco_em_branco_1" integer,
    "dt_devolucao_ult_cheque" date,
    "espaco_em_branco_2" integer,
    "dt_abertura_conta" date,
    "dt_ultima_compra" date,
    "snl_saldo_atual_atraso" character varying(1),
    "vlr_saldo_atual_atraso" numeric(13,2),
    "dt_inclu_negativacao" date,
    "juro_mora" numeric(13,2),
    "dt_solic_negativacao" date,
    "dt_reabil_negativacao" date,
    "dt_ajuizamento" date,
    "snl_saldo_enquadrado" character varying(1),
    "vlr_saldo_enquadrado" numeric(13,2),
    "dt_enquadramento" date,
    "snl_saldo_atualizado" character varying(1),
    "vlr_saldo_atualizado" numeric(13,2),
    "snl_correc_monet_enquad" character varying(1),
    "vlr_correc_monet_enquad" numeric(13,2),
    "snl_atual_enquad" character varying(1),
    "vlr_atual_enquad" numeric(13,2),
    "cliente_end_resid" character varying(40),
    "cliente_bairro_end_resid" character varying(15),
    "cliente_cidade_end_resid" character varying(40),
    "cliente_uf_end_resid" character varying(2),
    "cliente_cep_end_resid" character varying(9),
    "cliente_ddd_fone_resid" integer,
    "cliente_fone_resid" integer,
    "codigo_barras" character varying(50),
    "dias_atraso_enquad" integer,
    "desc_status_acordo" character varying(30),
    "desc_situacao_conta" character varying(30),
    "desc_behavior_score" character varying(30),
    "cod_class_comportamento" integer,
    "vlr_limite_saque" numeric(13,2),
    "vlr_uso_limite_saque" numeric(13,2),
    "vlr_creditos_ciclo" numeric(13,2),
    "vlr_debitos_ciclo" numeric(13,2),
    "vlr_total_pagtos_ciclo" numeric(13,2),
    "vlr_saldo_parc_com_juros" numeric(13,2),
    "vlr_saldo_parc_sem_juros" numeric(13,2),
    "vlr_saldo_parc_acelerado" numeric(13,2),
    "dt_entrada_cobranca" date,
    "vlr_tarifa_aplcda" numeric(13,2),
    "ic_primeira_fatura_atraso" character varying(2),
    "dt_procto_ultimo_pgto" date,
    "vlr_encargo_contratual" numeric(13,2),
    "vlr_imposto" numeric(13,2),
    "vlr_credito_posterior_enqdo" numeric(13,2),
    "vlr_debito_posterior_enqdo" numeric(13,2),
    "dias_atraso_cobranca" integer,
    "vlr_correcao_monet_enquad" numeric(13,2),
    "ic_status_acordo" character varying(2),
    "vlr_imposto_enqdo" numeric(13,2),
    "snl_juro_enqdo" character varying(1),
    "vlr_juro_enqdo" numeric(13,2),
    "ic_cheque_devolvido" character varying(1),
    "no_indicador_negativacao" character varying(50),
    "vlr_uso_limite_cdr" numeric(13,2),
    "vlr_multa_atraso" numeric(13,2),
    "flag_saldo_pendente" character varying(1),
    "vlr_jrs_acrd_aplicar" numeric(13,2),
    "vlr_enc_acrd_pendente" numeric(13,2),
    "co_tipo_acao_paral" character varying(1),
    "de_tipo_acao_paral" character varying(30),
    "num_carteira" integer,
    "linha_digitavel" character varying(54),
    "cnpj_cob_externa" bigint,
    "nome_cob_externa" character varying(60),
    "fone_cob_externa" bigint
) WITH (oids = false);

CREATE INDEX "ix_car_pcspogca_1" ON "neb"."car_pcspogca" USING btree ("cod_entidade", "cod_agencia", "numero_conta");


CREATE TABLE "neb"."car_pcspogca_bloqueio_cartao" (
    "cod_entidade" integer,
    "cod_agencia" integer,
    "numero_conta" bigint,
    "dt_bloqueio" date,
    "tipo_bloqueio" character varying(30)
) WITH (oids = false);

CREATE INDEX "ix_pcspogca_bloqueio_cartao_1" ON "neb"."car_pcspogca_bloqueio_cartao" USING btree ("cod_entidade", "cod_agencia", "numero_conta");


CREATE TABLE "neb"."car_pcspogcd" (
    "cod_entidade" integer,
    "cod_agencia" integer,
    "numero_conta" bigint,
    "numero_acordo" integer,
    "cod_acesso" integer,
    "desc_cod_acesso" character varying(50),
    "snl_vlr_atual" character varying(1),
    "vlr_atual" numeric(13,2),
    "snl_vlr_ult_pgto" character varying(1),
    "vlr_ult_pgto" numeric(13,2),
    "qtde_parcelas" integer,
    "dt_acordo" date,
    "sta_acordo" integer,
    "desc_sta_acordo" character varying(50)
) WITH (oids = false);

CREATE INDEX "ix_car_pcspogcd_1" ON "neb"."car_pcspogcd" USING btree ("cod_entidade", "cod_agencia", "numero_conta");


CREATE TABLE "neb"."car_pcspogce" (
    "cod_entidade" integer,
    "cod_agencia" integer,
    "numero_conta" bigint,
    "clave_fin" character varying(200),
    "ind_mas_datos" character varying(1),
    "qtde_total_ocor" integer,
    "qtde_ocor_tela" integer,
    "snl_vlr_acordo" character varying(1),
    "vlr_acordo" numeric(13,2),
    "snl_vlr_juro_acordo" character varying(1),
    "vlr_juro_acordo" numeric(13,2),
    "vlr_desconto_acordo" numeric(13,2),
    "snl_vlr_entrada" character varying(1),
    "vlr_entrada" numeric(13,2),
    "dt_pagto_entrada" date,
    "snl_vlr_iof_atraso" character varying(1),
    "vlr_iof_atraso" numeric(13,2),
    "snl_vlr_iof_projetado" character varying(1),
    "vlr_iof_projetado" numeric(13,2),
    "snl_vlr_iof_pago" character varying(1),
    "vlr_iof_pago" numeric(13,2),
    "snl_vlr_crco_mntra" character varying(1),
    "vlr_crco_mntra" numeric(13,2),
    "snl_vlr_mora" character varying(1),
    "vlr_mora" numeric(13,2),
    "pc_aplco_inde_enco" numeric(13,2),
    "usuario_alt" character varying(8),
    "vlr_parcela_antpo" numeric(13,2),
    "dt_tlrna_pgmo_anto" date,
    "email_cliente" character varying(50),
    "flag_tem_antec" character varying(1),
    "nu_campanha_admva" integer
) WITH (oids = false);


CREATE TABLE "neb"."com_boleto_cliente" (
    "boleto_nosso_numero" bigint NOT NULL,
    "boleto_cpf_cnpj" bigint NOT NULL,
    "boleto_cliente" character varying(50),
    "boleto_tipo_cliente" smallint,
    "endereco_descricao" smallint NOT NULL,
    "endereco_logradouro_abr" character varying(10),
    "endereco_logradouro" character varying(100),
    "endereco_numero" character varying(10),
    "endereco_complemento" character varying(50),
    "endereco_bairro" character varying(50),
    "endereco_cidade" character varying(50),
    "endereco_uf" character varying(2),
    "endereco_cep" character varying(10),
    "endereco_dados_extras" character varying(100),
    "endereco_atualizado" smallint,
    "endereco_email" character varying(200),
    "endereco_data_inclusao" timestamp,
    "endereco_ddd_1" smallint,
    "endereco_fone_1" bigint,
    "endereco_ddd_2" smallint,
    "endereco_fone_2" bigint,
    "cliente_dt_nasc" timestamp,
    "cliente_sexo" character(1),
    "cliente_cod_estado_civil" smallint,
    "cliente_nacionalidade" character varying(50),
    "cliente_ident_numero" bigint,
    "cliente_ident_emissor_uf" character(2),
    "cliente_ident_emissor_orgao" character varying(10),
    "cliente_ident_emissor_data" timestamp,
    "cliente_pis_pasep" bigint,
    CONSTRAINT "pk_com_boleto_cliente" PRIMARY KEY ("boleto_nosso_numero")
) WITH (oids = false);

CREATE INDEX "boleto_nosso_numero_idx01" ON "neb"."com_boleto_cliente" USING btree ("boleto_nosso_numero");

CREATE INDEX "com_boleto_cliente_boleto_cpf_cnpj_idx" ON "neb"."com_boleto_cliente" USING btree ("boleto_cpf_cnpj");


CREATE SEQUENCE com_boleto_contrato_boleto_contrato_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 4073774 CACHE 1;

CREATE TABLE "neb"."com_boleto_contrato" (
    "boleto_contrato_id" bigint DEFAULT nextval('com_boleto_contrato_boleto_contrato_id_seq') NOT NULL,
    "contrato_numero" bigint NOT NULL,
    "boleto_nosso_numero" bigint NOT NULL,
    "contrato_vlr_renegociado" numeric(13,2) NOT NULL,
    "contrato_sistema" smallint NOT NULL,
    "contrato_pv_cod" smallint,
    "contrato_vlr_renegociado_original" numeric(13,2) DEFAULT '0',
    "contrato_vlr_renegociado_alterado" numeric(13,2) DEFAULT '0',
    "contrato_campanha_renegociado" smallint DEFAULT '0',
    CONSTRAINT "pk_com_boleto_contrato" PRIMARY KEY ("contrato_numero", "boleto_nosso_numero")
) WITH (oids = false);

CREATE INDEX "boleto_contrato_id_idx" ON "neb"."com_boleto_contrato" USING btree ("boleto_contrato_id");

CREATE INDEX "boleto_nosso_numero_idx" ON "neb"."com_boleto_contrato" USING btree ("boleto_nosso_numero");


CREATE TABLE "neb"."com_boleto_dados" (
    "contrato_numero" bigint NOT NULL,
    "contrato_cpf_cnpj" bigint,
    "contrato_ativo" bit(1),
    "contrato_pv" integer,
    "contrato_sistema_cod" smallint,
    "contrato_cliente_tipo_cod" smallint,
    "contrato_op_cod" smallint,
    "contrato_nome" character varying(100),
    "contrato_dias_atraso" integer,
    "contrato_divida_total" numeric(13,2),
    "contrato_val_ca" numeric(13,2),
    "contrato_data_ca" date,
    "contrato_garantia_tipo" smallint,
    "ajuizado" bit(1),
    "empresa_cobranca_cod" integer,
    "contrato_girec_cod" integer,
    "negociacao_parametro" smallint,
    "contrato_posicao" date,
    CONSTRAINT "pk_com_boleto_dados" PRIMARY KEY ("contrato_numero")
) WITH (oids = false);

CREATE INDEX "com_boleto_dados_contrato_cpf_cnpj_idx" ON "neb"."com_boleto_dados" USING btree ("contrato_cpf_cnpj");


CREATE TABLE "neb"."com_boleto_dados_ext_negociacao_parametro" (
    "negociacao_parametro" integer NOT NULL,
    "descricao" character varying(50),
    CONSTRAINT "pk_com_boleto_dados_ext_negociacao_parametro" PRIMARY KEY ("negociacao_parametro")
) WITH (oids = false);


CREATE TABLE "neb"."com_boleto_operacoes_parametro" (
    "boleto_operacao_cod" smallint NOT NULL,
    "boleto_operacao_descricao" character varying(200),
    "boleto_operacao_tipo_liquidacao" smallint,
    "boleto_operacao_tipo_prestacao" smallint,
    "boleto_operacao_tipo_renegociacao" bit(1),
    "boleto_operacao_sistema" smallint,
    "boleto_max_prestacao" integer,
    "boleto_operacao_on_off" bit(1),
    "boleto_operacao_lote_on_off" bit(1),
    "boleto_operacao_sineb_on_off" bit(1),
    "boleto_renegocia_garantia_real" bit(1),
    CONSTRAINT "pk_boleto_operacao" PRIMARY KEY ("boleto_operacao_cod")
) WITH (oids = false);

CREATE INDEX "boleto_operacao_idx" ON "neb"."com_boleto_operacoes_parametro" USING btree ("boleto_operacao_cod");


CREATE TABLE "neb"."com_boleto_proposta" (
    "boleto_nosso_numero" bigint NOT NULL,
    "boleto_tipo" smallint,
    "boleto_dt_vencto" date,
    "boleto_cod_cedente" bigint,
    "boleto_dt_doc" date,
    "boleto_numero_doc" bigint,
    "boleto_dt_processamento" date,
    "boleto_valor" numeric(13,2),
    "boleto_vlr_parcela_termo" numeric(13,2),
    "boleto_qtde_parcela_termo" smallint,
    "boleto_emissao_externo" smallint,
    "boleto_unidade_responsavel" integer,
    "boleto_forma_envio" smallint,
    "boleto_critica_191" smallint,
    "boleto_pv_reneg" smallint,
    "boleto_vlr_iof" numeric(13,2),
    "boleto_taxa_juros_191" numeric(18,5),
    "boleto_valor_original" numeric(13,2),
    "boleto_valor_alt_flag" smallint,
    "boleto_usuario" bigint,
    "boleto_empct_codigo" integer,
    CONSTRAINT "pk_com_boleto_proposta" PRIMARY KEY ("boleto_nosso_numero")
) WITH (oids = false);


CREATE TABLE "neb"."com_boleto_proposta_tipo" (
    "boleto_proposta_tipo_id" smallint,
    "boleto_proposta_tipo_nome" character varying(30)
) WITH (oids = false);


CREATE TABLE "neb"."com_boleto_taxas_parcelamento" (
    "tipt_cod" smallint,
    "tipt_desc" character varying(50),
    "prap_cod" smallint NOT NULL,
    "prap_min" smallint,
    "prap_max" smallint,
    "taxp_cod" smallint,
    "taxp_percmin" numeric(13,2),
    "taxp_percmax" numeric(13,2),
    CONSTRAINT "pk_com_boleto_taxas_parcelamento" PRIMARY KEY ("prap_cod")
) WITH (oids = false);


CREATE TABLE "neb"."com_contrato_garantia" (
    "contrato_numero" bigint NOT NULL,
    "contrato_garantia_id" smallint NOT NULL,
    CONSTRAINT "pk_com_contrato_garantia" PRIMARY KEY ("contrato_numero", "contrato_garantia_id")
) WITH (oids = false);

CREATE INDEX "contrato_numero_idx" ON "neb"."com_contrato_garantia" USING btree ("contrato_numero");


CREATE TABLE "neb"."com_execucao_processo_judicial" (
    "contrato_numero" bigint NOT NULL,
    "exp_codigo" bigint,
    "dt_inclusao" timestamp,
    "codigo" numeric(20,0),
    "dta_juizamento" timestamp,
    "tipo_codigo" smallint,
    "acao_tipo_desc" character varying(40),
    "vlr_custas" numeric(13,2),
    "dt_custas" timestamp,
    CONSTRAINT "pk_contrato_numero" PRIMARY KEY ("contrato_numero")
) WITH (oids = false);

CREATE INDEX "processo_judicial_contrato_numero_idx" ON "neb"."com_execucao_processo_judicial" USING btree ("contrato_numero");


CREATE TABLE "neb"."com_garantia" (
    "garantia_id" smallint NOT NULL,
    "garantia_descricao" character varying(100),
    CONSTRAINT "pk_garantia_id" PRIMARY KEY ("garantia_id")
) WITH (oids = false);

CREATE INDEX "garantia_cod_idx" ON "neb"."com_garantia" USING btree ("garantia_id");


CREATE TABLE "neb"."com_negociacao_parametro_consolidacao" (
    "corte_inferior_meses" smallint,
    "corte_superior_meses" smallint,
    "forma_pagamento" smallint,
    "indexador" smallint,
    "taxa_juros" numeric(10,4)
) WITH (oids = false);


CREATE TABLE "neb"."com_operacao" (
    "operacao_cod" smallint NOT NULL,
    "operacao_descricao" character varying(100),
    CONSTRAINT "pk_com_operacao" PRIMARY KEY ("operacao_cod")
) WITH (oids = false);

CREATE INDEX "com_operacao_operacao_cod_idx" ON "neb"."com_operacao" USING btree ("operacao_cod");


CREATE TABLE "neb"."com_operacao_imp" (
    "inport" character varying(400)
) WITH (oids = false);


CREATE TABLE "neb"."hab_boleto_dados" (
    "contrato_numero" bigint NOT NULL,
    "contrato_cpf_cnpj" bigint,
    "contrato_ativo" bit(1),
    "contrato_pv" integer,
    "contrato_sistema_cod" smallint,
    "contrato_cliente_tipo_cod" smallint,
    "contrato_op_cod" smallint,
    "contrato_nome" character varying(100),
    "contrato_dias_atraso" integer,
    "contrato_divida_total" numeric(13,2),
    "contrato_val_ca" numeric(13,2),
    "contrato_data_ca" date,
    "contrato_garantia_tipo" smallint,
    "ajuizado" bit(1),
    "empresa_cobranca_cod" integer,
    "contrato_girec_cod" integer,
    "negociacao_parametro" smallint,
    "contrato_posicao" date,
    "contrato_dv" integer,
    CONSTRAINT "pk_hab_boleto_dados" PRIMARY KEY ("contrato_numero")
) WITH (oids = false);

CREATE INDEX "hab_boleto_dados_contrato_cpf_cnpj_idx" ON "neb"."hab_boleto_dados" USING btree ("contrato_cpf_cnpj");


CREATE TABLE "neb"."hab_boleto_dados_ext_negociacao_parametro" (
    "negociacao_parametro" integer,
    "descricao" character varying(50)
) WITH (oids = false);


CREATE TABLE "neb"."hab_boleto_proposta" (
    "boleto_proposta" bigint NOT NULL,
    "contrato_numero" bigint NOT NULL,
    "contrato_cpf_cnpj" bigint NOT NULL,
    "boleto_cedente" bigint,
    "boleto_nosso_numero" bigint,
    "contrato_prest_atraso" smallint,
    "boleto_valor" numeric(13,2),
    "boleto_emissor" character varying(11),
    "boleto_ncpd" character varying(4),
    "boleto_data_vencimento" date,
    "boleto_dt_doc" date,
    "boleto_incorporado" smallint,
    "boleto_pago" smallint,
    "boleto_pago_dt" date,
    "boleto_pago_vlr" numeric(13,2),
    "boleto_tp_116" smallint,
    "boleto_tp_116_dt" date,
    "boleto_pa_contrato" integer,
    "boleto_pa_responsavel" integer,
    "boleto_data_vencimento_real" date,
    "boleto_lote_tipo" smallint,
    "boleto_lote_enviado" smallint,
    "boleto_lote_quantidade_meses_pausa" smallint,
    "boleto_lote_lista_meses_pausa" character varying(200),
    "boleto_emissao_externo" smallint,
    CONSTRAINT "pk_hab_boleto_proposta" PRIMARY KEY ("boleto_proposta")
) WITH (oids = false);


CREATE TABLE "neb"."hab_produto" (
    "produto_cod" smallint NOT NULL,
    "produto_dv" smallint,
    "produto_desc" character varying(100),
    "produto_tipo_credor" smallint,
    "siico_produto_id" smallint,
    "sis_num" smallint,
    CONSTRAINT "pk_produto_cod" PRIMARY KEY ("produto_cod")
) WITH (oids = false);

CREATE INDEX "hab_produto_produto_cod_idx" ON "neb"."hab_produto" USING btree ("produto_cod");


CREATE TABLE "neb"."nebtbf51_acordo_ngcco_cartao" (
    "nu_contrato_acordo" bigint NOT NULL,
    "dt_inclusao_acordo" date NOT NULL,
    "nu_cpf_solicitante_acordo" bigint NOT NULL,
    "nu_cpf_cliente_contrato" bigint NOT NULL,
    "nu_agencia_origem_contrato" integer NOT NULL,
    "de_conteudo_acordo_xml_envio" text,
    "de_conteudo_acordo_xml_retorno" text,
    "vr_total_acordo" numeric(13,2),
    "vr_entrada_acordo" numeric(13,2),
    "qt_parcela_acordo" integer,
    "vr_parcela_acordo" numeric(13,2),
    "vr_iof_acordo" numeric(13,2),
    "vr_desconto_acordo" numeric(13,2),
    CONSTRAINT "pk_nebtbf51_acordo_ngcco_carta" PRIMARY KEY ("nu_contrato_acordo", "dt_inclusao_acordo")
) WITH (oids = false);


CREATE SEQUENCE tbl_atualizacao_arquivos_arquivo_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "neb"."tbl_atualizacao_arquivos" (
    "arquivo_id" integer DEFAULT nextval('tbl_atualizacao_arquivos_arquivo_id_seq') NOT NULL,
    "arquivo_nome" character varying(100),
    "sineb_tabela_destino" character varying(100),
    "ordem" integer,
    "carregar" integer,
    "exportar" integer,
    "sistema" integer,
    "transmitir" integer,
    "sigbd_transmite" character varying(50),
    CONSTRAINT "pk_tbl_atualizacao_arquivos" PRIMARY KEY ("arquivo_id")
) WITH (oids = false);


CREATE SEQUENCE tbl_atualizacao_tabelas_colunas_registro_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "neb"."tbl_atualizacao_tabelas_colunas" (
    "registro_id" integer DEFAULT nextval('tbl_atualizacao_tabelas_colunas_registro_id_seq') NOT NULL,
    "tabela_nome" character varying(100),
    "coluna_nome" character varying(100),
    "indice_tipo" character varying(2),
    "indice_nome" character varying(100),
    CONSTRAINT "pk_tbl_atualizacao_tabelas_colunas" PRIMARY KEY ("registro_id")
) WITH (oids = false);


CREATE SEQUENCE tbl_atualizacao_views_arquivo_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "neb"."tbl_atualizacao_views" (
    "arquivo_id" integer DEFAULT nextval('tbl_atualizacao_views_arquivo_id_seq') NOT NULL,
    "view_nome" character varying(100),
    "view_definicao" character varying,
    CONSTRAINT "pk_tbl_atualizacao_views" PRIMARY KEY ("arquivo_id")
) WITH (oids = false);


CREATE SEQUENCE tbl_atualizacao_views_dependencia_arquivo_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "neb"."tbl_atualizacao_views_dependencia" (
    "arquivo_id" integer DEFAULT nextval('tbl_atualizacao_views_dependencia_arquivo_id_seq') NOT NULL,
    "view_nome" character varying(100),
    "objeto_tipo" character varying(100),
    "objeto_nome" character varying(100),
    CONSTRAINT "pk_tbl_atualizacao_views_dependencia" PRIMARY KEY ("arquivo_id")
) WITH (oids = false);


CREATE TABLE "neb"."tbl_atualizacao_zlog" (
    "log_rotina" character varying(100),
    "log_rotina_passo" character varying(100),
    "log_rotina_passo_observacao" character varying(100),
    "log_data_reg" timestamp
) WITH (oids = false);


CREATE TABLE "neb"."tbl_auditorialog" (
    "auditorialog_cpf_cnpj" bigint,
    "auditorialog_ip" character varying(50) NOT NULL,
    "auditorialog_url" character varying(100),
    "auditorialog_dataacesso" timestamp
) WITH (oids = false);


CREATE SEQUENCE tbl_cadastro_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "neb"."tbl_cadastro" (
    "endereco_cpf_cnpj" bigint NOT NULL,
    "endereco_logradouro_abr" character varying(10),
    "endereco_logradouro" character varying(100),
    "endereco_numero" character varying(10),
    "endereco_complemento" character varying(50),
    "endereco_bairro" character varying(50),
    "endereco_cidade" character varying(50),
    "endereco_uf" character varying(2),
    "endereco_cep" character varying(10),
    "endereco_dados_extras" character varying(100),
    "endereco_fone_1" character varying(20),
    "endereco_fone_2" character varying(20),
    "endereco_email" character varying(200),
    "endereco_data_inclusao" timestamp,
    "id" bigint DEFAULT nextval('tbl_cadastro_id_seq') NOT NULL,
    CONSTRAINT "tbl_cadastro_id_uindex" UNIQUE ("id")
) WITH (oids = false);


CREATE SEQUENCE tbl_campanha_contrato_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "neb"."tbl_campanha_contrato" (
    "contrato_numero" bigint NOT NULL,
    "campanha_valor_a_vista" numeric(13,2),
    "campanha_valor_a_prazo" numeric(13,2),
    "campanha_prazo" integer,
    "campanha_vigencia" date,
    "id" bigint DEFAULT nextval('tbl_campanha_contrato_id_seq') NOT NULL,
    CONSTRAINT "pk_tbl_campanha_contrato" PRIMARY KEY ("contrato_numero")
) WITH (oids = false);


CREATE SEQUENCE tbl_cliente_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 17661251 CACHE 1;

CREATE TABLE "neb"."tbl_cliente" (
    "cliente_cpf_cnpj" bigint,
    "cliente_nome" character varying(100),
    "cliente_dt_nasc" timestamp,
    "cliente_sexo" character(1),
    "cliente_cod_estado_civil" smallint,
    "cliente_nacionalidade" character varying(50),
    "cliente_ident_numero" bigint,
    "cliente_ident_emissor_uf" character(2),
    "cliente_ident_emissor_orgao" character varying(10),
    "cliente_ident_emissor_data" timestamp,
    "cliente_pis_pasep" bigint,
    "cliente_empresa_setor_cod" smallint,
    "cliente_empresa_natureza_cod" smallint,
    "cliente_empresa_represent_nome" character varying(50),
    "cliente_empresa_represent_cpf" bigint,
    "cliente_segmento" character varying(4),
    "cliente_gerente_matricula" character varying(7),
    "id" bigint DEFAULT nextval('tbl_cliente_id_seq') NOT NULL
) WITH (oids = false);

CREATE INDEX "cliente_cpf_cnpj_idx" ON "neb"."tbl_cliente" USING btree ("cliente_cpf_cnpj");


CREATE SEQUENCE tbl_cliente_bloqueio_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 1599294 CACHE 1;

CREATE TABLE "neb"."tbl_cliente_bloqueio" (
    "cliente_cpf_cnpj" bigint NOT NULL,
    "cliente_dt_bloqueio" timestamp,
    "id" bigint DEFAULT nextval('tbl_cliente_bloqueio_id_seq') NOT NULL
) WITH (oids = false);

CREATE INDEX "ix_tbl_cli_blq_cpf_cnpj" ON "neb"."tbl_cliente_bloqueio" USING btree ("cliente_cpf_cnpj");


CREATE SEQUENCE tbl_cliente_empresa_natureza_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "neb"."tbl_cliente_empresa_natureza" (
    "cliente_empresa_natureza_cod" smallint,
    "cliente_empresa_natureza_desc" character varying(50),
    "id" bigint DEFAULT nextval('tbl_cliente_empresa_natureza_id_seq') NOT NULL
) WITH (oids = false);


CREATE SEQUENCE tbl_cliente_empresa_setor_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "neb"."tbl_cliente_empresa_setor" (
    "cliente_empresa_setor_cod" smallint,
    "cliente_empresa_setor_desc" character varying(50),
    "id" bigint DEFAULT nextval('tbl_cliente_empresa_setor_id_seq') NOT NULL
) WITH (oids = false);


CREATE SEQUENCE tbl_email_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 1731285 CACHE 1;

CREATE TABLE "neb"."tbl_email" (
    "email_cpf_cnpj" bigint,
    "email_descricao" smallint,
    "email_endereco" character varying(100),
    "email_usuario_matricula" character(20),
    "email_usuario_unidade" smallint,
    "email_data_cadastro" date,
    "email_data_alteracao" date,
    "email_valido" bit(1),
    "id" bigint DEFAULT nextval('tbl_email_id_seq') NOT NULL
) WITH (oids = false);

CREATE INDEX "tbl_email_email_cpf_cnpj_idx" ON "neb"."tbl_email" USING btree ("email_cpf_cnpj");


CREATE SEQUENCE tbl_empct_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 31 CACHE 1;

CREATE TABLE "neb"."tbl_empct" (
    "empct_codigo" integer NOT NULL,
    "empct_nome" character varying(50),
    "empct_cnpj" bigint,
    "empct_segmento_credito" integer,
    "id" bigint DEFAULT nextval('tbl_empct_id_seq') NOT NULL,
    CONSTRAINT "tbl_empct_id_uindex" UNIQUE ("id"),
    CONSTRAINT "tbl_empct_pkey" PRIMARY KEY ("empct_codigo")
) WITH (oids = false);


CREATE SEQUENCE tbl_empct_imp_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 36 CACHE 1;

CREATE TABLE "neb"."tbl_empct_imp" (
    "empct_codigo" character varying(4000),
    "empct_nome" character varying(400),
    "empct_cnpj" character varying(400),
    "id" bigint DEFAULT nextval('tbl_empct_imp_id_seq') NOT NULL
) WITH (oids = false);


CREATE SEQUENCE tbl_endereco_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 16974263 CACHE 1;

CREATE TABLE "neb"."tbl_endereco" (
    "endereco_cpf_cnpj" bigint,
    "endereco_descricao" smallint,
    "endereco_logradouro_abr" character varying(10),
    "endereco_logradouro" character varying(100),
    "endereco_numero" character varying(10),
    "endereco_complemento" character varying(50),
    "endereco_bairro" character varying(50),
    "endereco_cidade" character varying(50),
    "endereco_uf" character varying(2),
    "endereco_cep" character varying(10),
    "endereco_contrato" bigint,
    "id" bigint DEFAULT nextval('tbl_endereco_id_seq') NOT NULL
) WITH (oids = false);

CREATE INDEX "ix_tbl_endereco_cpf_cnpj" ON "neb"."tbl_endereco" USING btree ("endereco_cpf_cnpj");

CREATE INDEX "tbl_endereco_endereco_cpf_cnpj_idx" ON "neb"."tbl_endereco" USING btree ("endereco_cpf_cnpj");

CREATE INDEX "tbl_endereco_id_index" ON "neb"."tbl_endereco" USING btree ("id");


CREATE SEQUENCE tbl_estatisticas_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 20 CACHE 1;

CREATE TABLE "neb"."tbl_estatisticas" (
    "item" character varying(50),
    "referencia" character varying(50),
    "data_registro" timestamp,
    "valor" character varying(50),
    "id" bigint DEFAULT nextval('tbl_estatisticas_id_seq') NOT NULL
) WITH (oids = false);


CREATE SEQUENCE tbl_fone_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 66464830 CACHE 1;

CREATE TABLE "neb"."tbl_fone" (
    "fone_cpf_cnpj" bigint,
    "fone_descricao" smallint,
    "fone_tipo" smallint,
    "fone_numero_ddd" smallint,
    "fone_numero" bigint,
    "fone_usuario_matricula" character(20),
    "fone_usuario_unidade" smallint,
    "fone_data_cadastro" date,
    "fone_data_alteracao" date,
    "fone_valido" bit(1),
    "id" bigint DEFAULT nextval('tbl_fone_id_seq') NOT NULL,
    CONSTRAINT "tbl_fone_id_idx" UNIQUE ("id")
) WITH (oids = false);

CREATE INDEX "ix_tbl_fone_cpf_cnpj" ON "neb"."tbl_fone" USING btree ("fone_cpf_cnpj");

CREATE INDEX "tbl_fone_numero_idx" ON "neb"."tbl_fone" USING btree ("fone_numero_ddd", "fone_numero");


CREATE SEQUENCE tbl_fone_ddd_regiao_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 67 CACHE 1;

CREATE TABLE "neb"."tbl_fone_ddd_regiao" (
    "ddd" smallint NOT NULL,
    "uf" character varying(2),
    "qtde_digitos_celular" smallint,
    "id" bigint DEFAULT nextval('tbl_fone_ddd_regiao_id_seq') NOT NULL,
    CONSTRAINT "pk_ddd" PRIMARY KEY ("ddd")
) WITH (oids = false);


CREATE TABLE "neb"."tbl_girec" (
    "girec_cod" smallint,
    "girec_sigla" character varying(8),
    "girec_email_ext" character varying(50),
    "girec_telefone" character varying(14),
    "id" bigint
) WITH (oids = false);


CREATE TABLE "neb"."tbl_indexadores" (
    "ind_cod" smallint,
    "ind_desc" character varying(20)
) WITH (oids = false);


CREATE TABLE "neb"."tbl_indices" (
    "ind_cod" smallint,
    "ini_dtref" date,
    "ini_perc" numeric(7,4),
    "ini_fatacum" numeric(18,13),
    "ini_cmacum" numeric(13,9)
) WITH (oids = false);


CREATE TABLE "neb"."tbl_nsu" (
    "nsu_cod" integer NOT NULL,
    "nsu_cpf_cnpj" bigint NOT NULL,
    "nsu_data" timestamp,
    CONSTRAINT "pk_tbl_nsu" PRIMARY KEY ("nsu_cod")
) WITH (oids = false);

CREATE INDEX "tbl_nsu_idx01" ON "neb"."tbl_nsu" USING btree ("nsu_cpf_cnpj");


CREATE TABLE "neb"."tbl_numero_validador" (
    "numero_validador_cpf_cnpj" bigint NOT NULL,
    "numero_validador_codigo" integer,
    "numero_validador_data" date,
    CONSTRAINT "pk_numero_validador_cpf_cnpj" PRIMARY KEY ("numero_validador_cpf_cnpj")
) WITH (oids = false);

CREATE INDEX "tbl_numero_validador_cpf_cnpj_idx" ON "neb"."tbl_numero_validador" USING btree ("numero_validador_cpf_cnpj");


CREATE TABLE "neb"."tbl_parametros" (
    "parametro_id" integer NOT NULL,
    "parametro_descricao" character varying(100),
    "parametro_status" boolean,
    "parametro_valor" integer,
    "parametro_msg" character varying(1000),
    "parametro_exibe_msg" boolean,
    CONSTRAINT "pk_parametro_id" PRIMARY KEY ("parametro_id")
) WITH (oids = false);


CREATE TABLE "neb"."tbl_tipo_acordo_cartao" (
    "cod_tipo_reneg" integer NOT NULL,
    "cod_acordo" integer NOT NULL,
    "descricao_acordo" character varying(100),
    "descricao_acordo_alias" character varying(100),
    "ativo" boolean,
    CONSTRAINT "tbl_codigo_acesso_acordo_cod_acordo_cod_acesso_key" UNIQUE ("cod_acordo", "cod_tipo_reneg")
) WITH (oids = false);


CREATE SEQUENCE tbl_usuario_empct_usuario_empct_codigo_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "neb"."tbl_usuario_empct" (
    "usuario_empct_codigo" integer DEFAULT nextval('tbl_usuario_empct_usuario_empct_codigo_seq') NOT NULL,
    "usuario_empct_email" character varying(100),
    "usuario_empct_password" character varying(32),
    "usuario_empct_ativo" boolean,
    "usuario_empct_master" boolean,
    "usuario_empct_cpf" bigint,
    "usuario_empct_empct_codigo" integer,
    "usuario_empct_nome" character varying(100),
    CONSTRAINT "pk_usuario_empct_codigo" PRIMARY KEY ("usuario_empct_codigo")
) WITH (oids = false);




-- 2021-10-25 19:05:33.444379+00
