create user postgres with encrypted password 'postgres'
    superuser
    createdb
    createrole
    replication;

create user sineb001 with encrypted password 'neb'
    superuser
    createdb
    createrole
    replication;

create user sneb002 with encrypted password 'neb'
    superuser
    createdb
    createrole
    replication;

create user sneb001 with encrypted password 'neb'
    superuser
    createdb
    createrole
    replication;

/*create user draw with encrypted password 'neb'
    superuser
    createdb
    createrole
    replication;
*/

create user sineb with encrypted password 'neb'
    superuser
    createdb
    createrole
    replication;

/*create user neb with encrypted password 'neb'
    superuser
    createdb
    createrole
    replication;*/

create user nebgp_owner with encrypted password 'neb'
    superuser
    createdb
    createrole
    replication;

comment on role postgres is 'Usuario de suporte ao produto - CEPTIBR';

create user c131481
    superuser
    createrole
    replication;

comment on role c131481 is 'Helen Reis Santos Freitas - DBA-CEDESBR071';

create user c090290
    superuser
    createdb
    createrole
    replication;

comment on role c090290 is 'Luiz Eduardo Barbosa de Oliveira -DBA-CEDESBR071';

create user c068186
    superuser
    replication;

comment on role c068186 is 'Fernando Luiz Bichara -DBA-CEDESBR071';

create user c065717
    superuser
    createdb
    createrole
    replication;

comment on role c065717 is 'Jaqueline Teodoro Bastos - DBA-CEDESBR071';

create user otp;

comment on role otp is 'Owner do OTP';

create role otpgp_desenvolvedor;

comment on role otpgp_desenvolvedor is 'Role desenvolvedor - OTP';

create role otpgp_usuario_servico;

comment on role otpgp_usuario_servico is 'Role usuario servico - OTP';

create user admin_pos
    superuser
    replication;

comment on role admin_pos is 'Usuário de backup postgres - SD265453.';

create role abdgp_usuario_producao_backup
    superuser;

comment on role abdgp_usuario_producao_backup is 'Role para o usuário responsável pelo backup.';

create user ico;

comment on role ico is 'Owner do ICO';

create role icogp_consulta;

comment on role icogp_consulta is 'Role consulta - ICO';

create role icogp_usuario_etl_pwc;

comment on role icogp_usuario_etl_pwc is 'Role usuario servico ETL - ICO';

create user f911464
    replication
    valid until '2021-01-26 03:00:00+00';

comment on role f911464 is 'Euler Cruz de Souza - DBA-CEDESBR301-CTMONSI';

create role srsgp_consulta;

create role srsgp_desenvolvedor;

create role srsgp_usuario_etl_pwc;

create user srs
    valid until '2014-06-09 03:00:00+00';

comment on role srs is 'Owner do SRS';

create role srsgp_usuario_servico;

create role tdegp_consulta;

create role tdegp_usuario_etl_pwc;

create user ssrs001
    valid until ' infinity ';

alter user ssrs001 set search_path="$user", public, tde;

comment on role ssrs001 is 'Usuário serviço - SRS';

create user c055723;

comment on role c055723 is 'Eliane Saldanha';

create role tdegp_desenvolvedor;

create role tdegp_usuario_servico;

create user c101483;

comment on role c101483 is 'Fabio de Aguiar Nascente';

create user c129775;

comment on role c129775 is 'Diego Machado de Carvalho';

create user f569783
    valid until ' infinity ';

comment on role f569783 is 'Cleomar Barros de Oliveira Junior';

create user p741324
    superuser;

comment on role p741324 is 'Alex de Oliveira Sousa - DBA-CEPTIBR-HITSS';

create user sabddb01
    superuser
    createdb
    createrole
    replication;

comment on role sabddb01 is 'Usuário serviço - Equipe DBA-CEDESBR071';

create user psi
    valid until '2021-01-26 03:00:00+00';

comment on role psi is 'Owner do PSI-DEPARTAMENTAL';

create role psigp_desenvolvedor;

create user tde;

comment on role tde is 'Owner do TDE-DEPARTAMENTAL';

create user p734649
    superuser;

comment on role p734649 is 'Miguel Angelo Rodrigues da Silva- DBA CEPTIBR31';

create user neb
    valid until '2020-03-12 03:00:00+00';

comment on role neb is 'Owner do NEB';

create role nebgp_usuario_servico;

create role nebgp_desenvolvedor;

create user snebbd01
    valid until ' infinity ';

comment on role snebbd01 is 'Usuário serviço - NEB';

create user p649175;

comment on role p649175 is 'Fabricio Martins da Silva- DBA CEPTIBR31';

create user sotpbd01;

comment on role sotpbd01 is 'Usuário serviço - OTP';

create user abm;

comment on role abm is 'Owner do ABM';

create role abmgp_desenvolvedor;

create role abmgp_usuario_etl_pwc;

create role abmgp_usuario_servico;

create user sabm001;

comment on role sabm001 is 'Usuário serviço ABM';

create user amc;

comment on role amc is 'Owner do AMC';

create role amcgp_desenvolvedor;

create role amcgp_usuario_servico;

create user c129784
    valid until ' infinity ';

comment on role c129784 is 'Role de leitura
"Elaine Almeida Xavier Olibeira"';

create user p788745;

comment on role p788745 is 'Cassio Luiz Soares Dias - DBA-CEPTIBR-PRODUCAO';

create user gdp;

comment on role gdp is 'Owner do GDP';

create role gdpgp_desenvolvedor;

create role gdpgp_usuario_servico;

create user sgdpbd01
    valid until ' infinity ';

comment on role sgdpbd01 is 'Usuário serviço - GDP';

create user c060542
    valid until ' infinity ';

comment on role c060542 is 'Milena Rocha de Souza Milena';

create user p998782
    superuser
    createdb
    replication;

comment on role p998782 is 'Adriano Albernaz Golebiowski - DBA Suporte';

create user zabbix_monitor;

comment on role zabbix_monitor is 'Usuário do serviço de monitoramento Zabbix.';

create user p972797
    superuser;

comment on role p972797 is 'Jeandre Bernadelli Guerra - DBA Suporte';

create user p546948;

comment on role p546948 is 'Rafael Pereira de Souza - DBA_CEPTIBR_CPM-BRAXIS';

create user arh;

comment on role arh is 'Owner do ARH';

create role arhgp_consulta;

comment on role arhgp_consulta is 'Role consulta - ARH';

create user gcc;

comment on role gcc is 'Owner do GCC';

create role gccgp_consulta;

comment on role gccgp_consulta is 'Role consulta - GCC';

create role gccgp_desenvolvedor;

create user ita;

comment on role ita is 'Owner do ITA';

create role itagp_consulta;

comment on role itagp_consulta is 'Role consulta - ITA';

create role itagp_desenvolvedor;

comment on role itagp_desenvolvedor is 'Role desenvolvedor - ITA';

create role itagp_usuario_servico;

comment on role itagp_usuario_servico is 'Role usuario servico - ITA';

create role abdro_usuario_producao;

create user p790387;

comment on role p790387 is 'Jonas Wesley Pereira - DBA_CEPTIBR_CPM-BRAXIS';

create user c060776
    superuser
    valid until ' infinity ';

comment on role c060776 is 'Thais Monteiro de Morais - DBA-CEDESBR071';

create user ctd
    valid until '2019-08-02 03:00:00+00';

comment on role ctd is 'Owner do CTD';

create role ctdgp_desenvolvedor;

create role ctdgp_usuario_servico;

create user sctdbd01
    valid until ' infinity ';

comment on role sctdbd01 is 'Usuário serviço - CTD';

create user sctdbd02
    valid until ' infinity ';

comment on role sctdbd02 is 'Usuário serviço exclusivamente para instância SICTD CCA (módulo internet) - CTD';

create user sctdbd03
    valid until ' infinity ';

comment on role sctdbd03 is 'Usuário serviço exclusivamente para instância SICTD - módulo OCR';

create user c052958;

comment on role c052958 is 'Luciano Seite Nishikawa';

create user c071002;

comment on role c071002 is 'Andre Taishi Yamaguchi';

create user c075689;

comment on role c075689 is 'Débora da Silva Barros';

create user c090053;

comment on role c090053 is 'Mauricio Tarlá Menezes';

create user c091027;

comment on role c091027 is 'Marcelo Gutierrez';

create user c094494;

comment on role c094494 is 'Solange Pereira Barbosa da Silva';

create user c110848;

comment on role c110848 is 'Ivete Aparecida Dorizzoti';

create user c136102;

comment on role c136102 is 'Priscila Castro de Oliveira';

create user f935913;

comment on role f935913 is 'Eduardo Rodrigues Jacob - ETL-CEDESBR302-CTMONSI';

create user c142926;

comment on role c142926 is 'Marcelo Afonso Alves';

create user c092952
    superuser
    valid until ' infinity ';

comment on role c092952 is 'Thiago Carvalho Abreu - DBA-CEDESBR071';

create user f939440;

comment on role f939440 is 'Mauro de Queiroz Dias Jacome - AD-CEDESBR071';

create role abdro_consulta_objetos;

create user p791119
    superuser;

comment on role p791119 is 'Cleysson de Sousa Lima - DBA-CEPTIBR';

create user p694570
    superuser
    noinherit;

comment on role p694570 is 'Andre Luiz Borges de Oliveira - DBA CEPTIBR';

create user p911464
    superuser
    replication;

comment on role p911464 is 'Euler Cruz de Souza - DBA-CEDESBR071';

create user p623623
    superuser;

comment on role p623623 is 'Andre Lima dos Santos - DBA-CEPTIBR';

