CREATE TABLE "neb"."vw_auditorialog_dataacesso" ("auditorialog_cpf_cnpj" bigint, "auditorialog_ip" character varying(50), "auditorialog_url" character varying(100), "auditorialog_dataacesso" timestamp);


CREATE TABLE "neb"."vw_com_boleto_dados" ("contrato_numero" bigint, "contrato_cpf_cnpj" bigint, "contrato_ativo" bit(1), "contrato_pv" integer, "contrato_cliente_tipo_cod" smallint, "contrato_op_cod" smallint, "contrato_nome" character varying(100), "contrato_dias_atraso" integer, "contrato_divida_total" numeric(13,2), "contrato_val_ca" numeric(13,2), "contrato_data_ca" date, "contrato_sistema_cod" smallint, "contrato_garantia_tipo" smallint, "ajuizado" bit(1), "empresa_cobranca_cod" integer, "contrato_girec_cod" integer, "negociacao_parametro" smallint);


CREATE TABLE "neb"."vw_com_boleto_dados_internet" ("cliente_cpf_cnpj" bigint, "cliente_nome" character varying(100), "cliente_dt_nasc" timestamp, "cliente_sexo" character(1), "cliente_cod_estado_civil" smallint, "cliente_nacionalidade" character varying(50), "cliente_ident_numero" bigint, "cliente_ident_emissor_uf" character(2), "cliente_ident_emissor_orgao" character varying(10), "cliente_ident_emissor_data" timestamp, "cliente_dt_bloqueio" timestamp, "contrato_cliente_tipo_cod" smallint, "cliente_empresa_setor_cod" smallint, "cliente_empresa_natureza_cod" smallint, "cliente_empresa_represent_cpf" bigint, "cliente_empresa_represent_nome" character varying(50));


CREATE TABLE "neb"."vw_com_boleto_fone_internet" ("fone_cpf_cnpj" bigint, "fone_numero_ddd" smallint, "fone_numero" bigint);


CREATE TABLE "neb"."vw_com_boleto_melhor_dados_cliente" ("cliente_cpf_cnpj" bigint, "cliente_nome" character varying(100), "cliente_dt_nasc" timestamp, "cliente_sexo" character(1), "cliente_cod_estado_civil" smallint, "cliente_nacionalidade" character varying(50), "cliente_ident_numero" bigint, "cliente_ident_emissor_uf" character(2), "cliente_ident_emissor_orgao" character varying(10), "cliente_ident_emissor_data" timestamp, "cliente_pis_pasep" bigint);


CREATE TABLE "neb"."vw_com_boleto_melhor_email" ("email_cpf_cnpj" bigint, "email_descricao" smallint, "email_endereco" character varying(100), "email_valido" bit(1));


CREATE TABLE "neb"."vw_com_boleto_melhor_endereco" ("endereco_descricao" smallint, "endereco_logradouro_abr" character varying(10), "endereco_logradouro" character varying(100), "endereco_numero" character varying(10), "endereco_bairro" character varying(50), "endereco_complemento" character varying(50), "endereco_cidade" character varying(50), "endereco_uf" character varying(2), "endereco_cep" character varying(10), "endereco_cpf_cnpj" bigint);


CREATE TABLE "neb"."vw_com_boleto_melhor_fone" ("fone_cpf_cnpj" bigint, "fone_descricao" smallint, "fone_numero_ddd" smallint, "fone_numero" bigint, "fone_data_alteracao" date);


DROP TABLE IF EXISTS "neb"."vw_auditorialog_dataacesso";
CREATE VIEW "neb"."vw_auditorialog_dataacesso" AS SELECT neb.tbl_auditorialog.auditorialog_cpf_cnpj,
    neb.tbl_auditorialog.auditorialog_ip,
    neb.tbl_auditorialog.auditorialog_url,
    neb.tbl_auditorialog.auditorialog_dataacesso
   FROM neb.tbl_auditorialog
  WHERE ((neb.tbl_auditorialog.auditorialog_dataacesso)::date = (now())::date)
  ORDER BY neb.tbl_auditorialog.auditorialog_dataacesso DESC;

DROP TABLE IF EXISTS "neb"."vw_com_boleto_dados";
CREATE VIEW "neb"."vw_com_boleto_dados" AS SELECT neb.com_boleto_dados.contrato_numero,
    neb.com_boleto_dados.contrato_cpf_cnpj,
    neb.com_boleto_dados.contrato_ativo,
    neb.com_boleto_dados.contrato_pv,
    neb.com_boleto_dados.contrato_cliente_tipo_cod,
    neb.com_boleto_dados.contrato_op_cod,
    neb.com_boleto_dados.contrato_nome,
    neb.com_boleto_dados.contrato_dias_atraso,
    neb.com_boleto_dados.contrato_divida_total,
    neb.com_boleto_dados.contrato_val_ca,
    neb.com_boleto_dados.contrato_data_ca,
    neb.com_boleto_dados.contrato_sistema_cod,
    neb.com_boleto_dados.contrato_garantia_tipo,
    neb.com_boleto_dados.ajuizado,
    neb.com_boleto_dados.empresa_cobranca_cod,
    neb.com_boleto_dados.contrato_girec_cod,
    neb.com_boleto_dados.negociacao_parametro
   FROM neb.com_boleto_dados;



DROP TABLE IF EXISTS "neb"."vw_com_boleto_fone_internet";
CREATE VIEW "neb"."vw_com_boleto_fone_internet" AS SELECT f.fone_cpf_cnpj,
    f.fone_numero_ddd,
    f.fone_numero
   FROM (neb.tbl_fone f
     JOIN neb.tbl_fone_ddd_regiao fd ON ((f.fone_numero_ddd = fd.ddd)))
  WHERE ((length((f.fone_numero)::text) = fd.qtde_digitos_celular) AND (("substring"((f.fone_numero)::text, 1, 8))::integer <> ALL (ARRAY[99999999, 88888888, 77777777, 66666666, 55555555, 44444444, 33333333, 22222222, 11111111])) AND (("substring"((f.fone_numero)::text, 1, 1))::integer = ANY (ARRAY[6, 7, 8, 9])))
  GROUP BY f.fone_cpf_cnpj, f.fone_numero_ddd, f.fone_numero;

DROP TABLE IF EXISTS "neb"."vw_com_boleto_dados_internet";
CREATE VIEW "neb"."vw_com_boleto_dados_internet" AS SELECT bd.contrato_cpf_cnpj AS cliente_cpf_cnpj,
    bd.contrato_nome AS cliente_nome,
    c.cliente_dt_nasc,
    c.cliente_sexo,
    c.cliente_cod_estado_civil,
    c.cliente_nacionalidade,
    c.cliente_ident_numero,
    c.cliente_ident_emissor_uf,
    c.cliente_ident_emissor_orgao,
    c.cliente_ident_emissor_data,
    bloq.cliente_dt_bloqueio,
    bd.contrato_cliente_tipo_cod,
    c.cliente_empresa_setor_cod,
    c.cliente_empresa_natureza_cod,
    c.cliente_empresa_represent_cpf,
    c.cliente_empresa_represent_nome
   FROM (((( SELECT neb.com_boleto_dados.contrato_cpf_cnpj,
            neb.com_boleto_dados.contrato_nome,
            neb.com_boleto_dados.contrato_cliente_tipo_cod
           FROM neb.com_boleto_dados
          GROUP BY neb.com_boleto_dados.contrato_cpf_cnpj, neb.com_boleto_dados.contrato_nome, neb.com_boleto_dados.contrato_cliente_tipo_cod
        UNION
         SELECT neb.hab_boleto_dados.contrato_cpf_cnpj,
            neb.hab_boleto_dados.contrato_nome,
            neb.hab_boleto_dados.contrato_cliente_tipo_cod
           FROM neb.hab_boleto_dados
          GROUP BY neb.hab_boleto_dados.contrato_cpf_cnpj, neb.hab_boleto_dados.contrato_nome, neb.hab_boleto_dados.contrato_cliente_tipo_cod
        UNION
         SELECT neb.car_boleto_dados.contrato_cpf_cnpj,
            neb.car_boleto_dados.contrato_nome,
            neb.car_boleto_dados.contrato_cliente_tipo_cod
           FROM neb.car_boleto_dados
          GROUP BY neb.car_boleto_dados.contrato_cpf_cnpj, neb.car_boleto_dados.contrato_nome, neb.car_boleto_dados.contrato_cliente_tipo_cod) bd
     LEFT JOIN neb.tbl_cliente c ON ((bd.contrato_cpf_cnpj = c.cliente_cpf_cnpj)))
     JOIN ( SELECT vw_fi.fone_cpf_cnpj
           FROM neb.vw_com_boleto_fone_internet AS vw_fi
          GROUP BY vw_fi.fone_cpf_cnpj) fone ON ((c.cliente_cpf_cnpj = fone.fone_cpf_cnpj)))
     LEFT JOIN ( SELECT max(clb.cliente_dt_bloqueio) AS cliente_dt_bloqueio,
            clb.cliente_cpf_cnpj
           FROM neb.tbl_cliente_bloqueio clb
          GROUP BY clb.cliente_cpf_cnpj) bloq ON ((bloq.cliente_cpf_cnpj = c.cliente_cpf_cnpj)));


DROP TABLE IF EXISTS "neb"."vw_com_boleto_melhor_dados_cliente";
CREATE VIEW "neb"."vw_com_boleto_melhor_dados_cliente" AS SELECT neb.tbl_cliente.cliente_cpf_cnpj,
    neb.tbl_cliente.cliente_nome,
    neb.tbl_cliente.cliente_dt_nasc,
    neb.tbl_cliente.cliente_sexo,
    neb.tbl_cliente.cliente_cod_estado_civil,
    neb.tbl_cliente.cliente_nacionalidade,
    neb.tbl_cliente.cliente_ident_numero,
    neb.tbl_cliente.cliente_ident_emissor_uf,
    neb.tbl_cliente.cliente_ident_emissor_orgao,
    neb.tbl_cliente.cliente_ident_emissor_data,
    neb.tbl_cliente.cliente_pis_pasep
   FROM neb.tbl_cliente;

DROP TABLE IF EXISTS "neb"."vw_com_boleto_melhor_email";
CREATE VIEW "neb"."vw_com_boleto_melhor_email" AS SELECT neb.tbl_email.email_cpf_cnpj,
    neb.tbl_email.email_descricao,
    neb.tbl_email.email_endereco,
    neb.tbl_email.email_valido
   FROM neb.tbl_email;

DROP TABLE IF EXISTS "neb"."vw_com_boleto_melhor_endereco";
CREATE VIEW "neb"."vw_com_boleto_melhor_endereco" AS SELECT neb.tbl_endereco.endereco_descricao,
    neb.tbl_endereco.endereco_logradouro_abr,
    neb.tbl_endereco.endereco_logradouro,
    neb.tbl_endereco.endereco_numero,
    neb.tbl_endereco.endereco_bairro,
    neb.tbl_endereco.endereco_complemento,
    neb.tbl_endereco.endereco_cidade,
    neb.tbl_endereco.endereco_uf,
    neb.tbl_endereco.endereco_cep,
    neb.tbl_endereco.endereco_cpf_cnpj
   FROM neb.tbl_endereco;

DROP TABLE IF EXISTS "neb"."vw_com_boleto_melhor_fone";
CREATE VIEW "neb"."vw_com_boleto_melhor_fone" AS SELECT neb.tbl_fone.fone_cpf_cnpj,
    neb.tbl_fone.fone_descricao,
    neb.tbl_fone.fone_numero_ddd,
    neb.tbl_fone.fone_numero,
    neb.tbl_fone.fone_data_alteracao
   FROM neb.tbl_fone;
   