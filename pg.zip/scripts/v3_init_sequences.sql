create sequence neb.com_boleto_contrato_boleto_contrato_id_seq;

alter sequence neb.com_boleto_contrato_boleto_contrato_id_seq owner to neb;

grant usage on sequence neb.com_boleto_contrato_boleto_contrato_id_seq to nebgp_desenvolvedor with grant option;

grant usage on sequence neb.com_boleto_contrato_boleto_contrato_id_seq to nebgp_usuario_servico with grant option;

create sequence neb.tbl_atualizacao_arquivos_arquivo_id_seq;

alter sequence neb.tbl_atualizacao_arquivos_arquivo_id_seq owner to neb;

grant usage on sequence neb.tbl_atualizacao_arquivos_arquivo_id_seq to nebgp_usuario_servico with grant option;

grant usage on sequence neb.tbl_atualizacao_arquivos_arquivo_id_seq to nebgp_desenvolvedor with grant option;

create sequence neb.tbl_atualizacao_tabelas_colunas_registro_id_seq;

alter sequence neb.tbl_atualizacao_tabelas_colunas_registro_id_seq owner to neb;

grant usage on sequence neb.tbl_atualizacao_tabelas_colunas_registro_id_seq to nebgp_desenvolvedor;

grant usage on sequence neb.tbl_atualizacao_tabelas_colunas_registro_id_seq to nebgp_usuario_servico with grant option;

create sequence neb.tbl_atualizacao_views_arquivo_id_seq;

alter sequence neb.tbl_atualizacao_views_arquivo_id_seq owner to neb;

grant usage on sequence neb.tbl_atualizacao_views_arquivo_id_seq to nebgp_desenvolvedor with grant option;

grant usage on sequence neb.tbl_atualizacao_views_arquivo_id_seq to nebgp_usuario_servico with grant option;

create sequence neb.tbl_atualizacao_views_dependencia_arquivo_id_seq;

alter sequence neb.tbl_atualizacao_views_dependencia_arquivo_id_seq owner to neb;

grant usage on sequence neb.tbl_atualizacao_views_dependencia_arquivo_id_seq to nebgp_desenvolvedor with grant option;

grant usage on sequence neb.tbl_atualizacao_views_dependencia_arquivo_id_seq to nebgp_usuario_servico with grant option;

create sequence neb.tbl_usuario_empct_usuario_empct_codigo_seq;

alter sequence neb.tbl_usuario_empct_usuario_empct_codigo_seq owner to neb;

grant usage on sequence neb.tbl_usuario_empct_usuario_empct_codigo_seq to nebgp_desenvolvedor with grant option;

grant usage on sequence neb.tbl_usuario_empct_usuario_empct_codigo_seq to nebgp_usuario_servico with grant option;

