/*
    - Pessoa jurídica
    - Com dois contratos ativos
*/
/*
INSERT INTO neb.tbl_cliente
(cliente_cpf_cnpj, cliente_nome, cliente_dt_nasc, cliente_sexo,
 cliente_cod_estado_civil, cliente_nacionalidade, cliente_ident_numero,
 cliente_ident_emissor_uf, cliente_ident_emissor_orgao,
 cliente_ident_emissor_data, cliente_pis_pasep, cliente_empresa_setor_cod,
 cliente_empresa_natureza_cod, cliente_empresa_represent_nome,
 cliente_empresa_represent_cpf, cliente_segmento, cliente_gerente_matricula)
 VALUES
(6953983000167, 'MINI  MERCADO SALLA LTDA ME', '1900-01-01', '', null,
'BRASILEIRA', 6953983000167, '', '14', '1902-01-01',
null, 41, 64, 'moacir monteiro', 30039843815, 'ES03', 'C099523');

INSERT INTO neb.tbl_fone
(fone_cpf_cnpj, fone_descricao, fone_tipo, fone_numero_ddd, fone_numero,
fone_usuario_matricula, fone_usuario_unidade, fone_data_cadastro,
fone_data_alteracao, fone_valido)
VALUES
(6953983000167, 105, null, 83, 996523518, null, null, null, null, 1::bit);

--contrato_cliente_tipo_cod=1 PF
--contrato_cliente_tipo_cod=2 PJ
INSERT INTO neb.com_boleto_dados
(contrato_numero, contrato_cpf_cnpj, contrato_ativo, contrato_pv,
 contrato_sistema_cod, contrato_cliente_tipo_cod, contrato_op_cod,
 contrato_nome, contrato_dias_atraso, contrato_divida_total,
 contrato_val_ca, contrato_data_ca, contrato_garantia_tipo, ajuizado,
 empresa_cobranca_cod, contrato_girec_cod, negociacao_parametro,
 contrato_posicao)
VALUES
(201868555000001102, 6953983000167, '1', 1868, 1, 2, 555,
'MINI  MERCADO SALLA LTDA ME', 3593, 139815.38, 21678.98, '2010-06-19',
1, '1', 1, 7647, 4, '2020-02-20');

INSERT INTO neb.car_boleto_dados
(contrato_numero, contrato_cpf_cnpj, contrato_ativo, contrato_pv,
contrato_sistema_cod, contrato_cliente_tipo_cod, contrato_op_cod,
contrato_nome, contrato_dias_atraso, contrato_divida_total, contrato_val_ca,
contrato_data_ca, contrato_garantia_tipo, ajuizado, empresa_cobranca_cod,
contrato_girec_cod, negociacao_parametro, contrato_formatado, contrato_posicao)
VALUES (
306087, 6953983000167, '1', 105, 23, 2, 426055, 'MINI  MERCADO SALLA LTDA ME', 0,
0.00, 0.00, '2020-01-31', 1, '0', 1, 7641, 5, '426055******6677', '2020-01-31');

INSERT INTO neb.tbl_email
(email_cpf_cnpj, email_descricao, email_endereco, email_usuario_matricula,
email_usuario_unidade, email_data_cadastro, email_data_alteracao,
email_valido)
VALUES
(6953983000167, 102, 'minimercado@uol.com.br', null, null, '2017-01-03', null, null);

INSERT INTO neb.tbl_endereco
(endereco_cpf_cnpj, endereco_descricao, endereco_logradouro_abr, endereco_logradouro,
endereco_numero, endereco_complemento, endereco_bairro, endereco_cidade, endereco_uf,
endereco_cep, endereco_contrato)
VALUES
(6953983000167, 105, 'AV ', 'ITAIPAVA', '4815', null, 'ITAIPAVA', 'ITAJAI', 'SC',
'88316300', 306087);*/
