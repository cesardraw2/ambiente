/*
INSERT INTO neb.tbl_fone_ddd_regiao (ddd, uf, qtde_digitos_celular)
VALUES (11, 'SP', 9);
INSERT INTO neb.tbl_fone_ddd_regiao (ddd, uf, qtde_digitos_celular)
VALUES (83, 'PB', 9);



INSERT INTO neb.tbl_girec (girec_cod, girec_sigla, girec_email_ext, girec_telefone)
VALUES (7641, 'GIGAD', 'GIGADBH@CAIXA.GOV.BR', '31-32171009');
INSERT INTO neb.tbl_girec (girec_cod, girec_sigla, girec_email_ext, girec_telefone)
VALUES (7647, 'GIGAD', 'GIGADFL@CAIXA.GOV.BR', '48-37225601');
INSERT INTO neb.tbl_girec (girec_cod, girec_sigla, girec_email_ext, girec_telefone)
VALUES (7649, 'GIGAD', 'GIGADGO@CAIXA.GOV.BR', '62-36121401');



INSERT INTO neb.com_boleto_operacoes_parametro (boleto_operacao_cod,
boleto_operacao_descricao, boleto_operacao_tipo_liquidacao,
boleto_operacao_tipo_prestacao, boleto_operacao_tipo_renegociacao,
boleto_operacao_sistema, boleto_max_prestacao, boleto_operacao_on_off,
boleto_operacao_lote_on_off, boleto_operacao_sineb_on_off,
boleto_renegocia_garantia_real)
VALUES
(102, 'CRÉDITO PESSOAL/ANTECIPAÇÃO DE RESTITUIÇÃO DE IMPOSTO DE RENDA - PRÉ FIXADA/POSTECIPADA/ANTECIPAÇÃO ', 1, 1, '1', 1, 96, '1', '1', '1', '0');
INSERT INTO neb.com_boleto_operacoes_parametro (boleto_operacao_cod,
boleto_operacao_descricao, boleto_operacao_tipo_liquidacao,
boleto_operacao_tipo_prestacao, boleto_operacao_tipo_renegociacao,
boleto_operacao_sistema, boleto_max_prestacao, boleto_operacao_on_off,
boleto_operacao_lote_on_off, boleto_operacao_sineb_on_off,
boleto_renegocia_garantia_real)
VALUES
(168, 'MOVEISCARD', 0, 0, '0', 20, 0, '0', '0', '0', '0');
INSERT INTO neb.com_boleto_operacoes_parametro (boleto_operacao_cod,
boleto_operacao_descricao, boleto_operacao_tipo_liquidacao,
boleto_operacao_tipo_prestacao, boleto_operacao_tipo_renegociacao,
boleto_operacao_sistema, boleto_max_prestacao, boleto_operacao_on_off,
boleto_operacao_lote_on_off, boleto_operacao_sineb_on_off,
boleto_renegocia_garantia_real)
VALUES
(555, 'CREDITO ESPECIAL EMPRESA - GARANTIA FGO - PREFIXADA', 1, 1, '1', 1, 0, '1', '0', '1', '0');


INSERT INTO neb.com_boleto_taxas_parcelamento (tipt_cod, tipt_desc, prap_cod, prap_min, prap_max, taxp_cod, taxp_percmin, taxp_percmax) VALUES (2, 'PRÉ-FIXADAS', 1, 1, 12, 17, 1.18, 1.48);
INSERT INTO neb.com_boleto_taxas_parcelamento (tipt_cod, tipt_desc, prap_cod, prap_min, prap_max, taxp_cod, taxp_percmin, taxp_percmax) VALUES (2, 'PRÉ-FIXADAS', 2, 13, 24, 28, 1.38, 1.68);
INSERT INTO neb.com_boleto_taxas_parcelamento (tipt_cod, tipt_desc, prap_cod, prap_min, prap_max, taxp_cod, taxp_percmin, taxp_percmax) VALUES (2, 'PRÉ-FIXADAS', 3, 25, 36, 29, 1.67, 1.97);
INSERT INTO neb.com_boleto_taxas_parcelamento (tipt_cod, tipt_desc, prap_cod, prap_min, prap_max, taxp_cod, taxp_percmin, taxp_percmax) VALUES (2, 'PRÉ-FIXADAS', 4, 37, 48, 30, 1.80, 2.10);
INSERT INTO neb.com_boleto_taxas_parcelamento (tipt_cod, tipt_desc, prap_cod, prap_min, prap_max, taxp_cod, taxp_percmin, taxp_percmax) VALUES (2, 'PRÉ-FIXADAS', 5, 49, 60, 31, 1.97, 2.27);
INSERT INTO neb.com_boleto_taxas_parcelamento (tipt_cod, tipt_desc, prap_cod, prap_min, prap_max, taxp_cod, taxp_percmin, taxp_percmax) VALUES (2, 'PRÉ-FIXADAS', 6, 61, 96, 32, 2.10, 2.40);


INSERT INTO neb.hab_produto (produto_cod, produto_dv, produto_desc, produto_tipo_credor, siico_produto_id, sis_num) VALUES (168, 1, 'minha casa minha vida', 1, 1, 1);*/
