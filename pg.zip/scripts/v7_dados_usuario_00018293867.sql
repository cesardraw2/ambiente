/*
    - Pessoa física
    - Com um contrato ativo e outro inativo
*/

/*
INSERT INTO neb.tbl_cliente
(cliente_cpf_cnpj, cliente_nome, cliente_dt_nasc, cliente_sexo,
 cliente_cod_estado_civil, cliente_nacionalidade, cliente_ident_numero,
 cliente_ident_emissor_uf, cliente_ident_emissor_orgao,
 cliente_ident_emissor_data, cliente_pis_pasep, cliente_empresa_setor_cod,
 cliente_empresa_natureza_cod, cliente_empresa_represent_nome,
 cliente_empresa_represent_cpf, cliente_segmento, cliente_gerente_matricula)
 VALUES
(00018293867, 'WANDER DIAS SILVA', '1976-04-28', 'M', 1, 'BRASILEIRA', 00018293867, 'SP',
 'SSP', '1978-04-28', null, null, 0, null, null, 'GV01', 'C034671');

INSERT INTO neb.tbl_fone
(fone_cpf_cnpj, fone_descricao, fone_tipo, fone_numero_ddd, fone_numero,
fone_usuario_matricula, fone_usuario_unidade, fone_data_cadastro,
fone_data_alteracao, fone_valido)
VALUES
(00018293867, 102, null, 83, 987792493, null, null, null, null, 1::bit);
INSERT INTO neb.tbl_fone
(fone_cpf_cnpj, fone_descricao, fone_tipo, fone_numero_ddd, fone_numero,
fone_usuario_matricula, fone_usuario_unidade, fone_data_cadastro,
fone_data_alteracao, fone_valido)
VALUES
(00018293867, 102, null, 11, 998989898, null, null, null, null, null);

--contrato_cliente_tipo_cod=1 PF
--contrato_cliente_tipo_cod=2 PJ
INSERT INTO neb.com_boleto_dados
(contrato_numero, contrato_cpf_cnpj, contrato_ativo, contrato_pv,
 contrato_sistema_cod, contrato_cliente_tipo_cod, contrato_op_cod,
 contrato_nome, contrato_dias_atraso, contrato_divida_total,
 contrato_val_ca, contrato_data_ca, contrato_garantia_tipo, ajuizado,
 empresa_cobranca_cod, contrato_girec_cod, negociacao_parametro,
 contrato_posicao)
VALUES
(231141400000052474, 00018293867, '1', 1141, 1, 1, 102, 'WANDER DIAS SILVA',
 5623, 27198.02, 2514.60, '2004-11-27', 0, '0', 1, 7649, 1, '2020-02-20');

INSERT INTO neb.com_boleto_dados
(contrato_numero, contrato_cpf_cnpj, contrato_ativo, contrato_pv,
 contrato_sistema_cod, contrato_cliente_tipo_cod, contrato_op_cod,
 contrato_nome, contrato_dias_atraso, contrato_divida_total,
 contrato_val_ca, contrato_data_ca, contrato_garantia_tipo, ajuizado,
 empresa_cobranca_cod, contrato_girec_cod, negociacao_parametro,
 contrato_posicao)
VALUES
(231141400000052476, 00018293867, '1', 1141, 1, 1, 102, 'WANDER DIAS SILVA',
 720, 19000.00, 4500.00, '2018-11-27', 0, '0', 1, 7649, 1, '2020-03-20');

INSERT INTO neb.hab_boleto_dados
(contrato_numero, contrato_cpf_cnpj, contrato_ativo, contrato_pv,
 contrato_sistema_cod, contrato_cliente_tipo_cod, contrato_op_cod,
 contrato_nome, contrato_dias_atraso, contrato_divida_total,
 contrato_val_ca, contrato_data_ca, contrato_garantia_tipo, ajuizado,
 empresa_cobranca_cod, contrato_girec_cod, negociacao_parametro,
 contrato_posicao, contrato_dv)
VALUES
(231141400000052475, 00018293867, '0', 1141, 1, 1, 168, 'WANDER DIAS SILVA',
 5623, 270198.02, 2514.60, '2004-11-27', 0, '0', 1, 7649, 1, '2020-02-20', 1);

INSERT INTO neb.tbl_email
(email_cpf_cnpj, email_descricao, email_endereco, email_usuario_matricula,
email_usuario_unidade, email_data_cadastro, email_data_alteracao,
email_valido)
VALUES
(00018293867, 102, 'wander@uol.com.br', null, null, '2017-01-03', null, null);
INSERT INTO neb.tbl_email
(email_cpf_cnpj, email_descricao, email_endereco, email_usuario_matricula,
email_usuario_unidade, email_data_cadastro, email_data_alteracao,
email_valido)
VALUES
(00018293867, 100, 'wander@gmail.com.br', null, null, '2019-12-10', null, 1::bit);

INSERT INTO neb.tbl_endereco
(endereco_cpf_cnpj, endereco_descricao, endereco_logradouro_abr, endereco_logradouro,
endereco_numero, endereco_complemento, endereco_bairro, endereco_cidade, endereco_uf,
endereco_cep, endereco_contrato)
VALUES
(00018293867,160,'QDR','BEMBRIAO','2','complemento','Vila Abobrinha','CRISSIUMAL','RS','98640000',231141400000052474);
INSERT INTO neb.tbl_endereco
(endereco_cpf_cnpj, endereco_descricao, endereco_logradouro_abr, endereco_logradouro,
endereco_numero, endereco_complemento, endereco_bairro, endereco_cidade, endereco_uf,
endereco_cep, endereco_contrato)
VALUES
(00018293867,8,'RUA','RUA1105','0','complemento','CENTRO','PIUM','TO','77570000',231141400000052475);

INSERT INTO neb.tbl_nsu VALUES (1, 00018293867, CURRENT_DATE);

INSERT INTO neb.tbl_campanha_contrato (contrato_numero, campanha_valor_a_vista, campanha_valor_a_prazo, campanha_prazo, campanha_vigencia)
VALUES (231141400000052474, 20000.00, 28000.00, 96, '2020-08-17');

INSERT INTO neb.tbl_campanha_contrato (contrato_numero, campanha_valor_a_vista, campanha_valor_a_prazo, campanha_prazo, campanha_vigencia)
VALUES (231141400000052476, 10000.00, 20000.00, 96, '2020-10-10');
*/
