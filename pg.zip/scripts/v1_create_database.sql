/*grant all privileges on database posdes02 to draw;*/
grant all privileges on database posdes02 to neb;
grant all privileges on database posdes02 to sneb001;
grant all privileges on database posdes02 to sneb002;
grant all privileges on database posdes02 to nebgp_owner;

--create schema neb;





