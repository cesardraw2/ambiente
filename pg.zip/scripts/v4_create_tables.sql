CREATE TABLE IF NOT EXISTS neb.car_acordo_detalhes
(
    cod_entidade         integer,
    cod_agencia          integer,
    numero_conta         bigint,
    num_parcela          integer,
    dt_parcela           date,
    dt_pagto_parce       date,
    snl_vlr_parcela      varchar(1),
    vlr_parcela          numeric(13, 2),
    snl_vlr_pago         varchar(1),
    vlr_pago             numeric(13, 2),
    situacao_parcela     varchar(30),
    snl_vlr_pagar        varchar(1),
    vlr_pagar            numeric(13, 2),
    snl_vlr_juro_atraso  varchar(1),
    vlr_juro_atraso      numeric(13, 2),
    snl_vlr_mora_atraso  varchar(1),
    vlr_mora_atraso      numeric(13, 2),
    snl_vlr_multa_atraso varchar(1),
    vlr_multa_atraso     numeric(13, 2),
    snl_vlr_iof_atraso   varchar(1),
    vlr_iof_atraso       numeric(13, 2)
);

ALTER TABLE neb.car_acordo_detalhes owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.car_acordo_detalhes TO nebgp_desenvolvedor;

CREATE TABLE IF NOT EXISTS neb.car_bin
(
    car_bin_cod  integer not null,
    car_bin_desc varchar(50),
    car_bin_sac  varchar(150)
);

ALTER TABLE neb.car_bin owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.car_bin TO nebgp_desenvolvedor;

CREATE INDEX car_bin_car_bin_cod_idx ON neb.car_bin (car_bin_cod);

CREATE TABLE IF NOT EXISTS neb.car_boleto_dados
(
    contrato_numero           bigint not null,
    contrato_cpf_cnpj         bigint,
    contrato_ativo            bit,
    contrato_pv               integer,
    contrato_sistema_cod      smallint,
    contrato_cliente_tipo_cod smallint,
    contrato_op_cod           integer,
    contrato_nome             varchar(100),
    contrato_dias_atraso      integer,
    contrato_divida_total     numeric(13, 2),
    contrato_val_ca           numeric(13, 2),
    contrato_data_ca          date,
    contrato_garantia_tipo    smallint,
    ajuizado                  bit,
    empresa_cobranca_cod      integer,
    contrato_girec_cod        integer,
    negociacao_parametro      smallint,
    contrato_formatado        varchar(16),
    contrato_posicao          date
);

ALTER TABLE neb.car_boleto_dados owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.car_boleto_dados TO nebgp_desenvolvedor;

CREATE INDEX car_boleto_dados_contrato_cpf_c ON neb.car_boleto_dados (contrato_cpf_cnpj);

CREATE TABLE IF NOT EXISTS neb.car_boleto_dados_fixos
(
    contrato_numero    bigint not null,
    linha_digitavel    varchar(43),
    cedente            varchar(40),
    codigo_cedente     varchar(21),
    data_documento     date,
    aceite             varchar(1),
    carteira           varchar(2),
    moeda              varchar(2),
    cnpj_cpf           bigint,
    numero_cartao      varchar(22),
    nosso_numero       varchar(16),
    vencimento_boleto  date,
    pagamento_minimo   numeric(13, 2),
    codigo_de_barras   varchar(44),
    data_processamento date
);

ALTER TABLE neb.car_boleto_dados_fixos owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.car_boleto_dados_fixos TO nebgp_desenvolvedor;

CREATE INDEX car_boleto_dados_fixos_contrato ON neb.car_boleto_dados_fixos (contrato_numero);

CREATE TABLE IF NOT EXISTS neb.car_boleto_dados_proposta
(
    contrato_numero        bigint  not null,
    qtd_parc_proposta      integer not null,
    vlr_cada_parcela       numeric(13, 2),
    vlr_iof                numeric(13, 2),
    vlr_prim_parcela_c_iof numeric(13, 2),
    vlr_total              numeric(13, 2),
    vlr_juros_prop         numeric(13, 2),
    vlr_custo_efetivo      numeric(13, 2)
);

ALTER TABLE neb.car_boleto_dados_proposta owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.car_boleto_dados_proposta TO nebgp_desenvolvedor;

CREATE INDEX car_boleto_dados_proposta_contr ON neb.car_boleto_dados_proposta (contrato_numero);

CREATE TABLE IF NOT EXISTS neb.car_boleto_proposta
(
    boleto_nosso_numero        bigint not null,
    boleto_dt_vencto           date,
    boleto_dt_processamento    timestamp,
    boleto_usuario             bigint,
    boleto_unidade_responsavel integer,
    boleto_contrato            bigint,
    boleto_valor_maximo        numeric(13, 2)
);

ALTER TABLE neb.car_boleto_proposta owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.car_boleto_proposta TO nebgp_desenvolvedor;

CREATE TABLE IF NOT EXISTS neb.car_pcspogca
(
    cod_entidade                integer,
    cod_agencia                 integer,
    numero_conta                bigint,
    cliente_nome                varchar(40),
    cliente_ddd_fone_comercial  integer,
    cliente_fone_comercial      bigint,
    cliente_ddd_fone_celular    integer,
    cliente_fone_celular        bigint,
    cliente_end_correspo        varchar(40),
    cliente_bairro_end_correspo varchar(15),
    cliente_cidade_end_correspo varchar(40),
    cliente_uf_end_correspo     varchar(2),
    cliente_cep_end_correspo    bigint,
    cliente_pais_end_correspo   varchar(25),
    cod_produto                 bigint,
    snl_saldo_fatura            varchar(1),
    vlr_saldo_fatura            numeric(13, 2),
    cod_situacao_conta          integer,
    dt_corte                    date,
    vlr_min_fatura_cob          numeric(13, 2),
    dt_dia_venc_fatura          date,
    limite                      numeric(13, 2),
    bloqueio                    varchar(40),
    atributo                    varchar(25),
    atraso_conta                integer,
    pessoa_tipo                 varchar(5),
    cpf_cnpj                    bigint,
    dt_nascimento               date,
    ic_classif_conta            varchar(2),
    espaco_em_branco_1          integer,
    dt_devolucao_ult_cheque     date,
    espaco_em_branco_2          integer,
    dt_abertura_conta           date,
    dt_ultima_compra            date,
    snl_saldo_atual_atraso      varchar(1),
    vlr_saldo_atual_atraso      numeric(13, 2),
    dt_inclu_negativacao        date,
    juro_mora                   numeric(13, 2),
    dt_solic_negativacao        date,
    dt_reabil_negativacao       date,
    dt_ajuizamento              date,
    snl_saldo_enquadrado        varchar(1),
    vlr_saldo_enquadrado        numeric(13, 2),
    dt_enquadramento            date,
    snl_saldo_atualizado        varchar(1),
    vlr_saldo_atualizado        numeric(13, 2),
    snl_correc_monet_enquad     varchar(1),
    vlr_correc_monet_enquad     numeric(13, 2),
    snl_atual_enquad            varchar(1),
    vlr_atual_enquad            numeric(13, 2),
    cliente_end_resid           varchar(40),
    cliente_bairro_end_resid    varchar(15),
    cliente_cidade_end_resid    varchar(40),
    cliente_uf_end_resid        varchar(2),
    cliente_cep_end_resid       varchar(9),
    cliente_ddd_fone_resid      integer,
    cliente_fone_resid          integer,
    codigo_barras               varchar(50),
    dias_atraso_enquad          integer,
    desc_status_acordo          varchar(30),
    desc_situacao_conta         varchar(30),
    desc_behavior_score         varchar(30),
    cod_class_comportamento     integer,
    vlr_limite_saque            numeric(13, 2),
    vlr_uso_limite_saque        numeric(13, 2),
    vlr_creditos_ciclo          numeric(13, 2),
    vlr_debitos_ciclo           numeric(13, 2),
    vlr_total_pagtos_ciclo      numeric(13, 2),
    vlr_saldo_parc_com_juros    numeric(13, 2),
    vlr_saldo_parc_sem_juros    numeric(13, 2),
    vlr_saldo_parc_acelerado    numeric(13, 2),
    dt_entrada_cobranca         date,
    vlr_tarifa_aplcda           numeric(13, 2),
    ic_primeira_fatura_atraso   varchar(2),
    dt_procto_ultimo_pgto       date,
    vlr_encargo_contratual      numeric(13, 2),
    vlr_imposto                 numeric(13, 2),
    vlr_credito_posterior_enqdo numeric(13, 2),
    vlr_debito_posterior_enqdo  numeric(13, 2),
    dias_atraso_cobranca        integer,
    vlr_correcao_monet_enquad   numeric(13, 2),
    ic_status_acordo            varchar(2),
    vlr_imposto_enqdo           numeric(13, 2),
    snl_juro_enqdo              varchar(1),
    vlr_juro_enqdo              numeric(13, 2),
    ic_cheque_devolvido         varchar(1),
    no_indicador_negativacao    varchar(50),
    vlr_uso_limite_cdr          numeric(13, 2),
    vlr_multa_atraso            numeric(13, 2),
    flag_saldo_pendente         varchar(1),
    vlr_jrs_acrd_aplicar        numeric(13, 2),
    vlr_enc_acrd_pendente       numeric(13, 2),
    co_tipo_acao_paral          varchar(1),
    de_tipo_acao_paral          varchar(30),
    num_carteira                integer,
    linha_digitavel             varchar(54),
    cnpj_cob_externa            bigint,
    nome_cob_externa            varchar(60),
    fone_cob_externa            bigint
);

ALTER TABLE neb.car_pcspogca owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.car_pcspogca TO nebgp_desenvolvedor;

CREATE INDEX ix_car_pcspogca_1 ON neb.car_pcspogca (cod_entidade, cod_agencia, numero_conta);

CREATE TABLE IF NOT EXISTS neb.car_pcspogca_bloqueio_cartao
(
    cod_entidade  integer,
    cod_agencia   integer,
    numero_conta  bigint,
    dt_bloqueio   date,
    tipo_bloqueio varchar(30)
);

ALTER TABLE neb.car_pcspogca_bloqueio_cartao owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.car_pcspogca_bloqueio_cartao TO nebgp_desenvolvedor;

CREATE INDEX ix_pcspogca_bloqueio_cartao_1 ON neb.car_pcspogca_bloqueio_cartao (cod_entidade, cod_agencia, numero_conta);

CREATE TABLE IF NOT EXISTS neb.car_pcspogcd
(
    cod_entidade     integer,
    cod_agencia      integer,
    numero_conta     bigint,
    numero_acordo    integer,
    cod_acesso       integer,
    desc_cod_acesso  varchar(50),
    snl_vlr_atual    varchar(1),
    vlr_atual        numeric(13, 2),
    snl_vlr_ult_pgto varchar(1),
    vlr_ult_pgto     numeric(13, 2),
    qtde_parcelas    integer,
    dt_acordo        date,
    sta_acordo       integer,
    desc_sta_acordo  varchar(50)
);

ALTER TABLE neb.car_pcspogcd owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.car_pcspogcd TO nebgp_desenvolvedor;

CREATE INDEX ix_car_pcspogcd_1 ON neb.car_pcspogcd (cod_entidade, cod_agencia, numero_conta);

CREATE TABLE IF NOT EXISTS neb.car_pcspogce
(
    cod_entidade          integer,
    cod_agencia           integer,
    numero_conta          bigint,
    clave_fin             varchar(200),
    ind_mas_datos         varchar(1),
    qtde_total_ocor       integer,
    qtde_ocor_tela        integer,
    snl_vlr_acordo        varchar(1),
    vlr_acordo            numeric(13, 2),
    snl_vlr_juro_acordo   varchar(1),
    vlr_juro_acordo       numeric(13, 2),
    vlr_desconto_acordo   numeric(13, 2),
    snl_vlr_entrada       varchar(1),
    vlr_entrada           numeric(13, 2),
    dt_pagto_entrada      date,
    snl_vlr_iof_atraso    varchar(1),
    vlr_iof_atraso        numeric(13, 2),
    snl_vlr_iof_projetado varchar(1),
    vlr_iof_projetado     numeric(13, 2),
    snl_vlr_iof_pago      varchar(1),
    vlr_iof_pago          numeric(13, 2),
    snl_vlr_crco_mntra    varchar(1),
    vlr_crco_mntra        numeric(13, 2),
    snl_vlr_mora          varchar(1),
    vlr_mora              numeric(13, 2),
    pc_aplco_inde_enco    numeric(13, 2),
    usuario_alt           varchar(8),
    vlr_parcela_antpo     numeric(13, 2),
    dt_tlrna_pgmo_anto    date,
    email_cliente         varchar(50),
    flag_tem_antec        varchar(1),
    nu_campanha_admva     integer
);

ALTER TABLE neb.car_pcspogce owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.car_pcspogce TO nebgp_desenvolvedor;

CREATE TABLE IF NOT EXISTS neb.com_boleto_cliente
(
    boleto_nosso_numero         bigint   not null,
    boleto_cpf_cnpj             bigint   not null,
    boleto_cliente              varchar(50),
    boleto_tipo_cliente         smallint,
    endereco_descricao          smallint not null,
    endereco_logradouro_abr     varchar(10),
    endereco_logradouro         varchar(100),
    endereco_numero             varchar(10),
    endereco_complemento        varchar(50),
    endereco_bairro             varchar(50),
    endereco_cidade             varchar(50),
    endereco_uf                 varchar(2),
    endereco_cep                varchar(10),
    endereco_dados_extras       varchar(100),
    endereco_atualizado         smallint,
    endereco_email              varchar(200),
    endereco_data_inclusao      timestamp,
    endereco_ddd_1              smallint,
    endereco_fone_1             bigint,
    endereco_ddd_2              smallint,
    endereco_fone_2             bigint,
    cliente_dt_nasc             timestamp,
    cliente_sexo                char,
    cliente_cod_estado_civil    smallint,
    cliente_nacionalidade       varchar(50),
    cliente_ident_numero        bigint,
    cliente_ident_emissor_uf    char(2),
    cliente_ident_emissor_orgao varchar(10),
    cliente_ident_emissor_data  timestamp,
    cliente_pis_pasep           bigint
);

ALTER TABLE neb.com_boleto_cliente owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.com_boleto_cliente TO nebgp_desenvolvedor;

CREATE INDEX boleto_nosso_numero_idx01 ON neb.com_boleto_cliente (boleto_nosso_numero);

CREATE INDEX com_boleto_cliente_boleto_cpf_c ON neb.com_boleto_cliente (boleto_cpf_cnpj);

CREATE TABLE IF NOT EXISTS neb.com_boleto_contrato
(
    boleto_contrato_id              bigint         not null,
    contrato_numero                 bigint         not null,
    boleto_nosso_numero             bigint         not null,
    contrato_vlr_renegociado        numeric(13, 2) not null,
    contrato_sistema                smallint       not null,
    contrato_pv_cod                 smallint,
    contrato_vlr_renegociado_origin numeric(13, 2) default 0,
    contrato_vlr_renegociado_ALTERa numeric(13, 2) default 0,
    contrato_campanha_renegociado   smallint       default '0'::smallint
);

ALTER TABLE neb.com_boleto_contrato owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.com_boleto_contrato TO nebgp_desenvolvedor;

CREATE INDEX boleto_contrato_id_idx ON neb.com_boleto_contrato (boleto_contrato_id);

CREATE INDEX boleto_nosso_numero_idx ON neb.com_boleto_contrato (boleto_nosso_numero);

CREATE TABLE IF NOT EXISTS neb.com_boleto_dados
(
    contrato_numero           bigint not null,
    contrato_cpf_cnpj         bigint,
    contrato_ativo            bit,
    contrato_pv               integer,
    contrato_sistema_cod      smallint,
    contrato_cliente_tipo_cod smallint,
    contrato_op_cod           smallint,
    contrato_nome             varchar(100),
    contrato_dias_atraso      integer,
    contrato_divida_total     numeric(13, 2),
    contrato_val_ca           numeric(13, 2),
    contrato_data_ca          date,
    contrato_garantia_tipo    smallint,
    ajuizado                  bit,
    empresa_cobranca_cod      integer,
    contrato_girec_cod        integer,
    negociacao_parametro      smallint,
    contrato_posicao          date
);

ALTER TABLE neb.com_boleto_dados owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.com_boleto_dados TO nebgp_desenvolvedor;

CREATE INDEX com_boleto_dados_contrato_cpf_c ON neb.com_boleto_dados (contrato_cpf_cnpj);

CREATE TABLE IF NOT EXISTS neb.com_boleto_dados_ext_negociacao
(
    negociacao_parametro integer not null,
    descricao            varchar(50)
);

ALTER TABLE neb.com_boleto_dados_ext_negociacao owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.com_boleto_dados_ext_negociacao TO nebgp_desenvolvedor;

CREATE TABLE IF NOT EXISTS neb.com_boleto_operacoes_parametro
(
    boleto_operacao_cod             smallint not null,
    boleto_operacao_descricao       varchar(200),
    boleto_operacao_tipo_liquidacao smallint,
    boleto_operacao_tipo_prestacao  smallint,
    boleto_operacao_tipo_renegociac bit,
    boleto_operacao_sistema         smallint,
    boleto_max_prestacao            integer,
    boleto_operacao_on_off          bit,
    boleto_operacao_lote_on_off     bit,
    boleto_operacao_sineb_on_off    bit,
    boleto_renegocia_garantia_real  bit
);

ALTER TABLE neb.com_boleto_operacoes_parametro owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.com_boleto_operacoes_parametro TO nebgp_desenvolvedor;

CREATE INDEX boleto_operacao_idx ON neb.com_boleto_operacoes_parametro (boleto_operacao_cod);

CREATE TABLE IF NOT EXISTS neb.com_boleto_proposta
(
    boleto_nosso_numero        bigint not null,
    boleto_tipo                smallint,
    boleto_dt_vencto           date,
    boleto_cod_cedente         bigint,
    boleto_dt_doc              date,
    boleto_numero_doc          bigint,
    boleto_dt_processamento    date,
    boleto_valor               numeric(13, 2),
    boleto_vlr_parcela_termo   numeric(13, 2),
    boleto_qtde_parcela_termo  smallint,
    boleto_emissao_externo     smallint,
    boleto_unidade_responsavel integer,
    boleto_forma_envio         smallint,
    boleto_critica_191         smallint,
    boleto_pv_reneg            smallint,
    boleto_vlr_iof             numeric(13, 2),
    boleto_taxa_juros_191      numeric(18, 5),
    boleto_valor_original      numeric(13, 2),
    boleto_valor_alt_flag      smallint,
    boleto_usuario             bigint,
    boleto_empct_codigo        integer
);

ALTER TABLE neb.com_boleto_proposta owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.com_boleto_proposta TO nebgp_desenvolvedor;

CREATE TABLE IF NOT EXISTS neb.com_boleto_proposta_tipo
(
    boleto_proposta_tipo_id   smallint,
    boleto_proposta_tipo_nome varchar(30)
);

ALTER TABLE neb.com_boleto_proposta_tipo owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.com_boleto_proposta_tipo TO nebgp_desenvolvedor;

CREATE TABLE IF NOT EXISTS neb.com_boleto_taxas_parcelamento
(
    tipt_cod     smallint,
    tipt_desc    varchar(50),
    prap_cod     smallint not null,
    prap_min     smallint,
    prap_max     smallint,
    taxp_cod     smallint,
    taxp_percmin numeric(13, 2),
    taxp_percmax numeric(13, 2)
);

ALTER TABLE neb.com_boleto_taxas_parcelamento owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.com_boleto_taxas_parcelamento TO nebgp_desenvolvedor;

CREATE TABLE IF NOT EXISTS neb.com_contrato_garantia
(
    contrato_numero      bigint   not null,
    contrato_garantia_id smallint not null
);

ALTER TABLE neb.com_contrato_garantia owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.com_contrato_garantia TO nebgp_desenvolvedor;

CREATE INDEX contrato_numero_idx ON neb.com_contrato_garantia (contrato_numero);

CREATE TABLE IF NOT EXISTS neb.com_execucao_processo_judicial
(
    contrato_numero bigint not null,
    exp_codigo      bigint,
    dt_inclusao     timestamp,
    codigo          numeric(20),
    dta_juizamento  timestamp,
    tipo_codigo     smallint,
    acao_tipo_desc  varchar(40),
    vlr_custas      numeric(13, 2),
    dt_custas       timestamp
);

ALTER TABLE neb.com_execucao_processo_judicial owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.com_execucao_processo_judicial TO nebgp_desenvolvedor;

CREATE INDEX processo_judicial_contrato_nume ON neb.com_execucao_processo_judicial (contrato_numero);

CREATE TABLE IF NOT EXISTS neb.com_garantia
(
    garantia_id        smallint not null,
    garantia_descricao varchar(100)
);

ALTER TABLE neb.com_garantia owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.com_garantia TO nebgp_desenvolvedor;

CREATE INDEX garantia_cod_idx ON neb.com_garantia (garantia_id);

CREATE TABLE IF NOT EXISTS neb.com_operacao
(
    operacao_cod       smallint not null,
    operacao_descricao varchar(100)
);

ALTER TABLE neb.com_operacao owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.com_operacao TO nebgp_desenvolvedor;

CREATE INDEX com_operacao_operacao_cod_idx ON neb.com_operacao (operacao_cod);

CREATE TABLE IF NOT EXISTS neb.com_negociacao_parametro_consol
(
    corte_inferior_meses smallint,
    corte_superior_meses smallint,
    forma_pagamento      smallint,
    indexador            smallint,
    taxa_juros           numeric(10, 4)
);

ALTER TABLE neb.com_negociacao_parametro_consol owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.com_negociacao_parametro_consol TO nebgp_desenvolvedor;

CREATE TABLE IF NOT EXISTS neb.com_operacao_imp
(
    inport varchar(400)
);

ALTER TABLE neb.com_operacao_imp owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.com_operacao_imp TO nebgp_desenvolvedor;

CREATE TABLE IF NOT EXISTS neb.hab_boleto_dados
(
    contrato_numero           bigint not null,
    contrato_cpf_cnpj         bigint,
    contrato_ativo            bit,
    contrato_pv               integer,
    contrato_sistema_cod      smallint,
    contrato_cliente_tipo_cod smallint,
    contrato_op_cod           smallint,
    contrato_nome             varchar(100),
    contrato_dias_atraso      integer,
    contrato_divida_total     numeric(13, 2),
    contrato_val_ca           numeric(13, 2),
    contrato_data_ca          date,
    contrato_garantia_tipo    smallint,
    ajuizado                  bit,
    empresa_cobranca_cod      integer,
    contrato_girec_cod        integer,
    negociacao_parametro      smallint,
    contrato_posicao          date,
    contrato_dv               integer
);

ALTER TABLE neb.hab_boleto_dados owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.hab_boleto_dados TO nebgp_desenvolvedor;

CREATE INDEX hab_boleto_dados_contrato_cpf_c ON neb.hab_boleto_dados (contrato_cpf_cnpj);

CREATE TABLE IF NOT EXISTS neb.hab_boleto_dados_ext_negociacao
(
    negociacao_parametro integer,
    descricao            varchar(50)
);

ALTER TABLE neb.hab_boleto_dados_ext_negociacao owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.hab_boleto_dados_ext_negociacao TO nebgp_desenvolvedor;

CREATE TABLE IF NOT EXISTS neb.hab_boleto_proposta
(
    boleto_proposta                 bigint not null,
    contrato_numero                 bigint not null,
    contrato_cpf_cnpj               bigint not null,
    boleto_cedente                  bigint,
    boleto_nosso_numero             bigint,
    contrato_prest_atraso           smallint,
    boleto_valor                    numeric(13, 2),
    boleto_emissor                  varchar(11),
    boleto_ncpd                     varchar(4),
    boleto_data_vencimento          date,
    boleto_dt_doc                   date,
    boleto_incorporado              smallint,
    boleto_pago                     smallint,
    boleto_pago_dt                  date,
    boleto_pago_vlr                 numeric(13, 2),
    boleto_tp_116                   smallint,
    boleto_tp_116_dt                date,
    boleto_pa_contrato              integer,
    boleto_pa_responsavel           integer,
    boleto_data_vencimento_real     date,
    boleto_lote_tipo                smallint,
    boleto_lote_enviado             smallint,
    boleto_lote_quantidade_meses_pa smallint,
    boleto_lote_lista_meses_pausa   varchar(200),
    boleto_emissao_externo          smallint
);

ALTER TABLE neb.hab_boleto_proposta owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.hab_boleto_proposta TO nebgp_desenvolvedor;

CREATE TABLE IF NOT EXISTS neb.hab_produto
(
    produto_cod         smallint not null,
    produto_dv          smallint,
    produto_desc        varchar(100),
    produto_tipo_credor smallint,
    siico_produto_id    smallint,
    sis_num             smallint
);

ALTER TABLE neb.hab_produto owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.hab_produto TO nebgp_desenvolvedor;

CREATE INDEX hab_produto_produto_cod_idx ON neb.hab_produto (produto_cod);

CREATE TABLE IF NOT EXISTS neb.nebtbf51_acordo_ngcco_cartao
(
    nu_contrato_acordo             bigint  not null,
    dt_inclusao_acordo             date    not null,
    nu_cpf_solicitante_acordo      bigint  not null,
    nu_cpf_cliente_contrato        bigint  not null,
    nu_agencia_origem_contrato     integer not null,
    de_conteudo_acordo_xml_envio   text,
    de_conteudo_acordo_xml_retorno text,
    vr_total_acordo                numeric(13, 2),
    vr_entrada_acordo              numeric(13, 2),
    qt_parcela_acordo              integer,
    vr_parcela_acordo              numeric(13, 2),
    vr_iof_acordo                  numeric(13, 2),
    vr_desconto_acordo             numeric(13, 2)
);

ALTER TABLE neb.nebtbf51_acordo_ngcco_cartao owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.nebtbf51_acordo_ngcco_cartao TO nebgp_desenvolvedor;

CREATE TABLE IF NOT EXISTS neb.tbl_atualizacao_arquivos
(
    arquivo_id           integer not null,
    arquivo_nome         varchar(100),
    sineb_tabela_destino varchar(100),
    ordem                integer,
    carregar             integer,
    exportar             integer,
    sistema              integer,
    transmitir           integer,
    sigbd_transmite      varchar(50)
);

ALTER TABLE neb.tbl_atualizacao_arquivos owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.tbl_atualizacao_arquivos TO nebgp_desenvolvedor;

CREATE TABLE IF NOT EXISTS neb.tbl_atualizacao_tabelas_colunas
(
    registro_id integer not null,
    tabela_nome varchar(100),
    coluna_nome varchar(100),
    indice_tipo varchar(2),
    indice_nome varchar(100)
);

ALTER TABLE neb.tbl_atualizacao_tabelas_colunas owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.tbl_atualizacao_tabelas_colunas TO nebgp_desenvolvedor;

CREATE TABLE IF NOT EXISTS neb.tbl_atualizacao_views
(
    arquivo_id     integer not null,
    view_nome      varchar(100),
    view_definicao varchar
);

ALTER TABLE neb.tbl_atualizacao_views owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.tbl_atualizacao_views TO nebgp_desenvolvedor;

CREATE TABLE IF NOT EXISTS neb.tbl_atualizacao_views_dependenc
(
    arquivo_id  integer not null,
    view_nome   varchar(100),
    objeto_tipo varchar(100),
    objeto_nome varchar(100)
);

ALTER TABLE neb.tbl_atualizacao_views_dependenc owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.tbl_atualizacao_views_dependenc TO nebgp_desenvolvedor;

CREATE TABLE IF NOT EXISTS neb.tbl_atualizacao_zlog
(
    log_rotina                  varchar(100),
    log_rotina_passo            varchar(100),
    log_rotina_passo_observacao varchar(100),
    log_data_reg                timestamp
);

ALTER TABLE neb.tbl_atualizacao_zlog owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.tbl_atualizacao_zlog TO nebgp_desenvolvedor;

CREATE TABLE IF NOT EXISTS neb.tbl_auditorialog
(
    auditorialog_cpf_cnpj   bigint,
    auditorialog_ip         varchar(50) not null,
    auditorialog_url        varchar(100),
    auditorialog_dataacesso timestamp
);

ALTER TABLE neb.tbl_auditorialog owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.tbl_auditorialog TO nebgp_desenvolvedor;

CREATE TABLE IF NOT EXISTS neb.tbl_cadastro
(
    endereco_cpf_cnpj       bigint not null,
    endereco_logradouro_abr varchar(10),
    endereco_logradouro     varchar(100),
    endereco_numero         varchar(10),
    endereco_complemento    varchar(50),
    endereco_bairro         varchar(50),
    endereco_cidade         varchar(50),
    endereco_uf             varchar(2),
    endereco_cep            varchar(10),
    endereco_dados_extras   varchar(100),
    endereco_fone_1         varchar(20),
    endereco_fone_2         varchar(20),
    endereco_email          varchar(200),
    endereco_data_inclusao  timestamp
);

ALTER TABLE neb.tbl_cadastro owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.tbl_cadastro TO nebgp_desenvolvedor;

CREATE TABLE IF NOT EXISTS neb.tbl_campanha_contrato
(
    contrato_numero        bigint not null,
    campanha_valor_a_vista numeric(13, 2),
    campanha_valor_a_prazo numeric(13, 2),
    campanha_prazo         integer,
    campanha_vigencia      date
);

ALTER TABLE neb.tbl_campanha_contrato owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.tbl_campanha_contrato TO nebgp_desenvolvedor;

CREATE TABLE IF NOT EXISTS neb.tbl_cliente
(
    cliente_cpf_cnpj               bigint,
    cliente_nome                   varchar(100),
    cliente_dt_nasc                timestamp,
    cliente_sexo                   char,
    cliente_cod_estado_civil       smallint,
    cliente_nacionalidade          varchar(50),
    cliente_ident_numero           bigint,
    cliente_ident_emissor_uf       char(2),
    cliente_ident_emissor_orgao    varchar(10),
    cliente_ident_emissor_data     timestamp,
    cliente_pis_pasep              bigint,
    cliente_empresa_setor_cod      smallint,
    cliente_empresa_natureza_cod   smallint,
    cliente_empresa_represent_nome varchar(50),
    cliente_empresa_represent_cpf  bigint,
    cliente_segmento               varchar(4),
    cliente_gerente_matricula      varchar(7)
);

ALTER TABLE neb.tbl_cliente owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.tbl_cliente TO nebgp_desenvolvedor;

CREATE INDEX cliente_cpf_cnpj_idx ON neb.tbl_cliente (cliente_cpf_cnpj);

CREATE TABLE IF NOT EXISTS neb.tbl_cliente_bloqueio
(
    cliente_cpf_cnpj    bigint not null,
    cliente_dt_bloqueio timestamp
);

ALTER TABLE neb.tbl_cliente_bloqueio owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.tbl_cliente_bloqueio TO nebgp_desenvolvedor;

CREATE INDEX ix_tbl_cli_blq_cpf_cnpj ON neb.tbl_cliente_bloqueio (cliente_cpf_cnpj);

CREATE TABLE IF NOT EXISTS neb.tbl_cliente_empresa_natureza
(
    cliente_empresa_natureza_cod  smallint,
    cliente_empresa_natureza_desc varchar(50)
);

ALTER TABLE neb.tbl_cliente_empresa_natureza owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.tbl_cliente_empresa_natureza TO nebgp_desenvolvedor;

CREATE TABLE IF NOT EXISTS neb.tbl_cliente_empresa_setor
(
    cliente_empresa_setor_cod  smallint,
    cliente_empresa_setor_desc varchar(50)
);

ALTER TABLE neb.tbl_cliente_empresa_setor owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.tbl_cliente_empresa_setor TO nebgp_desenvolvedor;

CREATE TABLE IF NOT EXISTS neb.tbl_email
(
    email_cpf_cnpj          bigint,
    email_descricao         smallint,
    email_endereco          varchar(100),
    email_usuario_matricula char(20),
    email_usuario_unidade   smallint,
    email_data_cadastro     date,
    email_data_ALTERacao    date,
    email_valido            bit
);

ALTER TABLE neb.tbl_email owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.tbl_email TO nebgp_desenvolvedor;

CREATE INDEX tbl_email_email_cpf_cnpj_idx ON neb.tbl_email (email_cpf_cnpj);

CREATE TABLE IF NOT EXISTS neb.tbl_empct
(
    empct_codigo           integer not null,
    empct_nome             varchar(50),
    empct_cnpj             bigint,
    empct_segmento_credito integer
);

ALTER TABLE neb.tbl_empct owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.tbl_empct TO nebgp_desenvolvedor;

CREATE TABLE IF NOT EXISTS neb.tbl_empct_imp
(
    empct_codigo varchar(4000),
    empct_nome   varchar(400),
    empct_cnpj   varchar(400)
);

ALTER TABLE neb.tbl_empct_imp owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.tbl_empct_imp TO nebgp_desenvolvedor;

CREATE TABLE IF NOT EXISTS neb.tbl_endereco
(
    endereco_cpf_cnpj       bigint,
    endereco_descricao      smallint,
    endereco_logradouro_abr varchar(10),
    endereco_logradouro     varchar(100),
    endereco_numero         varchar(10),
    endereco_complemento    varchar(50),
    endereco_bairro         varchar(50),
    endereco_cidade         varchar(50),
    endereco_uf             varchar(2),
    endereco_cep            varchar(10),
    endereco_contrato       bigint
);

ALTER TABLE neb.tbl_endereco owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.tbl_endereco TO nebgp_desenvolvedor;

CREATE INDEX ix_tbl_endereco_cpf_cnpj ON neb.tbl_endereco (endereco_cpf_cnpj);

CREATE INDEX tbl_endereco_endereco_cpf_cnpj_ ON neb.tbl_endereco (endereco_cpf_cnpj);

CREATE TABLE IF NOT EXISTS neb.tbl_estatisticas
(
    item          varchar(50),
    referencia    varchar(50),
    data_registro timestamp,
    valor         varchar(50)
);

ALTER TABLE neb.tbl_estatisticas owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.tbl_estatisticas TO nebgp_desenvolvedor;

CREATE TABLE IF NOT EXISTS neb.tbl_fone
(
    fone_cpf_cnpj          bigint,
    fone_descricao         smallint,
    fone_tipo              smallint,
    fone_numero_ddd        smallint,
    fone_numero            bigint,
    fone_usuario_matricula char(20),
    fone_usuario_unidade   smallint,
    fone_data_cadastro     date,
    fone_data_ALTERacao    date,
    fone_valido            bit
);

ALTER TABLE neb.tbl_fone owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.tbl_fone TO nebgp_desenvolvedor;

CREATE INDEX ix_tbl_fone_cpf_cnpj ON neb.tbl_fone (fone_cpf_cnpj);

CREATE INDEX tbl_fone_numero_idx ON neb.tbl_fone (fone_numero_ddd, fone_numero);

CREATE TABLE IF NOT EXISTS neb.tbl_fone_ddd_regiao
(
    ddd                  smallint not null,
    uf                   varchar(2),
    qtde_digitos_celular smallint
);

ALTER TABLE neb.tbl_fone_ddd_regiao owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.tbl_fone_ddd_regiao TO nebgp_desenvolvedor;

CREATE TABLE IF NOT EXISTS neb.tbl_girec
(
    girec_cod       smallint,
    girec_sigla     varchar(8),
    girec_email_ext varchar(50),
    girec_telefone  varchar(14)
);

ALTER TABLE neb.tbl_girec owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.tbl_girec TO nebgp_desenvolvedor;

CREATE TABLE IF NOT EXISTS neb.tbl_indexadores
(
    ind_cod  smallint,
    ind_desc varchar(20)
);

ALTER TABLE neb.tbl_indexadores owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.tbl_indexadores TO nebgp_desenvolvedor;

CREATE TABLE IF NOT EXISTS neb.tbl_indices
(
    ind_cod     smallint,
    ini_dtref   date,
    ini_perc    numeric(7, 4),
    ini_fatacum numeric(18, 13),
    ini_cmacum  numeric(13, 9)
);

ALTER TABLE neb.tbl_indices owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.tbl_indices TO nebgp_desenvolvedor;

CREATE TABLE IF NOT EXISTS neb.tbl_nsu
(
    nsu_cod      integer not null,
    nsu_cpf_cnpj bigint  not null,
    nsu_data     timestamp
);

ALTER TABLE neb.tbl_nsu owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.tbl_nsu TO nebgp_desenvolvedor;

CREATE INDEX tbl_nsu_idx01 ON neb.tbl_nsu (nsu_cpf_cnpj);

CREATE TABLE IF NOT EXISTS neb.tbl_numero_validador
(
    numero_validador_cpf_cnpj bigint not null,
    numero_validador_codigo   integer,
    numero_validador_data     date
);

ALTER TABLE neb.tbl_numero_validador owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.tbl_numero_validador TO nebgp_desenvolvedor;

CREATE INDEX tbl_numero_validador_cpf_cnpj_i ON neb.tbl_numero_validador (numero_validador_cpf_cnpj);

CREATE TABLE IF NOT EXISTS neb.tbl_parametros
(
    parametro_id        integer not null,
    parametro_descricao varchar(100),
    parametro_status    boolean,
    parametro_valor     integer,
    parametro_msg       varchar(1000),
    parametro_exibe_msg boolean
);

ALTER TABLE neb.tbl_parametros owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.tbl_parametros TO nebgp_desenvolvedor;

CREATE TABLE IF NOT EXISTS neb.tbl_usuario_empct
(
    usuario_empct_codigo       integer not null,
    usuario_empct_email        varchar(100),
    usuario_empct_password     varchar(32),
    usuario_empct_ativo        boolean,
    usuario_empct_master       boolean,
    usuario_empct_cpf          bigint,
    usuario_empct_empct_codigo integer,
    usuario_empct_nome         varchar(100)
);

ALTER TABLE neb.tbl_usuario_empct owner TO c131481;

GRANT INSERT, SELECT, UPDATE, DELETE ON neb.tbl_usuario_empct TO nebgp_desenvolvedor;

