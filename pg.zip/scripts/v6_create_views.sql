CREATE OR REPLACE VIEW neb.vw_com_boleto_dados
            (contrato_numero, contrato_cpf_cnpj, contrato_ativo, contrato_pv, contrato_cliente_tipo_cod,
             contrato_op_cod, contrato_nome, contrato_dias_atraso, contrato_divida_total, contrato_val_ca,
             contrato_data_ca, contrato_sistema_cod, contrato_garantia_tipo, ajuizado, empresa_cobranca_cod,
             contrato_girec_cod, negociacao_parametro)
AS
SELECT com_boleto_dados.contrato_numero,
       com_boleto_dados.contrato_cpf_cnpj,
       com_boleto_dados.contrato_ativo,
       com_boleto_dados.contrato_pv,
       com_boleto_dados.contrato_cliente_tipo_cod,
       com_boleto_dados.contrato_op_cod,
       com_boleto_dados.contrato_nome,
       com_boleto_dados.contrato_dias_atraso,
       com_boleto_dados.contrato_divida_total,
       com_boleto_dados.contrato_val_ca,
       com_boleto_dados.contrato_data_ca,
       com_boleto_dados.contrato_sistema_cod,
       com_boleto_dados.contrato_garantia_tipo,
       com_boleto_dados.ajuizado,
       com_boleto_dados.empresa_cobranca_cod,
       com_boleto_dados.contrato_girec_cod,
       com_boleto_dados.negociacao_parametro
FROM neb.com_boleto_dados;

ALTER TABLE neb.vw_com_boleto_dados
    OWNER TO neb;

GRANT SELECT ON neb.vw_com_boleto_dados TO nebgp_desenvolvedor;

CREATE OR REPLACE VIEW neb.vw_auditorialog_dataacesso
            (auditorialog_cpf_cnpj, auditorialog_ip, auditorialog_url, auditorialog_dataacesso) AS
SELECT tbl_auditorialog.auditorialog_cpf_cnpj,
       tbl_auditorialog.auditorialog_ip,
       tbl_auditorialog.auditorialog_url,
       tbl_auditorialog.auditorialog_dataacesso
FROM neb.tbl_auditorialog
WHERE tbl_auditorialog.auditorialog_dataacesso::date = now()::date
ORDER BY tbl_auditorialog.auditorialog_dataacesso DESC;

ALTER TABLE neb.vw_auditorialog_dataacesso
    OWNER TO neb;

GRANT SELECT ON neb.vw_auditorialog_dataacesso TO nebgp_desenvolvedor;

CREATE OR REPLACE VIEW neb.vw_com_boleto_fone_internet(fone_cpf_cnpj, fone_numero_ddd, fone_numero) AS
SELECT f.fone_cpf_cnpj,
       f.fone_numero_ddd,
       f.fone_numero
FROM neb.tbl_fone f
         JOIN neb.tbl_fone_ddd_regiao fd ON f.fone_numero_ddd = fd.ddd
WHERE length(f.fone_numero::text) = fd.qtde_digitos_celular
  AND ("substring"(f.fone_numero::text, 1, 8)::integer <> ALL
       (ARRAY [99999999, 88888888, 77777777, 66666666, 55555555, 44444444, 33333333, 22222222, 11111111]))
  AND ("substring"(f.fone_numero::text, 1, 1)::integer = ANY (ARRAY [6, 7, 8, 9]))
GROUP BY f.fone_cpf_cnpj, f.fone_numero_ddd, f.fone_numero;

ALTER TABLE neb.vw_com_boleto_fone_internet
    OWNER TO neb;

GRANT SELECT ON neb.vw_com_boleto_fone_internet TO nebgp_desenvolvedor;

CREATE OR REPLACE VIEW neb.vw_com_boleto_dados_internet
            (cliente_cpf_cnpj, cliente_nome, cliente_dt_nasc, cliente_sexo, cliente_cod_estado_civil,
             cliente_nacionalidade, cliente_ident_numero, cliente_ident_emissor_uf, cliente_ident_emissor_orgao,
             cliente_ident_emissor_data, cliente_dt_bloqueio, contrato_cliente_tipo_cod, cliente_empresa_setor_cod,
             cliente_empresa_natureza_cod, cliente_empresa_represent_cpf, cliente_empresa_represent_nome)
AS
SELECT bd.contrato_cpf_cnpj AS cliente_cpf_cnpj,
       bd.contrato_nome     AS cliente_nome,
       c.cliente_dt_nasc,
       c.cliente_sexo,
       c.cliente_cod_estado_civil,
       c.cliente_nacionalidade,
       c.cliente_ident_numero,
       c.cliente_ident_emissor_uf,
       c.cliente_ident_emissor_orgao,
       c.cliente_ident_emissor_data,
       bloq.cliente_dt_bloqueio,
       bd.contrato_cliente_tipo_cod,
       c.cliente_empresa_setor_cod,
       c.cliente_empresa_natureza_cod,
       c.cliente_empresa_represent_cpf,
       c.cliente_empresa_represent_nome
FROM (SELECT com_boleto_dados.contrato_cpf_cnpj,
             com_boleto_dados.contrato_nome,
             com_boleto_dados.contrato_cliente_tipo_cod
      FROM neb.com_boleto_dados
      GROUP BY com_boleto_dados.contrato_cpf_cnpj, com_boleto_dados.contrato_nome,
               com_boleto_dados.contrato_cliente_tipo_cod
      UNION
      SELECT hab_boleto_dados.contrato_cpf_cnpj,
             hab_boleto_dados.contrato_nome,
             hab_boleto_dados.contrato_cliente_tipo_cod
      FROM neb.hab_boleto_dados
      GROUP BY hab_boleto_dados.contrato_cpf_cnpj, hab_boleto_dados.contrato_nome,
               hab_boleto_dados.contrato_cliente_tipo_cod
      UNION
      SELECT car_boleto_dados.contrato_cpf_cnpj,
             car_boleto_dados.contrato_nome,
             car_boleto_dados.contrato_cliente_tipo_cod
      FROM neb.car_boleto_dados
      GROUP BY car_boleto_dados.contrato_cpf_cnpj, car_boleto_dados.contrato_nome,
               car_boleto_dados.contrato_cliente_tipo_cod) bd
         LEFT JOIN neb.tbl_cliente c ON bd.contrato_cpf_cnpj = c.cliente_cpf_cnpj
         JOIN (SELECT vw_fi.fone_cpf_cnpj
               FROM neb.vw_com_boleto_fone_internet vw_fi
               GROUP BY vw_fi.fone_cpf_cnpj) fone ON c.cliente_cpf_cnpj = fone.fone_cpf_cnpj
         LEFT JOIN (SELECT max(clb.cliente_dt_bloqueio) AS cliente_dt_bloqueio,
                           clb.cliente_cpf_cnpj
                    FROM neb.tbl_cliente_bloqueio clb
                    GROUP BY clb.cliente_cpf_cnpj) bloq ON bloq.cliente_cpf_cnpj = c.cliente_cpf_cnpj;

ALTER TABLE neb.vw_com_boleto_dados_internet
    OWNER TO neb;

GRANT SELECT ON neb.vw_com_boleto_dados_internet TO nebgp_desenvolvedor;

CREATE OR REPLACE VIEW neb.vw_com_boleto_melhor_dados_cliente
            (cliente_cpf_cnpj, cliente_nome, cliente_dt_nasc, cliente_sexo, cliente_cod_estado_civil,
             cliente_nacionalidade, cliente_ident_numero, cliente_ident_emissor_uf, cliente_ident_emissor_orgao,
             cliente_ident_emissor_data, cliente_pis_pasep)
AS
SELECT tbl_cliente.cliente_cpf_cnpj,
       tbl_cliente.cliente_nome,
       tbl_cliente.cliente_dt_nasc,
       tbl_cliente.cliente_sexo,
       tbl_cliente.cliente_cod_estado_civil,
       tbl_cliente.cliente_nacionalidade,
       tbl_cliente.cliente_ident_numero,
       tbl_cliente.cliente_ident_emissor_uf,
       tbl_cliente.cliente_ident_emissor_orgao,
       tbl_cliente.cliente_ident_emissor_data,
       tbl_cliente.cliente_pis_pasep
FROM neb.tbl_cliente;

ALTER TABLE neb.vw_com_boleto_melhor_dados_cliente
    OWNER TO neb;

GRANT SELECT ON neb.vw_com_boleto_melhor_dados_cliente TO nebgp_desenvolvedor;

CREATE OR REPLACE VIEW neb.vw_com_boleto_melhor_email(email_cpf_cnpj, email_descricao, email_endereco, email_valido) AS
SELECT tbl_email.email_cpf_cnpj,
       tbl_email.email_descricao,
       tbl_email.email_endereco,
       tbl_email.email_valido
FROM neb.tbl_email;

ALTER TABLE neb.vw_com_boleto_melhor_email
    OWNER TO neb;

GRANT SELECT ON neb.vw_com_boleto_melhor_email TO nebgp_desenvolvedor;

CREATE OR REPLACE VIEW neb.vw_com_boleto_melhor_endereco
            (endereco_descricao, endereco_logradouro_abr, endereco_logradouro, endereco_numero, endereco_bairro,
             endereco_complemento, endereco_cidade, endereco_uf, endereco_cep, endereco_cpf_cnpj)
AS
SELECT tbl_endereco.endereco_descricao,
       tbl_endereco.endereco_logradouro_abr,
       tbl_endereco.endereco_logradouro,
       tbl_endereco.endereco_numero,
       tbl_endereco.endereco_bairro,
       tbl_endereco.endereco_complemento,
       tbl_endereco.endereco_cidade,
       tbl_endereco.endereco_uf,
       tbl_endereco.endereco_cep,
       tbl_endereco.endereco_cpf_cnpj
FROM neb.tbl_endereco;

ALTER TABLE neb.vw_com_boleto_melhor_endereco
    OWNER TO neb;

GRANT SELECT ON neb.vw_com_boleto_melhor_endereco TO nebgp_desenvolvedor;

CREATE OR REPLACE VIEW neb.vw_com_boleto_melhor_fone
            (fone_cpf_cnpj, fone_descricao, fone_numero_ddd, fone_numero, fone_data_ALTERacao) AS
SELECT tbl_fone.fone_cpf_cnpj,
       tbl_fone.fone_descricao,
       tbl_fone.fone_numero_ddd,
       tbl_fone.fone_numero,
       tbl_fone.fone_data_ALTERacao
FROM neb.tbl_fone;

ALTER TABLE neb.vw_com_boleto_melhor_fone
    OWNER TO neb;

GRANT SELECT ON neb.vw_com_boleto_melhor_fone TO nebgp_desenvolvedor;

