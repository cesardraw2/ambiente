sudo timedatectl set-timezone America/Sao_Paulo

sudo fallocate -l 10G /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile

sudo touch /etc/cloud/cloud.cfg.d/99-disable-network-config.cfg
sudo echo 'network: {config: disabled}:' >> /etc/cloud/cloud.cfg.d/99-disable-network-config.cfg

sudo apt-get -y install \
 curl \
 jq \
 apt-transport-https \
 ca-certificates \
 gnupg-agent \
 software-properties-common

curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -

sudo apt-key fingerprint 0EBFCD88

sudo add-apt-repository \
   "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"


echo "3 - Instalando o Docker..."
sudo apt-get install -y docker-ce docker-ce-cli containerd.io
sudo groupadd docker
sudo usermod -aG docker ubuntu
sudo systemctl enable docker
sudo apt install docker-compose -y

curl -o- https://raw.githubusercontent.com/creationix/nvm/v0.31.2/install.sh | bash

sudo cat /tmp/hosts > /etc/hosts

echo "Testando comunicação com VM -> http://sineb-api-des-esteiras.nprd2.caixa/sineb-api/adm/v1/pessoas"

curl -X GET "http://sineb-api-des-esteiras.nprd2.caixa/sineb-api/adm/v1/pessoas" -H "accept: application/json" | jq