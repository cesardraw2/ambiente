

echo 'export PATH=$PATH:/home/ubuntu/projects/sineb-web/node_modules/.bin/ngc' >> ~/.bashrc

curl -o- https://raw.githubusercontent.com/creationix/nvm/v0.31.2/install.sh | bash

nvm install v12.18.3

nvm alias default v12.18.3

npm i -g @angular/cli --force

