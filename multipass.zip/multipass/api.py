import flask
#from flask_cors import CORS, cross_origin

app = flask.Flask(__name__)
#cors = CORS(app)
app.config["DEBUG"] = True
#app.config['CORS_HEADERS'] = 'Content-Type'


#@cross_origin()
@app.route('/', methods=['GET'])
def home():
    return "<h1>Teste</h1><p>Conteúdo</p>"
    
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)