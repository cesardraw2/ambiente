cd /home/ubuntu/containers/db/adminer

docker-compose up -d 

