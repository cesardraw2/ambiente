echo "Inicializando API de teste..."
nohup python3 /home/ubuntu/api.py &
echo "\n\n ######## API de teste inicializada ########\n\n"
echo "HHHHHHHHHHHHHHHHHHHHHHH"
sudo netstat -anp | grep tcp
echo "HHHHHHHHHHHHHHHHHHHHHHH"