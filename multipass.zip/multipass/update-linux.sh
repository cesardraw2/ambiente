
echo "Atualizando o Linux"

sudo apt-get update 
sudo apt-get upgrade -y 
sudo apt-get -y install \
 net-tools \
 python3-pip
 
#cd /tmp
#curl https://raw.githubusercontent.com/creationix/nvm/master/install.sh | bash 
#source ~/.profile 

#nvm install node

#npm install -g @angular/cli

cd /home/ubuntu

#Create a new workspace and initial starter app
#ng new test-app
#cd test-app
#ng serve --host 0.0.0.0

pip3 install --user pipenv
pip3 install flask

pip3 install glances[all]








#nohup flask run --host=0.0.0.0 --port=5000 &