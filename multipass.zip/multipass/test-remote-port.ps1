#$ipaddress = "sineb-api-des-esteiras.nprd2.caixa"
$ipaddress = "10.0.0.122"
$port = 5432
$connection = New-Object System.Net.Sockets.TcpClient($ipaddress, $port)

if ($connection.Connected) {
    Write-Host "Success"
}
else {
    Write-Host "Failed"
}