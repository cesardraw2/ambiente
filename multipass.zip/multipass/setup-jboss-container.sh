cd /home/ubuntu/containers/jboss_eap_7_1

docker-compose up -d 

docker ps -a 

sudo netstat -anp | grep tcp

